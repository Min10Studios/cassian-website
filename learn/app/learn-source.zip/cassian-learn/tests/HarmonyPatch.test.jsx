import {afterEach,expect,test} from 'vitest';
import {cleanup,fireEvent,render,screen,within} from '@testing-library/react';
import LearnWeb from '../src/LearnWeb.jsx';
afterEach(()=>{cleanup();localStorage.clear();});
test('browser workshop explains B7 in E minor without rewriting the chord',()=>{
 render(<LearnWeb initialState={{section:'arpeggios',root:4}}/>);
 expect(screen.getAllByRole('option',{name:'G# / Ab'}).length).toBeGreaterThan(0);
 fireEvent.change(screen.getByLabelText('Chord sequence'),{target:{value:'B7 Em9'}});
 fireEvent.click(screen.getByRole('button',{name:'Apply sequence'}));
 fireEvent.change(screen.getByLabelText('Scale reference'),{target:{value:'minor'}});
 expect(screen.getByLabelText('Scale reference check').textContent).toMatch(/B7 uses D# outside/);
 expect(screen.getByLabelText('Scale reference check').textContent).toMatch(/conventional minor-key dominant/);
 const list=screen.getByRole('list',{name:'Arpeggio progression'});
 expect(within(list).getAllByRole('button')[0].textContent).toContain('B7');
});
