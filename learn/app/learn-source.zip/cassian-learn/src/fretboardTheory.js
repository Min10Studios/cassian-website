export const NOTE_NAMES = [
  "C",
  "C#",
  "D",
  "Eb",
  "E",
  "F",
  "F#",
  "G",
  "Ab",
  "A",
  "Bb",
  "B",
];
export const LEARN_KEYS = NOTE_NAMES.map((name, value) => ({ value, name }));
const tuning = (id, name, notes) => ({
  id,
  name,
  notes,
  openNotes: notes.map(midiNoteName),
});
export const LEARN_TUNINGS = [
  tuning("standard", "Standard E", [40, 45, 50, 55, 59, 64]),
  tuning("drop-d", "Drop D", [38, 45, 50, 55, 59, 64]),
  tuning("facgce", "FACGCE", [41, 45, 48, 55, 60, 64]),
  tuning("dadgad", "DADGAD", [38, 45, 50, 55, 57, 62]),
  tuning("open-d", "Open D", [38, 45, 50, 54, 57, 62]),
  tuning("drop-c", "Drop C", [36, 43, 48, 53, 57, 62]),
  tuning("seven-standard", "7-string B standard", [35, 40, 45, 50, 55, 59, 64]),
  tuning("daeacse", "DAEAC#E", [38, 45, 52, 57, 61, 64]),
  tuning("cgdgbd", "CGDGBD", [36, 43, 50, 55, 59, 62]),
  // Eight-string notes follow the public tuner; bass arrays are explicit reference additions.
  tuning(
    "eight-standard",
    "8-string F# standard",
    [30, 35, 40, 45, 50, 55, 59, 64],
  ),
  tuning("bass-four", "Bass · 4-string E standard", [28, 33, 38, 43]),
  tuning("bass-five", "Bass · 5-string B standard", [23, 28, 33, 38, 43]),
];
export const LEARN_SCALES = [
  {
    id: "minor-pentatonic",
    name: "Minor pentatonic",
    intervals: [0, 3, 5, 7, 10],
  },
  {
    id: "major-pentatonic",
    name: "Major pentatonic",
    intervals: [0, 2, 4, 7, 9],
  },
  { id: "blues", name: "Blues", intervals: [0, 3, 5, 6, 7, 10] },
  {
    id: "harmonic-minor",
    name: "Harmonic minor",
    intervals: [0, 2, 3, 5, 7, 8, 11],
  },
  { id: "ionian", name: "Ionian / major", intervals: [0, 2, 4, 5, 7, 9, 11] },
  { id: "dorian", name: "Dorian", intervals: [0, 2, 3, 5, 7, 9, 10] },
  { id: "phrygian", name: "Phrygian", intervals: [0, 1, 3, 5, 7, 8, 10] },
  { id: "lydian", name: "Lydian", intervals: [0, 2, 4, 6, 7, 9, 11] },
  { id: "mixolydian", name: "Mixolydian", intervals: [0, 2, 4, 5, 7, 9, 10] },
  {
    id: "aeolian",
    name: "Aeolian / natural minor",
    intervals: [0, 2, 3, 5, 7, 8, 10],
  },
  { id: "locrian", name: "Locrian", intervals: [0, 1, 3, 5, 6, 8, 10] },
  {
    id: "chromatic",
    name: "Chromatic",
    intervals: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
  },
];
export const PEARL_FRETS = [3, 5, 7, 9, 12, 15, 17, 19, 21, 24];
export const FRETBOARD_WIDTH = 1328;
export const FRET_STEP = 49;
export const FIRST_FRET_X = 105;
export const OPEN_STRING_X = 54;
export function pitchClass(note) {
  return ((Math.trunc(Number(note) || 0) % 12) + 12) % 12;
}
export function midiNoteName(midi, writtenName) {
  const name =
    typeof writtenName === "string"
      ? writtenName
      : NOTE_NAMES[pitchClass(midi)];
  const sharps = name.split("#").length - 1;
  const flats = name.split("b").length - 1;
  const writtenPitch = NOTE_NAMES.indexOf(name[0]) + sharps - flats;
  const octave = Math.floor((midi - writtenPitch) / 12) - 1;
  return name + octave;
}
export function getLearnTuning(id = "standard") {
  return LEARN_TUNINGS.find((item) => item.id === id) || LEARN_TUNINGS[0];
}
export function getLearnScale(id = "minor-pentatonic") {
  const aliases = {
    major: "ionian",
    minor: "aeolian",
    "natural-minor": "aeolian",
  };
  return (
    LEARN_SCALES.find((item) => item.id === (aliases[id] || id)) ||
    LEARN_SCALES[0]
  );
}
export function getFretMidi(tuningId, stringIndex, fret) {
  const selected =
    typeof tuningId === "string" ? getLearnTuning(tuningId) : tuningId;
  if (
    !selected?.notes ||
    !Number.isInteger(stringIndex) ||
    stringIndex < 0 ||
    stringIndex >= selected.notes.length ||
    !Number.isInteger(fret) ||
    fret < 0 ||
    fret > 24
  )
    return null;
  return selected.notes[stringIndex] + fret;
}
export function getRelativeInterval(midi, root) {
  return pitchClass(midi - root);
}
export function intervalName(interval, scaleId = "") {
  const labels = [
    "1",
    "b2",
    "2",
    "b3",
    "3",
    "4",
    "b5",
    "5",
    "b6",
    "6",
    "b7",
    "7",
  ];
  if (pitchClass(interval) === 6 && getLearnScale(scaleId).id === "lydian")
    return "#4";
  return labels[pitchClass(interval)];
}
export function getFretX(fret, leftHanded = false) {
  const right =
    fret === 0 ? OPEN_STRING_X : FIRST_FRET_X + (fret - 1) * FRET_STEP;
  return leftHanded ? FRETBOARD_WIDTH - right : right;
}
// Standard-E minor pentatonic boxes, measured from the low-E tonic fret.
// Each pair gives the two scale tones on one string, ordered low to high.
export const MINOR_PENTATONIC_BOXES = [
  [
    [0, 3],
    [0, 2],
    [0, 2],
    [0, 2],
    [0, 3],
    [0, 3],
  ],
  [
    [3, 5],
    [2, 5],
    [2, 5],
    [2, 4],
    [3, 5],
    [3, 5],
  ],
  [
    [5, 7],
    [5, 7],
    [5, 7],
    [4, 7],
    [5, 8],
    [5, 7],
  ],
  [
    [7, 10],
    [7, 10],
    [7, 9],
    [7, 9],
    [8, 10],
    [7, 10],
  ],
  [
    [10, 12],
    [10, 12],
    [9, 12],
    [9, 12],
    [10, 12],
    [10, 12],
  ],
];
export function isPentatonicBox(tuningId, scaleId) {
  return (
    tuningId === "standard" &&
    ["minor-pentatonic", "major-pentatonic"].includes(getLearnScale(scaleId).id)
  );
}
export function getPentatonicBox(root, scaleId, number) {
  const index = Number(number) - 1;
  if (index < 0 || index > 4 || !Number.isInteger(index)) return null;
  const major = getLearnScale(scaleId).id === "major-pentatonic";
  const patternIndex = major ? (index + 1) % 5 : index;
  const adjustment = major ? (index === 4 ? 9 : -3) : 0;
  let anchor = pitchClass(root - 4);
  const pattern = MINOR_PENTATONIC_BOXES[patternIndex].map((pair) =>
    pair.map((fret) => fret + adjustment),
  );
  if (Math.min(...pattern.flat()) + anchor < 0) anchor += 12;
  const frets = pattern.map((pair) => pair.map((fret) => fret + anchor));
  return {
    frets,
    min: Math.min(...frets.flat()),
    max: Math.max(...frets.flat()),
  };
}
export function getPositionOptions(tuningId, scaleId, root) {
  return [
    { value: "all", name: "Whole neck" },
    ...[1, 2, 3, 4, 5].map((number) => {
      const box = isPentatonicBox(tuningId, scaleId)
        ? getPentatonicBox(root, scaleId, number)
        : null;
      const min = box?.min ?? (number - 1) * 5;
      const max = box?.max ?? number * 5 - 1;
      return {
        value: String(number),
        name:
          (box ? "Box " : "Window ") + number + " · frets " + min + "–" + max,
      };
    }),
  ];
}
export function isInPosition(
  stringIndex,
  fret,
  { tuningId, scaleId, root, position = "all" },
) {
  if (position === "all") return true;
  const number = Number(position);
  if (!Number.isInteger(number) || number < 1 || number > 5) return true;
  if (isPentatonicBox(tuningId, scaleId)) {
    return (
      getPentatonicBox(root, scaleId, number).frets[stringIndex]?.includes(
        fret,
      ) || false
    );
  }
  return fret >= (number - 1) * 5 && fret <= number * 5 - 1;
}
export function canShowChordShape(chord, tuningId, root) {
  return Boolean(
    chord &&
    Array.isArray(chord.frets) &&
    chord.tuning === tuningId &&
    chord.frets.length === getLearnTuning(tuningId).notes.length &&
    Number.isFinite(chord.baseRoot) &&
    pitchClass(chord.baseRoot) === pitchClass(root),
  );
}
