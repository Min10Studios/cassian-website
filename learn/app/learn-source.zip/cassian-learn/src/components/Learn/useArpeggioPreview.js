import { useCallback, useEffect, useRef, useState } from 'react';
import { createArpeggioPlayer } from './arpeggioPlayer.js';

export default function useArpeggioPreview(modelKey, { volume = 75, nativeStatus } = {}) {
  const [playing, setPlaying] = useState(false),
    [active, setActive] = useState(null),
    [error, setError] = useState('');
  const player = useRef(null),
    alive = useRef(false);
  const stop = useCallback(() => {
    player.current?.stop();
    if (alive.current) {
      setPlaying(false);
      setActive(null);
    }
  }, []);
  useEffect(() => {
    alive.current = true;
    const hide = () => {
      if (document.hidden) stop();
    };
    document.addEventListener('visibilitychange', hide);
    window.addEventListener('blur', stop);
    return () => {
      alive.current = false;
      player.current?.stop();
      document.removeEventListener('visibilitychange', hide);
      window.removeEventListener('blur', stop);
    };
  }, [stop]);
  useEffect(() => {
    stop();
  }, [modelKey, stop]);
  useEffect(() => {
    player.current?.updateStatus?.(nativeStatus);
  }, [nativeStatus]);
  useEffect(() => {
    const result = player.current?.setVolume?.(volume);
    if (result?.catch) result.catch(() => {});
  }, [volume]);
  const play = async (events, options) => {
    setError('');
    player.current?.stop();
    const factory = createArpeggioPlayer;
    player.current = factory({
      AudioContextClass: window.AudioContext || window.webkitAudioContext,
      onEvent: (event) => {
        if (alive.current) setActive(event);
      },
      onStarted: () => {
        if (alive.current) setPlaying(true);
      },
      onComplete: () => {
        if (alive.current) setPlaying(false);
      },
      onError: (failure) => {
        if (alive.current) {
          setError(failure.message);
          setPlaying(false);
          setActive(null);
        }
      },
    });
    try {
      await player.current.start(events, { ...options, volume });
    } catch (failure) {
      if (alive.current) {
        setError(failure.message);
        setPlaying(false);
        setActive(null);
      }
    }
  };
  return { playing, active, error, play, stop };
}
