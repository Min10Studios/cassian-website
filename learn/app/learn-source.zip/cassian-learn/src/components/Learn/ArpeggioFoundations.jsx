import { useId, useState } from 'react';
import { getScaleNoteNames } from '../../curriculum.js';
import { NOTE_NAMES } from './fretboardTheory.js';
import {
  ARPEGGIO_QUALITIES,
  HARMONY_SCALES,
  INTERVAL_STUDIES,
  harmonizeArpeggios,
  arpeggioName,
} from './arpeggioTheory.js';

const routines = [
  [
    '01',
    'Triads before speed',
    'Major · minor · diminished · augmented',
    'Start at 60 BPM with quarter notes. Say root, third and fifth as you pick. Use one ' +
      'string set, then repeat in another position. Aim for clean separation before adding ' +
      'speed.',
  ],
  [
    '02',
    'Own the inversions',
    'Root · third · fifth · seventh',
    'Keep one chord and change its starting tone. Sing the bass note, then play ' +
      'ascending and descending. An inversion changes the starting note; the chord root ' +
      'stays the same.',
  ],
  [
    '03',
    'Follow the changes',
    'ii–V–I · guide tones',
    'Use the extended ii–V–I template. Identify each third and seventh, then land on one ' +
      'when the chord changes. Hold a shared tone across the change before trying a busier ' +
      'line.',
  ],
  [
    '04',
    'Picking and phrasing',
    'Alternate · legato · sweep',
    'Start with alternate picking and relaxed hands. Try legato where notes share a ' +
      'string. Sweep only on adjacent strings, muting the string you leave; generated ' +
      'routes are not automatic sweep fingerings. Leave rests and finish on a chord tone.',
  ],
  [
    '05',
    'Practise the rhythm',
    'Straight · triplets · odd bars',
    'Keep quarter-note BPM steady while changing subdivisions. In 3/4 count three ' +
      'quarters; in 6/8 try two groups of three eighths. Group 5/4 as 3+2 and 7/8 as ' +
      '2+2+3. Accent a group, then move the accent.',
  ],
  [
    '06',
    'Make a musical line',
    'Chord tones · approach notes · space',
    'Learn the arpeggio first, then connect two chord tones with one nearby scale note. ' +
      'Resolve that passing note deliberately. Practise short phrases with a held note and ' +
      'a rest instead of continuous runs.',
  ],
];

export default function ArpeggioFoundations({
  root,
  onAddChord,
  onHear,
  stop,
  disabled,
  referenceScale,
  onReferenceScaleChange,
}) {
  const formId = useId();
  const [fallbackScale, setScale] = useState('major'),
    [sevenths, setSevenths] = useState(true);
  const scale = HARMONY_SCALES.some((item) => item.id === referenceScale)
    ? referenceScale
    : fallbackScale;
  const [question, setQuestion] = useState(null),
    [answer, setAnswer] = useState(null),
    [direction, setDirection] = useState('up');
  const nextQuestion = () => {
    stop();
    const random = new Uint32Array(2);
    crypto.getRandomValues(random);
    setQuestion({ interval: random[0] % 13, base: 48 + root + (random[1] % 2) * 12 });
    setAnswer(null);
  };
  const hear = () => {
    if (!question) return;
    const interval = INTERVAL_STUDIES[question.interval][2] * (direction === 'down' ? -1 : 1);
    onHear(
      [
        { midi: question.base, tick: 0, duration: 380 },
        { midi: question.base + interval, tick: 480, duration: 680 },
      ],
      { tempo: 80, totalTicks: 1200 },
    );
  };
  return (
    <>
      <section className="arp-panel" aria-label="Arpeggio practice routines">
        <div className="arp-heading">
          <div>
            <span className="arp-eyebrow">BUILD A PRACTICE HABIT</span>
            <h3>From shapes to music.</h3>
          </div>
          <p>Short, focused studies for the notes you just built.</p>
        </div>
        <div className="arp-routines">
          {routines.map(([number, name, subtitle, text]) => (
            <details key={number}>
              <summary>
                <b>{number}</b>
                <span>
                  {name}
                  <small>{subtitle}</small>
                </span>
              </summary>
              <p>{text}</p>
            </details>
          ))}
        </div>
      </section>
      <section className="arp-panel" aria-label="Scale harmonization">
        <div className="arp-heading">
          <div>
            <span className="arp-eyebrow">CHORDS THAT BELONG TOGETHER</span>
            <h3>Build from a scale.</h3>
          </div>
          <p>Stack alternate scale notes to find the triads and sevenths in your lesson key.</p>
        </div>
        <div className="arp-controls">
          <label htmlFor={`${formId}-field-1`}>
            Harmony scale
            <select
              id={`${formId}-field-1`}
              value={scale}
              onChange={(event) => {
                setScale(event.target.value);
                onReferenceScaleChange?.(event.target.value);
              }}
            >
              {HARMONY_SCALES.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <label htmlFor={`${formId}-field-2`}>
            Chord depth
            <select
              id={`${formId}-field-2`}
              value={sevenths ? '7' : '3'}
              onChange={(event) => setSevenths(event.target.value === '7')}
            >
              <option value="3">Triads</option>
              <option value="7">Seventh chords</option>
            </select>
          </label>
        </div>
        <p className="arp-note">
          {NOTE_NAMES[root]} {HARMONY_SCALES.find((item) => item.id === scale).name}:{' '}
          {getScaleNoteNames({ major: 'ionian', minor: 'aeolian' }[scale] ?? scale, root).join(
            ' · ',
          )}
          . This builds chord suggestions; your existing chord qualities stay as written.
        </p>
        <div className="arp-harmony">
          {harmonizeArpeggios(scale, sevenths).map((item) => (
            <button
              type="button"
              key={item.degree}
              disabled={disabled || !item.quality}
              onClick={() => onAddChord(item)}
              aria-label={`Add degree ${item.degree}, ${arpeggioName(root, item)}`}
            >
              <small>DEGREE {item.degree}</small>
              <strong>{arpeggioName(root, item)}</strong>
              <span>+ Add chord</span>
            </button>
          ))}
        </div>
        {scale === 'melodic-minor' && (
          <p className="arp-note">
            This is ascending melodic minor, also used as a fixed jazz scale. Classical descending
            melodic minor uses natural minor.
          </p>
        )}
      </section>
      <div className="arp-reference-grid">
        <section className="arp-panel" aria-label="Interval ear trainer">
          <span className="arp-eyebrow">HEAR THE DISTANCE</span>
          <h3>Train your ear.</h3>
          <p>Choose a challenge, listen, then name the interval. Sing it back before checking.</p>
          <label htmlFor={`${formId}-field-3`}>
            Interval direction
            <select
              id={`${formId}-field-3`}
              value={direction}
              onChange={(event) => {
                stop();
                setDirection(event.target.value);
                setAnswer(null);
              }}
            >
              <option value="up">Ascending</option>
              <option value="down">Descending</option>
            </select>
          </label>
          <div className="arp-actions">
            <button type="button" onClick={nextQuestion}>
              New interval
            </button>
            <button type="button" onClick={hear} disabled={!question}>
              Hear interval
            </button>
          </div>
          <div className="arp-interval-answers" role="group" aria-label="Interval answers">
            {INTERVAL_STUDIES.map(([name, degree], index) => (
              <button
                type="button"
                key={name}
                disabled={!question}
                aria-pressed={answer === index}
                onClick={() => setAnswer(index)}
              >
                {degree}
                <small>{name}</small>
              </button>
            ))}
          </div>
          <p className="arp-feedback" role="status">
            {answer === null
              ? question
                ? 'Ready when you are. Hear the interval as often as you need.'
                : 'Press New interval to begin. Audio starts only when you press Hear.'
              : answer === question.interval
                ? `Correct · ${INTERVAL_STUDIES[question.interval][0]}. ` +
                  `${INTERVAL_STUDIES[question.interval][2]} semitones.`
                : 'Try again. Compare the distance between the two notes.'}
          </p>
          {question && answer !== null && answer !== question.interval && (
            <button type="button" onClick={() => setAnswer(question.interval)}>
              Reveal answer
            </button>
          )}
        </section>
        <section className="arp-panel" aria-label="Music theory reference">
          <span className="arp-eyebrow">THE ESSENTIALS</span>
          <h3>Understand the notes.</h3>
          <details open>
            <summary>What makes an arpeggio?</summary>
            <p>
              A chord played one note at a time. A triad has a root, third and fifth. Sevenths add
              another chord tone; ninths, elevenths and thirteenths add colour. A ninth is a second
              an octave higher; this builder folds extensions into the chosen register for playable
              studies.
            </p>
          </details>
          <details>
            <summary>Intervals and chord construction</summary>
            <div className="arp-theory-table">
              <table>
                <caption>Semitone distances from the root</caption>
                <thead>
                  <tr>
                    <th>Interval</th>
                    <th>Semitones</th>
                    <th>Use</th>
                  </tr>
                </thead>
                <tbody>
                  {INTERVAL_STUDIES.map(([name, degree, semitones, use]) => (
                    <tr key={name}>
                      <th scope="row">
                        {name} · {degree}
                      </th>
                      <td>{semitones}</td>
                      <td>{use}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
          <details>
            <summary>Chord formula library · {ARPEGGIO_QUALITIES.length} types</summary>
            <div className="arp-formula-library">
              {ARPEGGIO_QUALITIES.map((item) => (
                <p key={item.id}>
                  <strong>{item.name}</strong>
                  <span>{item.degrees.join(' · ')}</span>
                </p>
              ))}
            </div>
          </details>
          <details>
            <summary>Rhythm, inversions and voice leading</summary>
            <p>
              All tempos here count quarter notes. Eighths divide a quarter into two, triplets into
              three and sixteenths into four. An inversion begins on another chord tone. Voice
              leading connects nearby tones between chords; shared tones and the nearest movement
              appear beside your selected chord.
            </p>
          </details>
          <details>
            <summary>Tab, tuning and handedness</summary>
            <p>
              Tab keeps the highest string at the top. Numbers are fret numbers, not fingers.
              Left-handed mode mirrors the neck without changing pitches or tab order. Changing
              tuning recalculates every path; a fingering from standard tuning is never copied into
              another tuning.
            </p>
          </details>
        </section>
      </div>
    </>
  );
}
