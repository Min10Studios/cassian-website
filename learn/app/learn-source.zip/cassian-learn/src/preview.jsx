import { mountCassianLearn } from "./mount.jsx";
window.learnPreview = mountCassianLearn(document.querySelector("#learn"), {
  stylesUrl: "/src/learn.css?direct",
  sourceUrl: "/learn-source.zip",
});
