import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig(({ command }) => ({
  define: command === "build" ? { "process.env.NODE_ENV": '"production"' } : {},
  plugins: [react()],
  cacheDir: ".local/vite-cache",
  build: {
    lib: {
      entry: "src/mount.jsx",
      formats: ["es"],
      fileName: () => "cassian-learn.js",
      cssFileName: "cassian-learn",
    },
    minify: "terser",
    sourcemap: false,
  },
  test: { environment: "jsdom", include: ["tests/**/*.test.{js,jsx}"] },
}));
