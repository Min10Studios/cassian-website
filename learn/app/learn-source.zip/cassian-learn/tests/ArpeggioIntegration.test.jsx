import {afterEach,expect,test} from 'vitest';
import {cleanup,fireEvent,render,screen,within} from '@testing-library/react';
import LearnWeb from '../src/LearnWeb.jsx';
afterEach(() => { cleanup(); localStorage.clear(); });
test('portable Learn opens the new workshop and keeps Band scope explicit', () => {
  render(<LearnWeb initialState={{section:'arpeggios'}} />);
  expect(screen.getByRole('heading',{name:'Build a progression. Play it through.'})).toBeTruthy();
  expect(screen.getByRole('button',{name:'Play progression'})).toBeTruthy();
  expect(screen.getByText(/Play with Band in Cassian for Windows/)).toBeTruthy();
  expect(screen.queryByRole('button',{name:'Send to Band'})).toBeNull();
});
test('typed ECDB reaches the browser workshop in the requested order', () => {
  render(<LearnWeb initialState={{section:'arpeggios'}} />);
  fireEvent.change(screen.getByLabelText('Chord sequence'),{target:{value:'ECDB'}});
  fireEvent.click(screen.getByRole('button',{name:'Apply sequence'}));
  const list=screen.getByRole('list',{name:'Arpeggio progression'});
  const names=within(list).getAllByRole('button').map(button=>button.textContent);
  expect(names.join(' ')).toMatch(/E.*C.*D.*B/);
});
test('one handedness preference controls the new arpeggio view', () => {
  render(<LearnWeb initialState={{section:'arpeggios',handedness:'left'}} />);
  expect(screen.getByRole('checkbox',{name:'Left-handed view'}).checked).toBe(true);
  fireEvent.click(screen.getByRole('checkbox',{name:'Left-handed view'}));
  expect(screen.getByLabelText('Handedness').value).toBe('right');
});
