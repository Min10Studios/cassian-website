// Append only: the first six indices belong to released songs and recordings.
export const rhythmGenres = [
  "Rock",
  "Metalcore",
  "Thrash",
  "Blues shuffle",
  "Funk",
  "Clean ballad",
  "Pop",
  "Country",
  "Jazz swing",
  "Acoustic folk",
  "Reggae",
  "R&B / soul",
  "Punk",
  "Alternative / indie",
  "Latin / bossa",
  "Hard rock",
];
export const legacyGenreCount = 6;
export const shuffleGenre = (genre) => genre === 3 || genre === 8;
export const genreSubdivision = (genre) => (shuffleGenre(genre) ? "8T" : "16");

export const legacyGenre = (genre) =>
  [0, 1, 2, 3, 4, 5, 0, 0, 3, 5, 4, 4, 2, 0, 5, 0][genre] ?? 0;
