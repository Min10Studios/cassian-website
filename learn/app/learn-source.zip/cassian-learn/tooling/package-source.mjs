import {
  readFile,
  readdir,
  mkdir,
  writeFile,
  copyFile,
} from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve, relative } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const lock = JSON.parse(
  await readFile(resolve(root, "package-lock.json"), "utf8"),
);
for (const [name, entry] of Object.entries(lock.packages)) {
  if (
    entry.link ||
    (entry.resolved &&
      !entry.resolved.startsWith("https://registry.npmjs.org/"))
  )
    throw Error("Preferred source must not inherit dependency links: " + name);
}
const allowedRoots = ["src", "tests", "tooling"];
const files = [
  "package.json",
  "index.html",
  "package-lock.json",
  "vite.config.js",
  "README.md",
  "LICENSE.txt",
  "NOTICES.txt",
];
async function collect(directory) {
  for (const entry of await readdir(resolve(root, directory), {
    withFileTypes: true,
  })) {
    const name = directory + "/" + entry.name;
    if (entry.isDirectory()) await collect(name);
    else if (entry.isFile()) files.push(name);
    else throw Error("Source package cannot contain links: " + name);
  }
}
for (const directory of allowedRoots) await collect(directory);
const crc32 = (data) => {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++)
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
};
const word = (value, size) => {
  const buffer = Buffer.alloc(size);
  if (size === 2) buffer.writeUInt16LE(value);
  else buffer.writeUInt32LE(value);
  return buffer;
};
const locals = [],
  central = [];
let offset = 0;
for (const file of files.sort()) {
  const data = await readFile(resolve(root, file)),
    name = Buffer.from("cassian-learn/" + file);
  if (/[A-Za-z]:[\\/]Users[\\/][^\s"']+/i.test(data.toString("utf8")))
    throw Error("Local user-profile path in public source: " + file);
  const crc = crc32(data),
    flags = 0x800;
  const header = Buffer.concat([
    word(0x04034b50, 4),
    word(20, 2),
    word(flags, 2),
    word(0, 2),
    word(0, 2),
    word(33, 2),
    word(crc, 4),
    word(data.length, 4),
    word(data.length, 4),
    word(name.length, 2),
    word(0, 2),
    name,
  ]);
  locals.push(header, data);
  central.push(
    Buffer.concat([
      word(0x02014b50, 4),
      word(20, 2),
      word(20, 2),
      word(flags, 2),
      word(0, 2),
      word(0, 2),
      word(33, 2),
      word(crc, 4),
      word(data.length, 4),
      word(data.length, 4),
      word(name.length, 2),
      word(0, 2),
      word(0, 2),
      word(0, 2),
      word(0, 2),
      word(0, 4),
      word(offset, 4),
      name,
    ]),
  );
  offset += header.length + data.length;
}
const directory = Buffer.concat(central);
const zip = Buffer.concat([
  ...locals,
  directory,
  Buffer.concat([
    word(0x06054b50, 4),
    word(0, 2),
    word(0, 2),
    word(files.length, 2),
    word(files.length, 2),
    word(directory.length, 4),
    word(offset, 4),
    word(0, 2),
  ]),
]);
const output = resolve(root, "dist");
await mkdir(output, { recursive: true });
await writeFile(resolve(output, "learn-source.zip"), zip);
for (const name of ["LICENSE.txt", "NOTICES.txt"])
  await copyFile(resolve(root, name), resolve(output, name));
const rows = [];
for (const entry of (await readdir(output)).sort()) {
  if (entry === "manifest.json") continue;
  const path = resolve(output, entry),
    data = await readFile(path);
  rows.push({
    file: relative(output, path),
    bytes: data.length,
    sha256: createHash("sha256").update(data).digest("hex"),
  });
}
await writeFile(
  resolve(output, "manifest.json"),
  JSON.stringify({ schema: 1, files: rows }, null, 2) + "\n",
);
console.log(
  "Public Learn source/resources packaged: " +
    rows.length +
    " files; " +
    files.length +
    " source entries.",
);
