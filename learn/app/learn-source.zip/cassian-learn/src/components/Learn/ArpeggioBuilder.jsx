import { DraftDial } from '../HardwareControls.jsx';
import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import { useRetainedState } from '../../retainedViewState.js';
import {
  LEARN_KEYS,
  LEARN_TUNINGS,
  NOTE_NAMES,
  pitchClass,
  getLearnTuning,
} from './fretboardTheory.js';
import {
  ARPEGGIO_QUALITIES,
  ARPEGGIO_PATTERNS,
  ARPEGGIO_METERS,
  ARPEGGIO_RATES,
  ARPEGGIO_TEMPLATES,
  ARPEGGIO_STORAGE_KEY,
  MAX_ARPEGGIO_STEPS,
  getArpeggioQuality,
  getArpeggioRoot,
  arpeggioName,
  spellChordTones,
  createArpeggioProgression,
  normalizeArpeggioProgression,
  compileArpeggioProgression,
  chordConnection,
  arpeggioMidi,
  parseArpeggioSequence,
  ARPEGGIO_GENRES,
  meterQuarterBeats,
  arpeggioTab,
} from './arpeggioTheory.js';
import ArpeggioNeck from './ArpeggioNeck.jsx';
import ArpeggioFoundations from './ArpeggioFoundations.jsx';
import useArpeggioPreview from './useArpeggioPreview.js';
import { native } from '../../juce/bridge.js';
import ArpeggioBandSend from './ArpeggioBandSend.jsx';

function readLibrary() {
  try {
    const raw = localStorage.getItem(ARPEGGIO_STORAGE_KEY);
    if (!raw || raw.length > 131072) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length <= 12
      ? parsed.map(normalizeArpeggioProgression)
      : [];
  } catch {
    return [];
  }
}
function download(data, type, name) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function ArpeggioBuilder({
  leftHanded: preferredLeftHanded,
  onLeftHandedChange,
  root = 4,
  tuning = 'standard',
  onRootChange,
  onTuningChange,
  status = {},
  onNavigate,
  onError,
  onBusyChange,
}) {
  const formId = useId();
  const [draft, setDraft] = useRetainedState('learn-arpeggios', 'draft', createArpeggioProgression);
  const [tempoText, setTempoText] = useState(null);
  const [selectedId, setSelectedId] = useRetainedState('learn-arpeggios', 'selected', 1);
  const [leftHanded, setLeftHanded] = useRetainedState('learn-neck', 'left-handed', false);
  useEffect(() => {
    if (preferredLeftHanded !== undefined) setLeftHanded(preferredLeftHanded);
  }, [preferredLeftHanded, setLeftHanded]);
  const [loop, setLoop] = useRetainedState('learn-arpeggios', 'loop', true);
  const [studyView, setStudyView] = useRetainedState('learn-arpeggios', 'study-view', 'neck');
  const [sequence, setSequence] = useRetainedState('learn-arpeggios', 'sequence', '');
  const [sequenceError, setSequenceError] = useState(''),
    [playScope, setPlayScope] = useState(null);
  const [template, setTemplate] = useState('metal-minor'),
    [genre, setGenre] = useState('Metal');
  const [composerMode, setComposerMode] = useState('sequence'),
    [resetRequested, setResetRequested] = useState(false);
  const [bandSending, setBandSending] = useState(false),
    [resetEpoch, setResetEpoch] = useState(0);
  const handleBandBusy = useCallback(
    (busy) => {
      setBandSending(busy);
      onBusyChange?.(busy);
    },
    [onBusyChange],
  );
  const [library, setLibrary] = useState(readLibrary),
    [savedChoice, setSavedChoice] = useState('');
  const [feedback, setFeedback] = useState(''),
    [pendingLoad, setPendingLoad] = useState(null);
  const fileInput = useRef(null);
  const studyPane = useRef(null),
    previousKey = useRef(root),
    previousRange = useRef(draft.runRange);
  const focusStudy = useCallback(() => {
    const pane = studyPane.current;
    const target = pane?.classList.contains('is-full-neck')
      ? pane.querySelector('.arp-neck-panel')
      : pane;
    target?.scrollIntoView?.({ block: 'start', behavior: 'auto' });
  }, []);
  useEffect(() => {
    if (previousKey.current !== root || previousRange.current !== draft.runRange) {
      previousKey.current = root;
      previousRange.current = draft.runRange;
      focusStudy();
    }
  }, [root, draft.runRange, focusStudy]);
  const [previewVolume, setPreviewVolume] = useRetainedState('learn-arpeggios', 'volume', 75);
  const modelKey = JSON.stringify([draft, root, tuning]);
  const preview = useArpeggioPreview(modelKey, {
    volume: previewVolume,
    nativeStatus: status.learnPreview,
  });
  const compiled = useMemo(
    () => compileArpeggioProgression(draft, root, tuning),
    [draft, root, tuning],
  );
  const studyStep =
    playScope === 'progression'
      ? draft.steps.findIndex((step) => step.id === preview.active?.stepId)
      : -1;
  const playingStep = preview.playing ? studyStep : -1;
  const selectedIndex = Math.max(
    0,
    studyStep >= 0 ? studyStep : draft.steps.findIndex((step) => step.id === selectedId),
  );
  const selected = draft.steps[selectedIndex],
    chordRoot = getArpeggioRoot(root, selected);
  const selectedQuality = getArpeggioQuality(selected.quality),
    selectedPath = compiled.paths[selectedIndex];
  const progressionTab = useMemo(
    () =>
      compiled.missing.length
        ? 'Widen the fret range so every chord has a complete run.'
        : arpeggioTab(draft, root, tuning),
    [compiled, draft, root, tuning],
  );
  const next = draft.steps[(selectedIndex + 1) % draft.steps.length];
  const connection = chordConnection(
    chordRoot,
    selected.quality,
    getArpeggioRoot(root, next),
    next.quality,
  );
  const chordTones = spellChordTones(chordRoot, selected.quality);
  const atLimit = draft.steps.length >= MAX_ARPEGGIO_STEPS;
  const saveName = draft.name.trim() || 'My progression';
  const fileName = saveName.replace(/[^a-z0-9_-]+/gi, '-').slice(0, 70);
  const pulse = ARPEGGIO_RATES.find((item) => item.id === draft.rate).ticks;
  const genreTemplates = ARPEGGIO_TEMPLATES.filter((item) => item.genre === genre);
  const chosenTemplate =
    ARPEGGIO_TEMPLATES.find((item) => item.id === template) ?? genreTemplates[0];
  const stepBars = (index) => compiled.stepTicks[index] / (meterQuarterBeats(draft.meter) * 480);

  const playReference = (events, options, scope = 'single') => {
    if (scope !== 'progression') setSelectedId(selected.id);
    setPlayScope(scope);
    if (draft.runRange === 'full-neck') focusStudy();
    preview.play(events, options);
  };
  const update = (changes) => {
    preview.stop();
    setDraft((current) => ({ ...current, ...changes }));
    setFeedback('Draft changed. Save it to keep it after closing Cassian.');
  };
  const updateStep = (changes) => {
    update({
      steps: draft.steps.map((step) => (step.id === selected.id ? { ...step, ...changes } : step)),
    });
    focusStudy();
  };
  const applyChordSequence = (append = false) => {
    try {
      const steps = parseArpeggioSequence(sequence, root, draft.nextId).map((step) =>
        draft.runRange === 'full-neck' ? { ...step, pattern: 'up' } : step,
      );
      if (steps.length + (append ? draft.steps.length : 0) > MAX_ARPEGGIO_STEPS)
        throw new Error('Keep the complete progression within 32 chords.');
      const name =
        !append && ARPEGGIO_TEMPLATES.some((item) => item.name === draft.name)
          ? steps
              .map((step) => arpeggioName(root, step))
              .join(' – ')
              .slice(0, 80)
          : draft.name;
      update({
        name,
        steps: append ? [...draft.steps, ...steps] : steps,
        nextId: draft.nextId + steps.length,
      });
      setSelectedId(steps[0].id);
      setSequenceError('');
      focusStudy();
      setFeedback('Sequence ready. Play progression follows every card from left to right.');
    } catch (error) {
      setSequenceError(error.message);
    }
  };
  const applyGenreProgression = () => {
    const preset = createArpeggioProgression(chosenTemplate.id);
    const steps = preset.steps.map((step, index) => ({
      ...step,
      id: draft.nextId + index,
      pattern: draft.runRange === 'full-neck' ? 'up' : step.pattern,
    }));
    update({ name: preset.name, steps, nextId: draft.nextId + steps.length });
    setSelectedId(steps[0].id);
    focusStudy();
    setSequenceError('');
    setFeedback(
      `${genre} · ${chosenTemplate.name} is ready in ${NOTE_NAMES[root]}. Play it through or edit any chord.`,
    );
  };
  const resetDefaults = () => {
    preview.stop();
    const fresh = createArpeggioProgression();
    setDraft(fresh);
    setSelectedId(fresh.steps[0].id);
    onRootChange?.(fresh.key);
    onTuningChange?.(fresh.tuning);
    setLoop(true);
    setPreviewVolume(75);
    setStudyView('neck');
    focusStudy();
    setSequence('');
    setSequenceError('');
    setPlayScope(null);
    setTemplate('metal-minor');
    setGenre('Metal');
    setComposerMode('sequence');
    setPendingLoad(null);
    setResetRequested(false);
    setResetEpoch((value) => value + 1);
    setFeedback(
      'Workshop defaults restored. Your saved progressions and handedness are preserved.',
    );
  };
  const stayInArea = () => {
    const minFret = Math.min(19, draft.minFret);
    update({ runRange: 'octaves', minFret, maxFret: minFret + 5 });
    focusStudy();
  };
  const writeWholeNeckRun = () => {
    update({
      runRange: 'full-neck',
      minFret: 0,
      maxFret: 24,
      strings: 'all',
      steps: draft.steps.map((step) => ({ ...step, pattern: 'up' })),
    });
    setStudyView('neck');
    focusStudy();
    setFeedback(
      'Whole-neck run plays once to the last string. Choose Up & down for a return trip.',
    );
    setLoop(false);
  };
  const addChord = (chord = { offset: 0, quality: 'major' }) => {
    if (atLimit) return;
    const item = { inversion: 0, bars: 1, pattern: 'up-down', ...chord, id: draft.nextId };
    const steps = [...draft.steps];
    steps.splice(selectedIndex + 1, 0, item);
    update({ steps, nextId: draft.nextId + 1 });
    setSelectedId(item.id);
  };
  const removeChord = () => {
    if (draft.steps.length <= 1) return;
    update({ steps: draft.steps.filter((step) => step.id !== selected.id) });
    setSelectedId(draft.steps[Math.max(0, selectedIndex - 1)].id);
  };
  const moveChord = (direction) => {
    const target = selectedIndex + direction;
    if (target < 0 || target >= draft.steps.length) return;
    const steps = [...draft.steps];
    [steps[selectedIndex], steps[target]] = [steps[target], steps[selectedIndex]];
    update({ steps });
  };
  const applyLoad = () => {
    preview.stop();
    const loaded = normalizeArpeggioProgression(pendingLoad);
    setDraft(loaded);
    setSelectedId(loaded.steps[0].id);
    onRootChange?.(loaded.key);
    onTuningChange?.(loaded.tuning);
    setPendingLoad(null);
    setFeedback(`Loaded ${loaded.name}.`);
  };
  const save = () => {
    try {
      const document = normalizeArpeggioProgression({
        ...draft,
        name: saveName,
        key: root,
        tuning,
      });
      const previous = library.findIndex((item) => item.name === saveName);
      if (previous < 0 && library.length >= 12)
        throw new Error(
          'Your 12 save slots are full. Use an existing name or download a progression file.',
        );
      const nextLibrary =
        previous < 0
          ? [...library, document]
          : library.map((item, index) => (index === previous ? document : item));
      localStorage.setItem(ARPEGGIO_STORAGE_KEY, JSON.stringify(nextLibrary));
      setLibrary(nextLibrary);
      setSavedChoice(saveName);
      setFeedback(
        `Saved ${saveName} on this device. Download a progression file for a portable copy.`,
      );
    } catch (error) {
      setFeedback(error.message || 'Could not save here. Download a progression file instead.');
    }
  };
  const importFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      if (file.size > 131072) throw new Error('Choose a progression file smaller than 128 KB.');
      setPendingLoad(normalizeArpeggioProgression(JSON.parse(await file.text())));
    } catch (error) {
      setFeedback(`Could not import this progression. ${error.message}`);
    } finally {
      event.target.value = '';
    }
  };
  const exportFile = (kind) => {
    try {
      const document = normalizeArpeggioProgression({ ...draft, key: root, tuning });
      if (kind === 'midi') download(arpeggioMidi(document), 'audio/midi', `${fileName}.mid`);
      else if (kind === 'tab')
        download(
          arpeggioTab(
            document,
            root,
            tuning,
            studyView === 'progression' ? null : document.steps[selectedIndex].id,
          ),
          'text/plain;charset=utf-8',
          `${fileName}-tab.txt`,
        );
      else
        download(
          JSON.stringify(document, null, 2),
          'application/json',
          `${fileName}.cassian-arpeggios.json`,
        );
      setFeedback(
        kind === 'tab'
          ? 'Complete tablature prepared, including every note of the run and its return.'
          : kind === 'midi'
            ? 'MIDI file prepared with the current notes, tempo and time signature.'
            : 'Portable progression file prepared. Import it here to continue editing.',
      );
    } catch (error) {
      setFeedback(error.message);
    }
  };
  const hearChord = () =>
    playReference(
      selectedPath.map((note, index) => ({
        ...note,
        tick: index * pulse,
        duration: pulse * 0.82,
        stepId: selected.id,
        pathIndex: index,
      })),
      { tempo: draft.tempo, totalTicks: selectedPath.length * pulse },
    );
  return (
    <div className="arp-workspace" inert={bandSending}>
      <section className="arp-panel arp-sequence-panel" aria-label="Progression playback">
        <div className="arp-heading">
          <div>
            <span className="arp-eyebrow">THE ARPEGGIO WORKSHOP</span>
            <h2>Build a progression. Play it through.</h2>
          </div>
          <div className="arp-source-tabs" role="group" aria-label="Progression source">
            <button
              type="button"
              aria-pressed={composerMode === 'sequence'}
              onClick={() => setComposerMode('sequence')}
            >
              Type chords
            </button>
            <button
              type="button"
              aria-pressed={composerMode === 'genre'}
              onClick={() => setComposerMode('genre')}
            >
              Genre presets
            </button>
          </div>
          <button
            type="button"
            onClick={() => {
              preview.stop();
              setResetRequested(true);
            }}
          >
            Reset defaults
          </button>
          <span className="arp-key-stamp">
            {NOTE_NAMES[root]} · {draft.steps.length} CHORDS · {draft.meter}
          </span>
        </div>
        {composerMode === 'sequence' ? (
          <div className="arp-quick-sequence">
            <label htmlFor={`${formId}-sequence`}>
              Chord sequence
              <input
                id={`${formId}-sequence`}
                value={sequence}
                maxLength={256}
                placeholder="E C D B · or ECDB"
                aria-invalid={!!sequenceError}
                aria-describedby={`${formId}-sequence-help`}
                onChange={(event) => {
                  setSequence(event.target.value);
                  setSequenceError('');
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    event.preventDefault();
                    applyChordSequence();
                  }
                }}
              />
            </label>
            <button type="button" onClick={() => applyChordSequence()} disabled={!sequence.trim()}>
              Apply sequence
            </button>
            <button
              type="button"
              onClick={() => applyChordSequence(true)}
              disabled={!sequence.trim() || atLimit}
            >
              Append sequence
            </button>
          </div>
        ) : (
          <div className="arp-quick-sequence arp-genre-picker">
            <label htmlFor={`${formId}-genre`}>
              Genre
              <select
                id={`${formId}-genre`}
                value={genre}
                onChange={(event) => {
                  const next = event.target.value;
                  setGenre(next);
                  setTemplate(ARPEGGIO_TEMPLATES.find((item) => item.genre === next).id);
                }}
              >
                {ARPEGGIO_GENRES.map((name) => (
                  <option key={name}>{name}</option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-genre-template`}>
              Progression
              <select
                id={`${formId}-genre-template`}
                value={chosenTemplate.id}
                onChange={(event) => setTemplate(event.target.value)}
              >
                {genreTemplates.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </label>
            <button type="button" onClick={applyGenreProgression}>
              Use progression
            </button>
          </div>
        )}
        <p className="arp-note" id={`${formId}-sequence-help`}>
          {composerMode === 'sequence'
            ? 'Use ECDB or Em7 Cmaj7 D B7. Apply replaces; Append adds.'
            : [
                `${genre} · ${genreTemplates.length} progressions · ${chosenTemplate.formula}.`,
                'Loads in your current key; every chord is editable.',
              ].join(' ')}
        </p>
        {resetRequested && (
          <div
            className="arp-reset-confirm arp-load-confirm"
            role="group"
            aria-label="Reset workshop defaults"
          >
            <p>
              Restore the starter progression, E key, Standard E tuning, 90 BPM, 4/4, one-octave
              studies and looping? Your saved progressions and left-handed preference stay.
            </p>
            <div className="arp-actions">
              <button type="button" onClick={() => setResetRequested(false)}>
                Cancel reset
              </button>
              <button type="button" onClick={resetDefaults}>
                Restore defaults
              </button>
            </div>
          </div>
        )}
        {sequenceError && (
          <p className="arp-warning" role="alert">
            {sequenceError}
          </p>
        )}
        <ol className="arp-progression" aria-label="Arpeggio progression">
          {draft.steps.map((step, index) => (
            <li key={step.id}>
              <button
                type="button"
                aria-pressed={selected.id === step.id}
                className={preview.active?.stepId === step.id ? 'is-playing' : ''}
                onClick={() => {
                  preview.stop();
                  setSelectedId(step.id);
                  focusStudy();
                }}
                aria-label={`Edit chord ${index + 1}, ${arpeggioName(root, step)}`}
              >
                <span>CHORD {String(index + 1).padStart(2, '0')}</span>
                <strong>{arpeggioName(root, step)}</strong>
                <small>
                  {stepBars(index)} {stepBars(index) === 1 ? 'bar' : 'bars'} ·{' '}
                  {getArpeggioQuality(step.quality).degrees[step.inversion]} in bass
                </small>
              </button>
            </li>
          ))}
        </ol>
        <details className="arp-order-tools">
          <summary>Add, move or remove chords</summary>
          <div className="arp-actions">
            <button type="button" onClick={() => addChord()} disabled={atLimit}>
              + Add chord
            </button>
            <button type="button" onClick={() => addChord(selected)} disabled={atLimit}>
              Duplicate chord
            </button>
            <button type="button" onClick={() => moveChord(-1)} disabled={selectedIndex === 0}>
              Move earlier
            </button>
            <button
              type="button"
              onClick={() => moveChord(1)}
              disabled={selectedIndex === draft.steps.length - 1}
            >
              Move later
            </button>
            <button type="button" onClick={removeChord} disabled={draft.steps.length === 1}>
              Remove chord
            </button>
            <span className="arp-note">{draft.steps.length} / 32 chords</span>
          </div>
        </details>
      </section>
      <div
        className={'arp-study-layout' + (draft.runRange === 'full-neck' ? ' is-full-neck' : '')}
        ref={studyPane}
      >
        <section className="arp-panel arp-editor-panel" aria-label="Chord study controls">
          <div className="arp-heading">
            <div>
              <span className="arp-eyebrow">CHANGE IT. SEE IT.</span>
              <h3>Shape the next chord.</h3>
            </div>
          </div>
          <div className="arp-chord-editor" role="group" aria-label="Selected chord settings">
            <label htmlFor={`${formId}-study-key`}>
              Progression key
              <select
                id={`${formId}-study-key`}
                value={root}
                onChange={(event) => {
                  preview.stop();
                  onRootChange?.(Number(event.target.value));
                }}
              >
                {LEARN_KEYS.map((key) => (
                  <option key={key.value} value={key.value}>
                    {key.name}
                  </option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-5`}>
              Chord root
              <select
                id={`${formId}-field-5`}
                value={chordRoot}
                onChange={(event) =>
                  updateStep({ offset: pitchClass(Number(event.target.value) - root) })
                }
              >
                {LEARN_KEYS.map((key) => (
                  <option key={key.value} value={key.value}>
                    {key.name}
                  </option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-6`}>
              Chord type
              <select
                id={`${formId}-field-6`}
                value={selectedQuality.id}
                onChange={(event) => updateStep({ quality: event.target.value, inversion: 0 })}
              >
                {ARPEGGIO_QUALITIES.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-7`}>
              Starting tone / inversion
              <select
                id={`${formId}-field-7`}
                value={selected.inversion}
                onChange={(event) => updateStep({ inversion: Number(event.target.value) })}
              >
                {chordTones.map((tone, index) => (
                  <option key={tone.degree} value={index}>
                    {index === 0
                      ? 'Root position'
                      : index === 1
                        ? 'First inversion'
                        : index === 2
                          ? 'Second inversion'
                          : index === 3
                            ? 'Third inversion'
                            : 'Start on ' + tone.degree}{' '}
                    · {tone.name}
                  </option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-8`}>
              Picking pattern
              <select
                id={`${formId}-field-8`}
                value={selected.pattern}
                onChange={(event) => updateStep({ pattern: event.target.value })}
              >
                {ARPEGGIO_PATTERNS.map((pattern) => (
                  <option key={pattern.id} value={pattern.id}>
                    {pattern.name}
                  </option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-9`}>
              {draft.runRange === 'full-neck' ? 'Minimum bars on this chord' : 'Bars on this chord'}
              <select
                id={`${formId}-field-9`}
                value={selected.bars}
                onChange={(event) => updateStep({ bars: Number(event.target.value) })}
              >
                {Array.from({ length: 8 }, (_, index) => (
                  <option key={index} value={index + 1}>
                    {index + 1}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <details className="arp-harmony-details">
            <summary>Chord tones &amp; connections</summary>
            <div className="arp-tone-strip" aria-label="Selected chord tones">
              {chordTones.map((tone) => (
                <span key={tone.degree}>
                  <b>{tone.name}</b>
                  <small>{tone.degree}</small>
                </span>
              ))}
              <p>
                {selectedQuality.name} · {selectedQuality.degrees.join(' – ')}
              </p>
            </div>
            <div className="arp-connection">
              <b>Into {arpeggioName(root, next)}</b>
              <span>
                {connection.shared.length
                  ? 'Shared tones: ' + connection.shared.join(' · ')
                  : 'No shared chord tones.'}
              </span>
              {connection.motion && (
                <span>
                  Try {connection.motion.from} → {connection.motion.to} ·{' '}
                  {connection.motion.distance}{' '}
                  {connection.motion.distance === 1 ? 'semitone' : 'semitones'}
                </span>
              )}
            </div>
            <p className="arp-note">
              The lesson key transposes the whole progression. Chord roots can move freely,
              including chords outside the key.
            </p>
          </details>
          <details className="arp-timing-options">
            <summary>Progression name &amp; saved settings</summary>
            <div className="arp-setup">
              <label htmlFor={`${formId}-field-1`}>
                Progression name
                <input
                  id={`${formId}-field-1`}
                  maxLength={80}
                  value={draft.name}
                  onChange={(event) => update({ name: event.target.value })}
                />
              </label>
            </div>
          </details>
        </section>
        <section className="arp-panel arp-neck-panel" aria-label="Arpeggio fingering and playback">
          <div className="arp-heading">
            <div>
              <span className="arp-eyebrow">PUT IT UNDER YOUR FINGERS</span>
              <h3>{arpeggioName(root, selected)} · the playable route</h3>
            </div>
            {draft.runRange === 'full-neck' && (
              <button type="button" onClick={stayInArea}>
                Stay in this area
              </button>
            )}
            {draft.runRange === 'full-neck' && (
              <button
                type="button"
                onClick={() =>
                  studyPane.current
                    ?.querySelector('.arp-editor-panel')
                    ?.scrollIntoView({ block: 'start' })
                }
              >
                Chord settings
              </button>
            )}
            <label className="arp-check" htmlFor={`${formId}-field-10`}>
              <input
                id={`${formId}-field-10`}
                type="checkbox"
                checked={leftHanded}
                onChange={(event) => { setLeftHanded(event.target.checked); onLeftHandedChange?.(event.target.checked); }}
              />
              Left-handed view
            </label>
          </div>
          <div
            className="arp-playback-settings"
            role="group"
            aria-label="Playback timing and volume"
          >
            <div className="arp-tempo-control">
              <DraftDial
                label="Tempo"
                caption="Tempo"
                value={draft.tempo}
                min={40}
                max={240}
                step={1}
                fineStep={1}
                onChange={(tempo) => {
                  setTempoText(null);
                  update({ tempo });
                }}
              />
              <label className="arp-tempo-field" htmlFor={`${formId}-field-2`}>
                BPM
                <input
                  aria-label="Quarter-note BPM"
                  id={`${formId}-field-2`}
                  type="number"
                  className="arp-bpm-input"
                  min={40}
                  max={240}
                  value={tempoText ?? String(draft.tempo)}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') event.currentTarget.blur();
                  }}
                  onChange={(event) => {
                    setTempoText(event.target.value);
                    if (event.target.value) {
                      const tempo = Number(event.target.value);
                      if (Number.isFinite(tempo) && tempo >= 40 && tempo <= 240) update({ tempo });
                    }
                  }}
                  onBlur={() => setTempoText(null)}
                />
              </label>
            </div>
            <label htmlFor={`${formId}-field-3`}>
              Time signature
              <select
                id={`${formId}-field-3`}
                value={draft.meter}
                onChange={(event) => update({ meter: event.target.value })}
              >
                {ARPEGGIO_METERS.map((meter) => (
                  <option key={meter}>{meter}</option>
                ))}
              </select>
            </label>
            <label htmlFor={`${formId}-field-4`}>
              Note spacing
              <select
                id={`${formId}-field-4`}
                value={draft.rate}
                onChange={(event) => update({ rate: event.target.value })}
              >
                {ARPEGGIO_RATES.map((rate) => (
                  <option key={rate.id} value={rate.id}>
                    {rate.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="arp-preview-volume" htmlFor={`${formId}-preview-volume`}>
              Guitar volume · {previewVolume}%
              <input
                id={`${formId}-preview-volume`}
                type="range"
                min="0"
                max="100"
                value={previewVolume}
                onChange={(event) => setPreviewVolume(Number(event.target.value))}
              />
            </label>
          </div>
          <div className="arp-sequence-transport">
            <button
              className="arp-primary"
              type="button"
              disabled={!!compiled.missing.length}
              onClick={() =>
                playReference(
                  compiled.events,
                  { tempo: draft.tempo, totalTicks: compiled.totalTicks, loop },
                  'progression',
                )
              }
            >
              Play progression
            </button>
            <button type="button" onClick={preview.stop} disabled={!preview.playing}>
              Stop progression
            </button>
            <label className="arp-check" htmlFor={`${formId}-loop-progression`}>
              <input
                id={`${formId}-loop-progression`}
                type="checkbox"
                checked={loop}
                onChange={(event) => {
                  preview.stop();
                  setLoop(event.target.checked);
                }}
              />
              Loop progression
            </label>

            <span role="status" aria-label="Progression playback status">
              {preview.playing && playScope === 'progression'
                ? playingStep >= 0
                  ? `Playing ${playingStep + 1}/${draft.steps.length} · ${arpeggioName(root, draft.steps[playingStep])}`
                  : 'Starting progression…'
                : studyStep >= 0
                  ? `Finished on ${arpeggioName(root, draft.steps[studyStep])}. Press Play to start again.`
                  : `Plays left to right${loop ? ', then repeats from the first chord' : ', once through'}.`}
            </span>
          </div>
          <div className="arp-study-view" role="group" aria-label="Study display">
            {[
              ['neck', 'Fretboard'],
              ['tab', 'Tablature'],
              ['both', 'Both'],
              ['progression', 'Progression tab'],
            ].map(([id, label]) => (
              <button
                type="button"
                key={id}
                aria-pressed={studyView === id}
                onClick={() => setStudyView(id)}
              >
                {label}
              </button>
            ))}
            {draft.runRange !== 'full-neck' && (
              <button
                type="button"
                aria-pressed={draft.runRange !== 'full-neck'}
                onClick={stayInArea}
              >
                Stay in this area
              </button>
            )}
            <button
              type="button"
              className="arp-run-button"
              onClick={writeWholeNeckRun}
              aria-pressed={draft.runRange === 'full-neck'}
            >
              Whole-neck run
            </button>
          </div>
          {draft.runRange !== 'full-neck' && (
            <label className="arp-fret-area" htmlFor={`${formId}-fret-area`}>
              Fret area
              <select
                id={`${formId}-fret-area`}
                value={draft.maxFret - draft.minFret === 5 ? draft.minFret : 'custom'}
                onChange={(event) => {
                  if (event.target.value === 'custom') return;
                  const minFret = Number(event.target.value);
                  update({ minFret, maxFret: minFret + 5 });
                  focusStudy();
                }}
              >
                <option value="custom">
                  Custom · {draft.minFret}–{draft.maxFret}
                </option>
                {Array.from({ length: 20 }, (_, fret) => (
                  <option key={fret} value={fret}>
                    {fret}–{fret + 5}
                  </option>
                ))}
              </select>
            </label>
          )}
          {draft.runRange === 'full-neck' && (
            <p className="arp-note arp-run-summary">
              {getLearnTuning(tuning).notes.length} strings · frets {draft.minFret}–{draft.maxFret}{' '}
              · {selectedPath.length} notes in this run. Each run plays once, then rests to the next
              chord. Choose Up &amp; down for the return; looping is optional.
            </p>
          )}
          <details className="arp-neck-options">
            <summary>Fret range, tuning &amp; strings</summary>
            <div className="arp-controls">
              <label htmlFor={`${formId}-field-11`}>
                Arpeggio tuning
                <select
                  id={`${formId}-field-11`}
                  value={tuning}
                  onChange={(event) => {
                    preview.stop();
                    onTuningChange?.(event.target.value);
                  }}
                >
                  {LEARN_TUNINGS.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </label>
              <label htmlFor={`${formId}-field-12`}>
                Lowest fret
                <select
                  id={`${formId}-field-12`}
                  value={draft.minFret}
                  onChange={(event) => {
                    const minFret = Number(event.target.value);
                    update({ minFret, maxFret: Math.max(draft.maxFret, minFret + 3) });
                  }}
                >
                  {Array.from({ length: 20 }, (_, index) => (
                    <option key={index}>{index}</option>
                  ))}
                </select>
              </label>
              <label htmlFor={`${formId}-field-13`}>
                Highest fret
                <select
                  id={`${formId}-field-13`}
                  value={draft.maxFret}
                  onChange={(event) => update({ maxFret: Number(event.target.value) })}
                >
                  {Array.from({ length: 24 - draft.minFret - 2 }, (_, index) => (
                    <option key={index}>{draft.minFret + 3 + index}</option>
                  ))}
                </select>
              </label>
              <label htmlFor={`${formId}-field-14`}>
                String set
                <select
                  id={`${formId}-field-14`}
                  value={draft.strings}
                  onChange={(event) => update({ strings: event.target.value })}
                >
                  <option value="all">All strings</option>
                  <option value="upper3">Upper 3 strings</option>
                  <option value="upper4">Upper 4 strings</option>
                  <option value="lower4">Lower 4 strings</option>
                </select>
              </label>
              <label htmlFor={`${formId}-field-15`}>
                Range
                <select
                  id={`${formId}-field-15`}
                  value={draft.runRange === 'full-neck' ? 'full-neck' : draft.octaves}
                  onChange={(event) =>
                    event.target.value === 'full-neck'
                      ? writeWholeNeckRun()
                      : update({ runRange: 'octaves', octaves: Number(event.target.value) })
                  }
                >
                  <option value={1}>One octave</option>
                  <option value={2}>Two octaves</option>
                  <option value="full-neck">Whole neck · all available octaves</option>
                </select>
              </label>
            </div>
            <div className="arp-actions">
              <label className="arp-check" htmlFor={`${formId}-field-16`}>
                <input
                  id={`${formId}-field-16`}
                  type="checkbox"
                  checked={draft.connect}
                  onChange={(event) => update({ connect: event.target.checked })}
                />
                Keep chord changes in a nearby register
              </label>
            </div>
          </details>
          {!selectedPath.length && (
            <p className="arp-warning" role="status">
              This chord needs more room. Widen the fret window, choose more strings or try one
              octave. No notes are silently dropped.
            </p>
          )}
          {studyView === 'progression' ? (
            <label className="arp-complete-tab-label" htmlFor={`${formId}-complete-tab`}>
              Complete progression tablature
              <textarea
                id={`${formId}-complete-tab`}
                className="arp-complete-tab"
                readOnly
                rows={16}
                spellCheck={false}
                value={progressionTab}
              />
            </label>
          ) : (
            <ArpeggioNeck
              overview={draft.runRange === 'full-neck'}
              view={studyView}
              path={selectedPath}
              tuning={tuning}
              minFret={draft.minFret}
              maxFret={draft.maxFret}
              leftHanded={leftHanded}
              active={preview.active?.stepId === selected.id ? preview.active : null}
              onPlayNote={(note) =>
                playReference([{ ...note, tick: 0, duration: 400, stepId: selected.id }], {
                  tempo: draft.tempo,
                  totalTicks: 480,
                })
              }
            />
          )}
          <div className="arp-transport">
            <div className="arp-actions">
              <button
                className="arp-primary"
                type="button"
                onClick={hearChord}
                disabled={!selectedPath.length}
              >
                Hear this arpeggio
              </button>
              <button type="button" onClick={preview.stop} disabled={!preview.playing}>
                Stop reference
              </button>
              <button
                type="button"
                onClick={() => exportFile('tab')}
                disabled={
                  studyView === 'progression' ? !!compiled.missing.length : !selectedPath.length
                }
              >
                {studyView === 'progression' ? 'Save progression tab' : 'Save run tab'}
              </button>
            </div>
            <span role="status">{preview.playing ? 'Reference playing' : 'Ready to practise'}</span>
          </div>
          <p className="arp-note">
            {native
              ? 'Clean guitar plays through Cassian’s audio engine and selected interface.'
              : 'Browser reference uses a simple tone. Recorded clean guitar plays in standalone Cassian.'}{' '}
            Guitar volume controls this example. Your rig, Band and recording stay unchanged.
            {native && <span> Clean guitar recordings: FreePats FSBS · CC0.</span>}
          </p>
          {!!compiled.missing.length && (
            <p className="arp-warning">
              {compiled.missing.length}{' '}
              {compiled.missing.length === 1 ? 'chord needs' : 'chords need'} a wider range.
              Progression playback and MIDI export wait until every chord has a route.
            </p>
          )}
          {preview.error && (
            <p className="arp-warning" role="alert">
              {preview.error}
            </p>
          )}
          <ArpeggioBandSend
            key={resetEpoch}
            draft={draft}
            root={root}
            tuning={tuning}
            genre={genre}
            status={status}
            onNavigate={onNavigate}
            onError={onError}
            onBusyChange={handleBandBusy}
            onStopReference={preview.stop}
          />
        </section>
      </div>
      <section className="arp-panel" aria-label="Save and load arpeggio progressions">
        <div className="arp-heading">
          <div>
            <span className="arp-eyebrow">KEEP THE GOOD IDEAS</span>
            <h3>Your progression notebook.</h3>
          </div>
          <p>Saved locally. Portable files and MIDI stay yours.</p>
        </div>
        <div className="arp-controls">
          <label htmlFor={`${formId}-field-19`}>
            Saved progressions
            <select
              id={`${formId}-field-19`}
              value={savedChoice}
              onChange={(event) => setSavedChoice(event.target.value)}
            >
              <option value="">Choose a saved progression</option>
              {library.map((item) => (
                <option key={item.name} value={item.name}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            disabled={!savedChoice}
            onClick={() => {
              preview.stop();
              setPendingLoad(library.find((item) => item.name === savedChoice));
            }}
          >
            Load saved progression
          </button>
        </div>
        <div className="arp-actions">
          <button className="arp-primary" type="button" onClick={save}>
            Save progression
          </button>
          <button type="button" onClick={() => exportFile('json')}>
            Download progression
          </button>
          <button type="button" onClick={() => fileInput.current?.click()}>
            Import progression
          </button>
          <button
            type="button"
            disabled={!!compiled.missing.length}
            onClick={() => exportFile('midi')}
          >
            Export MIDI
          </button>
          <input
            ref={fileInput}
            type="file"
            accept=".json,application/json"
            hidden
            onChange={importFile}
            aria-label="Import arpeggio progression file"
          />
        </div>
        {pendingLoad && (
          <div
            className="arp-load-confirm"
            role="group"
            aria-label="Confirm progression replacement"
          >
            <p>
              Replace the current draft with <strong>{pendingLoad.name}</strong>? Save or download
              your current draft first if you want to keep it.
            </p>
            <div className="arp-actions">
              <button type="button" onClick={() => setPendingLoad(null)}>
                Keep current draft
              </button>
              <button type="button" onClick={applyLoad}>
                Replace draft
              </button>
            </div>
          </div>
        )}
        <p className="arp-feedback" role="status">
          {feedback ||
            'Your draft stays here when switching tabs. Save it before closing the app. Saving ' +
              'an existing name updates that saved progression.'}
        </p>
      </section>
      <ArpeggioFoundations
        root={root}
        disabled={atLimit}
        onAddChord={addChord}
        onHear={(events, options) => playReference(events, options, 'ear')}
        stop={preview.stop}
      />
    </div>
  );
}
