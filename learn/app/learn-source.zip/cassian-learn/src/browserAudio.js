// Synthetic reference audio only. No recordings, neural model, microphone or native bridge.
export const midiFrequency = (midi) => 440 * 2 ** ((midi - 69) / 12);
export function scheduleReference(
  context,
  midi,
  at,
  duration = 0.65,
  amplitude = 0.1,
) {
  if (!Number.isInteger(midi) || midi < 0 || midi > 127)
    throw Error("Invalid reference note.");
  const oscillator = context.createOscillator(),
    gain = context.createGain();
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(midiFrequency(midi), at);
  gain.gain.setValueAtTime(0, at);
  gain.gain.linearRampToValueAtTime(amplitude, at + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(at);
  oscillator.stop(at + duration + 0.01);
  return { oscillator, gain };
}
export function createBrowserAudio({
  contextFactory,
  onError = () => {},
} = {}) {
  let context,
    timer,
    nextBeat,
    beat = 0,
    tempo = 80,
    disposed = false,
    generation = 0;
  const voices = new Set();
  const add = (voice) => {
    voices.add(voice);
    voice.oscillator.onended = () => {
      voice.oscillator.disconnect();
      voice.gain.disconnect();
      voices.delete(voice);
    };
  };
  const running = async () => {
    if (disposed) throw Error("Reference audio has been closed.");
    if (!context) {
      const Constructor =
        globalThis.AudioContext ?? globalThis.webkitAudioContext;
      if (!contextFactory && !Constructor)
        throw Error("Reference audio is unavailable in this browser.");
      context = contextFactory ? contextFactory() : new Constructor();
    }
    if (context.state !== "running") await context.resume();
    if (disposed || context.state !== "running")
      throw Error("Allow audio playback, then try again.");
    return context;
  };
  const stopPulse = () => {
    clearInterval(timer);
    timer = null;
  };
  const stop = () => {
    generation++;
    stopPulse();
    for (const voice of voices) {
      try {
        voice.oscillator.stop();
      } catch {
        /* Already finished. */
      }
      voice.oscillator.disconnect();
      voice.gain.disconnect();
    }
    voices.clear();
  };
  return {
    async playNotes(notes) {
      if (!Array.isArray(notes) || !notes.length || notes.length > 8)
        throw Error("Choose a reference note.");
      const admitted = generation,
        audio = await running();
      if (admitted !== generation) return false;
      notes.forEach((midi, index) =>
        add(
          scheduleReference(
            audio,
            midi,
            audio.currentTime + 0.02 + index * 0.12,
          ),
        ),
      );
      return true;
    },
    async startPulse(value) {
      this.setTempo(value);
      const admitted = generation,
        audio = await running();
      if (admitted !== generation) return false;
      stopPulse();
      beat = 0;
      nextBeat = audio.currentTime + 0.04;
      const tick = () => {
        if (audio.state !== "running") {
          stop();
          onError(Error("Audio playback was interrupted."));
          return;
        }
        while (nextBeat < audio.currentTime + 0.12) {
          add(
            scheduleReference(
              audio,
              beat++ % 4 === 0 ? 81 : 76,
              nextBeat,
              0.045,
              0.045,
            ),
          );
          nextBeat += 60 / tempo;
        }
      };
      tick();
      timer = setInterval(tick, 25);
      return true;
    },
    setTempo(value) {
      if (!Number.isInteger(value) || value < 40 || value > 200)
        throw Error("Choose 40–200 BPM.");
      tempo = value;
    },
    stop,
    dispose() {
      disposed = true;
      stop();
      if (context && context.state !== "closed") context.close();
    },
  };
}
