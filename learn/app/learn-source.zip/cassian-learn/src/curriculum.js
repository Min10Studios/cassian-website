import pathwayData from "./pathwayData.json";
import { rhythmGenres } from "./rhythmGenres.js";

// Pitch classes follow Cassian's Band key contract: C = 0, E = 4, B = 11.
export const LEARN_NOTE_NAMES = [
  "C",
  "C#",
  "D",
  "Eb",
  "E",
  "F",
  "F#",
  "G",
  "Ab",
  "A",
  "Bb",
  "B",
];
export const STANDARD_OPEN_PITCHES = [4, 9, 2, 7, 11, 4];
export const STRING_NAMES = ["E", "A", "D", "G", "B", "e"];
export const pitchClass = (value) => ((Number(value) % 12) + 12) % 12;
export const noteName = (value) => LEARN_NOTE_NAMES[pitchClass(value)];
const naturalLetters = ["C", "D", "E", "F", "G", "A", "B"];
const naturalPitches = [0, 2, 4, 5, 7, 9, 11];
function spellFromRoot(rootName, soundingPitch, letterSteps) {
  const letterIndex = (naturalLetters.indexOf(rootName[0]) + letterSteps) % 7;
  const difference = pitchClass(soundingPitch - naturalPitches[letterIndex]);
  const accidental = difference > 6 ? difference - 12 : difference;
  return (
    naturalLetters[letterIndex] +
    (accidental > 0 ? "#".repeat(accidental) : "b".repeat(-accidental))
  );
}
// Keep functional chord names diatonic to the key: B major's vi is G#m,
// while Ab major's vi is Fm. Pitch-class labels alone cannot make that choice.
export function noteNameInKey(root, offset) {
  const steps = {
    0: 0,
    1: 1,
    2: 1,
    3: 2,
    4: 2,
    5: 3,
    6: 3,
    7: 4,
    8: 5,
    9: 5,
    10: 6,
    11: 6,
  };
  return spellFromRoot(
    noteName(root),
    pitchClass(root) + offset,
    steps[pitchClass(offset)],
  );
}

export const SCALE_REFERENCE = [
  {
    id: "minor-pentatonic",
    name: "Minor pentatonic",
    formula: "1 · b3 · 4 · 5 · b7",
    intervals: [0, 3, 5, 7, 10],
  },
  {
    id: "major-pentatonic",
    name: "Major pentatonic",
    formula: "1 · 2 · 3 · 5 · 6",
    intervals: [0, 2, 4, 7, 9],
  },
  {
    id: "blues",
    name: "Minor blues",
    formula: "1 · b3 · 4 · b5 · 5 · b7",
    intervals: [0, 3, 5, 6, 7, 10],
  },
  {
    id: "harmonic-minor",
    name: "Harmonic minor",
    formula: "1 · 2 · b3 · 4 · 5 · b6 · 7",
    intervals: [0, 2, 3, 5, 7, 8, 11],
  },
  {
    id: "ionian",
    name: "Ionian / major",
    formula: "1 · 2 · 3 · 4 · 5 · 6 · 7",
    intervals: [0, 2, 4, 5, 7, 9, 11],
  },
  {
    id: "dorian",
    name: "Dorian",
    formula: "1 · 2 · b3 · 4 · 5 · 6 · b7",
    intervals: [0, 2, 3, 5, 7, 9, 10],
  },
  {
    id: "phrygian",
    name: "Phrygian",
    formula: "1 · b2 · b3 · 4 · 5 · b6 · b7",
    intervals: [0, 1, 3, 5, 7, 8, 10],
  },
  {
    id: "lydian",
    name: "Lydian",
    formula: "1 · 2 · 3 · #4 · 5 · 6 · 7",
    intervals: [0, 2, 4, 6, 7, 9, 11],
  },
  {
    id: "mixolydian",
    name: "Mixolydian",
    formula: "1 · 2 · 3 · 4 · 5 · 6 · b7",
    intervals: [0, 2, 4, 5, 7, 9, 10],
  },
  {
    id: "aeolian",
    name: "Aeolian / natural minor",
    formula: "1 · 2 · b3 · 4 · 5 · b6 · b7",
    intervals: [0, 2, 3, 5, 7, 8, 10],
  },
  {
    id: "locrian",
    name: "Locrian",
    formula: "1 · b2 · b3 · 4 · b5 · b6 · b7",
    intervals: [0, 1, 3, 5, 6, 8, 10],
  },
  {
    id: "chromatic",
    name: "Chromatic",
    formula: "All 12 semitones",
    intervals: Array.from({ length: 12 }, (_, i) => i),
  },
];

export function getScaleNoteNames(scaleId, root = 4) {
  const scale = SCALE_REFERENCE.find((item) => item.id === scaleId);
  if (!scale) return [];
  if (scaleId === "chromatic")
    return scale.intervals.map((interval) =>
      noteName(pitchClass(root) + interval),
    );
  const degrees = scale.formula
    .split("·")
    .map((degree) => (Number(degree.replace(/[^0-9]/g, "")) - 1) % 7);
  return scale.intervals.map((interval, index) =>
    spellFromRoot(noteName(root), pitchClass(root) + interval, degrees[index]),
  );
}

// All frets are low E -> high e. A null is a muted string. These are real
// standard-tuning shapes, not interval masks that can be reused in any tuning.
// Open strings become fretted notes when a movable form is shifted.
export const CHORD_SHAPES = {
  major: {
    label: "E form major",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 4,
    frets: [0, 2, 2, 1, 0, 0],
  },
  minor: {
    label: "E form minor",
    suffix: "m",
    intervals: [0, 3, 7],
    baseRoot: 4,
    frets: [0, 2, 2, 0, 0, 0],
  },
  power: {
    label: "Root / fifth / octave",
    suffix: "5",
    intervals: [0, 7],
    baseRoot: 4,
    frets: [0, 2, 2, null, null, null],
  },
  dominant7: {
    label: "E form dominant 7",
    suffix: "7",
    intervals: [0, 4, 7, 10],
    baseRoot: 4,
    frets: [0, 2, 0, 1, 0, 0],
  },
  major7: {
    label: "A form major 7",
    suffix: "maj7",
    intervals: [0, 4, 7, 11],
    baseRoot: 9,
    frets: [null, 0, 2, 1, 2, 0],
  },
  minor7: {
    label: "A form minor 7",
    suffix: "m7",
    intervals: [0, 3, 7, 10],
    baseRoot: 9,
    frets: [null, 0, 2, 0, 1, 0],
  },
  minor9: {
    label: "Minor 9 shell · fifth omitted",
    suffix: "m9",
    intervals: [0, 3, 7, 10, 2],
    baseRoot: 2,
    frets: [null, 5, 3, 5, 5, null],
  },
  dominant9: {
    label: "Dominant 9 shell · fifth omitted",
    suffix: "9",
    intervals: [0, 4, 7, 10, 2],
    baseRoot: 2,
    frets: [null, 5, 4, 5, 5, null],
  },
  dominant7sharp9: {
    label: "Dominant 7#9 · fifth omitted",
    suffix: "7#9",
    intervals: [0, 4, 7, 10, 3],
    baseRoot: 4,
    frets: [null, 7, 6, 7, 8, null],
  },
  sus2: {
    label: "A form suspended 2",
    suffix: "sus2",
    intervals: [0, 2, 7],
    baseRoot: 9,
    frets: [null, 0, 2, 2, 0, 0],
  },
  sus4: {
    label: "A form suspended 4",
    suffix: "sus4",
    intervals: [0, 5, 7],
    baseRoot: 9,
    frets: [null, 0, 2, 2, 3, 0],
  },
  add9: {
    label: "C form add9",
    suffix: "add9",
    intervals: [0, 4, 7, 2],
    baseRoot: 0,
    frets: [null, 3, 2, 0, 3, 0],
  },
  major7Inversion: {
    label: "Major 7 · third in the bass",
    suffix: "maj7",
    bassInterval: 4,
    intervals: [0, 4, 7, 11],
    baseRoot: 0,
    frets: [null, 7, 5, 5, 5, 7],
  },
  major9Inversion: {
    label: "Major 9 · third in bass, root omitted",
    suffix: "maj9",
    bassInterval: 4,
    intervals: [0, 4, 7, 11, 2],
    baseRoot: 0,
    frets: [null, null, 2, 4, 3, 3],
  },
  minor11: {
    label: "Minor 11 · ninth omitted",
    suffix: "m11",
    intervals: [0, 3, 7, 10, 2, 5],
    baseRoot: 9,
    frets: [null, 0, 0, 0, 1, 0],
  },
  cagedC: {
    label: "C form",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 0,
    frets: [null, 3, 2, 0, 1, 0],
  },
  cagedA: {
    label: "A form",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 9,
    frets: [null, 0, 2, 2, 2, 0],
  },
  cagedG: {
    label: "G form",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 7,
    frets: [3, 2, 0, 0, 0, 3],
  },
  cagedE: {
    label: "E form",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 4,
    frets: [0, 2, 2, 1, 0, 0],
  },
  cagedD: {
    label: "D form",
    suffix: "",
    intervals: [0, 4, 7],
    baseRoot: 2,
    frets: [null, null, 0, 2, 3, 2],
  },
};

export function getChordVoicing(shapeId, root = 4) {
  const shape = CHORD_SHAPES[shapeId];
  if (!shape) return null;
  const chordRoot = pitchClass(root);
  const shift = pitchClass(chordRoot - shape.baseRoot);
  const frets = shape.frets.map((fret) =>
    fret === null ? null : fret + shift,
  );
  const slash =
    shape.bassInterval === undefined
      ? ""
      : `/${spellFromRoot(noteName(chordRoot), chordRoot + shape.bassInterval, 2)}`;
  return {
    ...shape,
    id: `${shapeId}-${chordRoot}`,
    shapeId,
    name: `${noteName(chordRoot)}${shape.suffix}${slash}`,
    baseRoot: chordRoot,
    intervals: [...shape.intervals],
    frets,
    tuning: "standard",
  };
}

const open = (id, name, root, intervals, frets) => ({
  id,
  name,
  baseRoot: root,
  intervals,
  frets,
  tuning: "standard",
  label: "Fixed open reference",
});
export const OPEN_CHORDS = [
  open("open-c", "C", 0, [0, 4, 7], [null, 3, 2, 0, 1, 0]),
  open("open-a", "A", 9, [0, 4, 7], [null, 0, 2, 2, 2, 0]),
  open("open-g", "G", 7, [0, 4, 7], [3, 2, 0, 0, 0, 3]),
  open("open-e", "E", 4, [0, 4, 7], [0, 2, 2, 1, 0, 0]),
  open("open-d", "D", 2, [0, 4, 7], [null, null, 0, 2, 3, 2]),
  open("open-am", "Am", 9, [0, 3, 7], [null, 0, 2, 2, 1, 0]),
  open("open-em", "Em", 4, [0, 3, 7], [0, 2, 2, 0, 0, 0]),
  open("open-dm", "Dm", 2, [0, 3, 7], [null, null, 0, 2, 3, 1]),
];

const pentatonicBoxOffsets = [
  [
    [0, 3],
    [0, 2],
    [0, 2],
    [0, 2],
    [0, 3],
    [0, 3],
  ],
  [
    [3, 5],
    [2, 5],
    [2, 5],
    [2, 4],
    [3, 5],
    [3, 5],
  ],
  [
    [5, 7],
    [5, 7],
    [5, 7],
    [4, 7],
    [5, 8],
    [5, 7],
  ],
  [
    [7, 10],
    [7, 10],
    [7, 9],
    [7, 9],
    [8, 10],
    [7, 10],
  ],
  [
    [10, 12],
    [10, 12],
    [9, 12],
    [9, 12],
    [10, 12],
    [10, 12],
  ],
];

export function getPentatonicBoxes(root = 4) {
  const anchor = pitchClass(root - STANDARD_OPEN_PITCHES[0]);
  return pentatonicBoxOffsets.map((strings, i) => ({
    id: `minor-pent-box-${i + 1}`,
    label: `Box ${i + 1}`,
    frets: strings.map((frets) => frets.map((fret) => fret + anchor)),
    baseRoot: pitchClass(root),
    tuning: "standard",
  }));
}

const pathwayDefinitions = pathwayData;

export const PATHWAYS = pathwayDefinitions.map((pathway) => ({
  ...pathway,
  bandGenreId: rhythmGenres.indexOf(pathway.bandGenre),
  closestGroove: Boolean(pathway.closestGroove),
  bandGenreClosest: Boolean(pathway.closestGroove),
  bandNote: pathway.bandNote || `Existing Band groove: ${pathway.bandGenre}.`,
}));

export function buildProgression(pathwayOrId, root = 4) {
  const pathway =
    typeof pathwayOrId === "string"
      ? PATHWAYS.find((item) => item.id === pathwayOrId)
      : pathwayOrId;
  if (!pathway?.progression) return [];
  return pathway.progression.steps.map((item) => ({
    ...item,
    root: pitchClass(pitchClass(root) + item.offset),
    name: `${noteNameInKey(root, item.offset)}${item.suffix}`,
  }));
}

export function getPathwayChords(pathwayOrId, root = 4) {
  const pathway =
    typeof pathwayOrId === "string"
      ? PATHWAYS.find((item) => item.id === pathwayOrId)
      : pathwayOrId;
  return (pathway?.chords || []).map((item) => {
    const voicing = getChordVoicing(
      item.shape,
      pitchClass(pitchClass(root) + item.offset),
    );
    const rootName = noteNameInKey(root, item.offset);
    const slash =
      voicing.bassInterval === undefined
        ? ""
        : `/${spellFromRoot(rootName, voicing.baseRoot + voicing.bassInterval, 2)}`;
    return { ...voicing, name: `${rootName}${voicing.suffix}${slash}` };
  });
}
