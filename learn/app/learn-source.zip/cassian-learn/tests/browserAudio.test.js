import { expect, it, vi } from "vitest";
import {
  createBrowserAudio,
  midiFrequency,
  scheduleReference,
} from "../src/browserAudio.js";
const context = (state = "running") => {
  const nodes = [];
  const audio = {
    state,
    currentTime: 0,
    destination: {},
    resume: vi.fn(),
    close: vi.fn(),
    createOscillator: () => {
      const node = {
        type: "",
        frequency: { setValueAtTime: vi.fn() },
        connect: vi.fn(),
        disconnect: vi.fn(),
        start: vi.fn(),
        stop: vi.fn(),
      };
      nodes.push(node);
      return node;
    },
    createGain: () => ({
      gain: {
        setValueAtTime: vi.fn(),
        linearRampToValueAtTime: vi.fn(),
        exponentialRampToValueAtTime: vi.fn(),
      },
      connect: vi.fn(),
      disconnect: vi.fn(),
    }),
    nodes,
  };
  return audio;
};
it("uses concert-pitch reference frequencies and a finite, attack/release-shaped voice", () => {
  expect(midiFrequency(69)).toBe(440);
  expect(midiFrequency(57)).toBe(220);
  const audio = context();
  const voice = scheduleReference(audio, 69, 1);
  expect(voice.oscillator.frequency.setValueAtTime).toHaveBeenCalledWith(
    440,
    1,
  );
  expect(voice.oscillator.stop).toHaveBeenCalledWith(1.66);
  expect(voice.gain.gain.exponentialRampToValueAtTime).toHaveBeenCalledWith(
    0.0001,
    1.65,
  );
});
it("never reports a blocked browser context as a successful note", async () => {
  const audio = context("suspended");
  const engine = createBrowserAudio({ contextFactory: () => audio });
  await expect(engine.playNotes([69])).rejects.toThrow("Allow audio");
  expect(audio.nodes).toHaveLength(0);
  engine.dispose();
});
it("cancels a delayed unlock and scheduled voices when the host unmounts", async () => {
  const audio = context("suspended");
  let resume;
  audio.resume.mockImplementation(
    () =>
      new Promise((resolve) => {
        resume = () => {
          audio.state = "running";
          resolve();
        };
      }),
  );
  const engine = createBrowserAudio({ contextFactory: () => audio });
  const pending = engine.playNotes([69]);
  engine.dispose();
  resume();
  await expect(pending).rejects.toThrow("Allow audio");
  expect(audio.nodes).toHaveLength(0);
  expect(audio.close).toHaveBeenCalled();
});
