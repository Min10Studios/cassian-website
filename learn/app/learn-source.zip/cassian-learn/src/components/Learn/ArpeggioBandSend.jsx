// Browser scope is explicit; this module never calls the desktop Band. Crazaloth.
export default function ArpeggioBandSend() {
  return <p className="arp-note">Play with Band in Cassian for Windows. Export your progression below, then import it in the desktop Arpeggio workshop.</p>;
}
