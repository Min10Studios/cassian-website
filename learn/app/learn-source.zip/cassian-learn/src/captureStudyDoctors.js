// Original Cassian capture study text. Provenance: Crazaloth.
export const captureStudyDoctors = [
  {
    id: 'gain',
    title: 'Input & listening level',
    summary: 'Hear level and tone as separate observations.',
    explanation:
      'Input changes the signal entering the loaded capture. The visible output and Master ' +
      'controls set level later in the signal path. Match the listening level when ' +
      'comparing two settings.',
    exercise:
      'Play the same phrase at two Input settings. Adjust the visible output control to a ' +
      'similar listening level, then describe the change in attack and sustain.',
  },
  {
    id: 'presence',
    title: 'EQ & routing',
    summary: 'Locate the EQ before changing it.',
    explanation:
      'The preset saves its PRE and POST pedal routing. PRE EQ shapes the signal entering ' +
      'the amp; POST EQ shapes the finished sound. Legacy EQ rows retain their coupled ' +
      'shaping. These studies keep the saved processing models and control values.',
    exercise:
      'Find an EQ already present in the loaded preset. Read its lane and visible band ' +
      'labels, then compare a small change with the original setting.',
  },
  {
    id: 'depth',
    title: 'Capture pedal controls',
    summary: 'Study the controls on the actual pedal face.',
    explanation:
      'Warm Drive, Tight Drive, Classic Distortion and Heavy Distortion capture pedals ' +
      'provide Input, Output and Bypass. The model supplies the captured source tone. Other ' +
      'pedal types have their own visible controls.',
    exercise:
      'On a capture pedal, compare Bypass with the enabled sound. Match Output before ' +
      'judging the change; then make a small Input change and listen again.',
  },
  {
    id: 'gate',
    title: 'Save & compare',
    summary: 'Keep the phrase and monitoring level consistent.',
    explanation:
      'Applying a factory study loads its complete preset. The study preserves its factory ' +
      'control values. Save your own rig before developing a variation, and compare one ' +
      'audible change at a time.',
    exercise:
      'Record one observation about the original sound, make one visible control change, ' +
      'and describe the difference before changing another control.',
  },
];
