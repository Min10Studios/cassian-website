// Crazaloth: selected public Learn copy only; no application catalog.
export const Fretboard_Click_a_fret_to_inspect_Arrow =
  "Click a fret to inspect. Arrow keys move; Home / End reach open / 24. Scroll to explore the full neck.";
export const Fretboard_Fret_window_for_this_tuning_these =
  "Fret window for this tuning; these notes are recalculated from the open strings.";
export const Fretboard_chord_tones_recalculated_for_this_tuning =
  "chord tones recalculated for this tuning. The reference fingering is hidden; it belongs to ";
export const GenreCurriculum_Boxes_describe_locations_they_are_not =
  ". Boxes describe locations; they are not five different scales.";
export const GenreCurriculum_Compare_each_mode_against_the_same =
  "Compare each mode against the same root, ";
export const GenreCurriculum_Essential_open_chords_fixed_concert_keys =
  "Essential open chords · fixed concert keys";
export const GenreCurriculum_Five_connected_minor_pentatonic_boxes =
  "Five connected minor pentatonic boxes · ";
export const GenreCurriculum_Play_one_box_ascending_return_through =
  "Play one box ascending, return through the next, then finish on ";
export const GenreCurriculum_Sixstring_standard_tuning_low_E_at =
  "Six-string standard tuning · strings listed low E to high E; diagrams follow your handedness · × mute · ○ open · R root. A slash names the actual bass note.";
export const GenreCurriculum_The_diagrams_below_remain_E_A =
  "The diagrams below remain E A D G B E references. They do not transpose automatically into ";
export const GenreCurriculum_The_formula_shows_which_notes_changed =
  ". The formula shows which notes changed; a mode gets its sound from its tonal center and the harmony beneath it.";
export const GenreCurriculum_These_eight_references_retain_their_written =
  "These eight references retain their written keys when the selected root changes. Start with one clean note on each string; mute every ×. They are not alternate-tuning diagrams.";
export const GenreCurriculum_Use_the_tuningaware_fretboard_to_find =
  ". Use the tuning-aware fretboard to find chord tones, or return to standard before loading a grip.";
export const GenreCurriculum_major_in_standard_tuning_Their_CAGED =
  " major in standard tuning. Their C–A–G–E–D names describe the source shape. Moving an open form requires fretting its former open strings; use smaller chord fragments before attempting a full barre.";
export const GenreCurriculum_minor_pentatonic_1b345b7_standard_tuning_only =
  " minor pentatonic · 1–b3–4–5–b7 · standard tuning only. Each column lists two notes per string, from low E to high e. Slide between neighboring boxes through a shared note.";
export const GenreCurriculum_the_selected_root_Match_a_mode =
  ", the selected root. Match a mode to its chord root when studying a progression.";
export const ToneAcademy_A_heads_depth_or_resonance_control =
  "A head’s depth or resonance control changes its low-frequency feel; Cassian exposes a dedicated Depth control on Vyper. Bass changes tonal balance. Tight removes low end before distortion, while Dynamic Resonance reduces excessive chug resonance. Those controls do not substitute for a universal power-amp Depth knob.";
export const ToneAcademy_Distortion_and_listening_level_have_different =
  "Distortion and listening level have different jobs.";
export const ToneAcademy_Gain_pushes_the_amplifier_input_into =
  "Gain pushes the amplifier input into clipping and changes sustain, attack and harmonics. Amp Output balances the rig after its gain stages. Cassian’s global Master controls the final listening level, including the backing mix; it is not a modeled power-tube saturation control.";
export const ToneAcademy_Hold_a_chord_and_move_Treble =
  "Hold a chord and move Treble slightly, then return it. Move Presence by the same dB amount and listen to pick bite. Change one control at a time; do not assume equal knob positions sound equal.";
export const ToneAcademy_Lowend_weight_is_different_from_lowend =
  "Low-end weight is different from low-end tightness.";
export const ToneAcademy_Mute_the_strings_and_raise_Threshold =
  "Mute the strings and raise Threshold just above the noise. Then sustain your quietest note. If it cuts off, lower Threshold or lengthen Release. Set input gain correctly first; a gate cannot repair a clipped input.";
export const ToneAcademy_Palmmute_the_lowest_string_If_it =
  "Palm-mute the lowest string. If it blooms too much, raise Tight in small steps before cutting Bass. On a Vyper head, compare Depth separately. Keep the bass instrument audible when deciding how much low end the guitar needs.";
export const ToneAcademy_Play_one_chord_softly_then_hard =
  "Play one chord softly, then hard. Increase amp gain a little and listen for compression and grit. Match the listening level with Amp Output before judging whether the extra gain improved the sound. Learn recipes preserve your global Master.";
export const ToneAcademy_Separate_upperedge_bite_from_the_main =
  "Separate upper-edge bite from the main tone balance.";
export const ToneAcademy_Silence_between_notes_should_not_erase =
  "Silence between notes should not erase note tails.";
export const ToneAcademy_Threshold_decides_when_the_front_gate =
  "Threshold decides when the front gate closes; a higher value such as −50 dB closes sooner than −65 dB. Release controls how quickly it fades shut. A hard clamp helps staccato riffs but can cut quiet taps and sustained notes. Cassian has one front gate, not a separate loop gate.";
export const ToneAcademy_Treble_shapes_the_highfrequency_balance_of =
  "Treble shapes the high-frequency balance of the amp tone section. Presence changes the upper-edge response later in the amp path; the exact behavior depends on the selected Cassian head. Neither control can restore harmonics already removed by a cabinet high cut.";
export const Learn_Move_clockwise_by_fifths_Neighbouring_keys =
  "Move clockwise by fifths. Neighbouring keys share six notes in their major scales. The cadence labels above state major or minor functions; the fretboard mode stays your choice.";
