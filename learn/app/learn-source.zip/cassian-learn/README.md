# Cassian Learn browser module

Original educational content and diagrams: Cassian / Crazaloth, AGPL-3.0-or-later.
Portable adaptation of published source f6e66d9682c5a185f7471328c82ec1be20138edb.
The local integration starts from the published portable source b6758ed0.

Twelve original pathways, a 24-fret neck, chord/CAGED references, pentatonic boxes,
seven modes, circle of fifths, four transposed progression families and tone recipes.
One locally saved handedness setting covers neck and chord geometry without mirrored text.
The original nine guitar tunings remain; eight-string standard is taken from the public
tuner. Four/five-string standard bass tunings are explicit reference-map additions.
Six-string Standard-E chord grips remain clearly identified and do not become bass grips.
Chord/scale note labels follow their written key, including enharmonic octaves.
Opening a lesson reference moves keyboard focus and the view to the selected fretboard.

Synthetic Web Audio reference notes/arpeggios and a four-beat practice pulse require a
user gesture. They are not an amp simulator, microphone tuner, or native Band engine.
Tone recipes can be copied with the Clipboard API, with an honest fallback on rejection.
Lesson completion is a manual practice mark, not an assessment or automatic mastery claim.
Preferences/progress stay in bounded localStorage; no analytics, account or network API.

## Develop and verify

Node and npm are required. Install the exact lockfile dependencies with `npm ci`.

```text
npm test
npm run build
npm run test:browser
npm run dev
```

`build` creates self-contained ES module/CSS, the exact corresponding source ZIP and notices.
Browser checks use headless Edge on Windows or Chromium elsewhere; audio output is muted.
Automated Web Audio assertions do not establish physical speaker/microphone acceptance.

## Host integration

The website owns its main element, H1, navigation, route, header and footer. Mount once
inside an empty `#cassian-learn-root`, then unmount before the route is removed.
The module uses H2 onward, Shadow DOM, natural page height and external same-origin CSS.
It needs no host React installation, CDN, import map, inline script or inline stylesheet.

```js
import { mountCassianLearn } from './app/cassian-learn.js';
const instance = mountCassianLearn(document.querySelector('#cassian-learn-root'), {
  stylesUrl: new URL('./app/cassian-learn.css', import.meta.url).href,
  sourceUrl: new URL('./app/learn-source.zip', import.meta.url).href,
  storageKey: 'cassian.learn.web.v1',
});
// Route cleanup:
instance.unmount();
```

Ship every file explicitly listed by `dist/manifest.json` under `/learn/app/`.
The source ZIP contains only this package's source/tests/build inputs and licenses;
it excludes the desktop app/catalog, banks, model bytes, attachments, evidence and caches.
Keep the source link and AGPL/React notices available when distributing the build.

Theme inherits `--black`, `--surface`, `--panel`, `--white`, `--muted`, `--amber` and `--line`
from the host, with graphite/brass fallbacks. `onEvent` is an optional local callback,
never an automatic analytics request. Events have `schema`, `type` and `detail` fields.
`LearnWeb` is also exported for a future React host; no pending desktop installer is changed.
