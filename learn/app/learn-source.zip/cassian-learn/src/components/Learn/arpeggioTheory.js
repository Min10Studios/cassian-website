import { MORE_ARPEGGIO_PROGRESSIONS } from './arpeggioProgressions.js';
import { guitarStringLabel } from './fretboardTheory.js';
// Original Cassian arpeggio studies and progression model. Crazaloth provenance.
import { getLearnTuning, NOTE_NAMES, pitchClass } from './fretboardTheory.js';
import { noteNameInKey, spellFromRoot, spelledOctave } from './noteSpelling.js';

const quality = (id, name, suffix, intervals, degrees) => ({
  id,
  name,
  suffix,
  intervals,
  degrees,
});
export const ARPEGGIO_QUALITIES = [
  quality('major', 'Major', '', [0, 4, 7], ['1', '3', '5']),
  quality('minor', 'Minor', 'm', [0, 3, 7], ['1', 'b3', '5']),
  quality('diminished', 'Diminished', 'dim', [0, 3, 6], ['1', 'b3', 'b5']),
  quality('augmented', 'Augmented', 'aug', [0, 4, 8], ['1', '3', '#5']),
  quality('sus2', 'Suspended 2', 'sus2', [0, 2, 7], ['1', '2', '5']),
  quality('sus4', 'Suspended 4', 'sus4', [0, 5, 7], ['1', '4', '5']),
  quality('6', 'Major 6', '6', [0, 4, 7, 9], ['1', '3', '5', '6']),
  quality('m6', 'Minor 6', 'm6', [0, 3, 7, 9], ['1', 'b3', '5', '6']),
  quality('maj7', 'Major 7', 'maj7', [0, 4, 7, 11], ['1', '3', '5', '7']),
  quality('m7', 'Minor 7', 'm7', [0, 3, 7, 10], ['1', 'b3', '5', 'b7']),
  quality('7', 'Dominant 7', '7', [0, 4, 7, 10], ['1', '3', '5', 'b7']),
  quality('m7b5', 'Half-diminished 7', 'm7b5', [0, 3, 6, 10], ['1', 'b3', 'b5', 'b7']),
  quality('dim7', 'Diminished 7', 'dim7', [0, 3, 6, 9], ['1', 'b3', 'b5', 'bb7']),
  quality('mMaj7', 'Minor major 7', 'm(maj7)', [0, 3, 7, 11], ['1', 'b3', '5', '7']),
  quality('augMaj7', 'Augmented major 7', 'aug(maj7)', [0, 4, 8, 11], ['1', '3', '#5', '7']),
  quality('7s5', 'Dominant 7 sharp 5', '7#5', [0, 4, 8, 10], ['1', '3', '#5', 'b7']),
  quality('7sus4', 'Dominant 7 suspended 4', '7sus4', [0, 5, 7, 10], ['1', '4', '5', 'b7']),
  quality('add9', 'Add 9', 'add9', [0, 4, 7, 14], ['1', '3', '5', '9']),
  quality('maj9', 'Major 9', 'maj9', [0, 4, 7, 11, 14], ['1', '3', '5', '7', '9']),
  quality('m9', 'Minor 9', 'm9', [0, 3, 7, 10, 14], ['1', 'b3', '5', 'b7', '9']),
  quality('9', 'Dominant 9', '9', [0, 4, 7, 10, 14], ['1', '3', '5', 'b7', '9']),
  quality('7b9', 'Dominant 7 flat 9', '7b9', [0, 4, 7, 10, 13], ['1', '3', '5', 'b7', 'b9']),
  quality('7s9', 'Dominant 7 sharp 9', '7#9', [0, 4, 7, 10, 15], ['1', '3', '5', 'b7', '#9']),
  quality('m11', 'Minor 11', 'm11', [0, 3, 7, 10, 14, 17], ['1', 'b3', '5', 'b7', '9', '11']),
  quality(
    '13',
    'Dominant 13',
    '13',
    [0, 4, 7, 10, 14, 17, 21],
    ['1', '3', '5', 'b7', '9', '11', '13'],
  ),
  quality(
    'maj13',
    'Major 13',
    'maj13',
    [0, 4, 7, 11, 14, 17, 21],
    ['1', '3', '5', '7', '9', '11', '13'],
  ),
  quality(
    'm13',
    'Minor 13',
    'm13',
    [0, 3, 7, 10, 14, 17, 21],
    ['1', 'b3', '5', 'b7', '9', '11', '13'],
  ),
  quality('maj7s11', 'Major 7 sharp 11', 'maj7#11', [0, 4, 7, 11, 18], ['1', '3', '5', '7', '#11']),
];
export const HARMONY_SCALES = [
  { id: 'major', name: 'Major', intervals: [0, 2, 4, 5, 7, 9, 11] },
  { id: 'minor', name: 'Natural minor', intervals: [0, 2, 3, 5, 7, 8, 10] },
  { id: 'harmonic-minor', name: 'Harmonic minor', intervals: [0, 2, 3, 5, 7, 8, 11] },
  { id: 'melodic-minor', name: 'Melodic minor · ascending', intervals: [0, 2, 3, 5, 7, 9, 11] },
];
export const INTERVAL_STUDIES = [
  ['Unison', '1', 0, 'Same pitch'],
  ['Minor second', 'b2', 1, 'One fret'],
  ['Major second', '2', 2, 'Two frets'],
  ['Minor third', 'b3', 3, 'Minor chord colour'],
  ['Major third', '3', 4, 'Major chord colour'],
  ['Perfect fourth', '4', 5, 'Five semitones'],
  ['Tritone', 'b5 / #4', 6, 'Six semitones'],
  ['Perfect fifth', '5', 7, 'Power-chord foundation'],
  ['Minor sixth', 'b6', 8, 'Eight semitones'],
  ['Major sixth', '6', 9, 'Nine semitones'],
  ['Minor seventh', 'b7', 10, 'Dominant and minor 7 colour'],
  ['Major seventh', '7', 11, 'One below the octave'],
  ['Octave', '8', 12, 'Same note name, twelve frets higher'],
];
export const ARPEGGIO_PATTERNS = [
  { id: 'up', name: 'Ascending' },
  { id: 'down', name: 'Descending' },
  { id: 'up-down', name: 'Up & down' },
  { id: 'outside-in', name: 'Outside in' },
  { id: 'rolling-fours', name: 'Rolling groups of four' },
  { id: 'skip-tone', name: '1–3 / 2–4 chord-tone sequences' },
];
export const ARPEGGIO_METERS = ['2/4', '3/4', '4/4', '5/4', '6/8', '7/8'];
export const ARPEGGIO_RATES = [
  { id: 'quarter', name: 'Quarter notes', ticks: 480 },
  { id: 'eighth', name: 'Eighth notes', ticks: 240 },
  { id: 'triplet', name: 'Eighth-note triplets', ticks: 160 },
  { id: 'sixteenth', name: 'Sixteenth notes', ticks: 120 },
];
export const ARPEGGIO_TEMPLATES = [
  {
    id: 'jazz',
    genre: 'Jazz',
    formula: 'ii9 – V13 – Imaj9 – vi7',
    name: 'Extended ii–V–I',
    steps: [
      [2, 'm9'],
      [7, '13'],
      [0, 'maj9'],
      [9, 'm7'],
    ],
  },
  {
    id: 'minor',
    genre: 'Metal',
    formula: 'i9 – iv7 – vii°7 – V7b9',
    name: 'Minor turnaround',
    steps: [
      [0, 'm9'],
      [5, 'm7'],
      [11, 'dim7'],
      [7, '7b9'],
    ],
  },
  {
    id: 'soul',
    genre: 'Funk & Soul',
    formula: 'Imaj9 – iii7 – vi9 – ii11',
    name: 'Soul colours',
    steps: [
      [0, 'maj9'],
      [4, 'm7'],
      [9, 'm9'],
      [2, 'm11'],
    ],
  },
  {
    id: 'pop',
    genre: 'Pop',
    formula: 'I – V – vi – IV',
    name: 'Four-chord foundation',
    steps: [
      [0, 'major'],
      [7, 'major'],
      [9, 'minor'],
      [5, 'major'],
    ],
  },
];
const genreProgression = (id, genre, name, formula, steps) => ({ id, genre, name, formula, steps });
ARPEGGIO_TEMPLATES.push(
  genreProgression('metal-minor', 'Metal', 'Dark minor anthem', 'i – bVI – bVII – i', [
    [0, 'minor'],
    [8, 'major'],
    [10, 'major'],
    [0, 'minor'],
  ]),
  genreProgression('metal-phrygian', 'Metal', 'Phrygian tension', 'i – bII – i – bVII', [
    [0, 'minor'],
    [1, 'major'],
    [0, 'minor'],
    [10, 'major'],
  ]),
  genreProgression('metal-harmonic', 'Metal', 'Harmonic minor drama', 'i – bVI – iv – V7', [
    [0, 'minor'],
    [8, 'major'],
    [5, 'minor'],
    [7, '7'],
  ]),
  genreProgression(
    'metal-progressive',
    'Metal',
    'Progressive colours',
    'i9 – bVImaj7 – iv11 – V7b9',
    [
      [0, 'm9'],
      [8, 'maj7'],
      [5, 'm11'],
      [7, '7b9'],
    ],
  ),
  genreProgression('rock-minor', 'Rock', 'Minor rock lift', 'i – bVII – IV – i', [
    [0, 'minor'],
    [10, 'major'],
    [5, 'major'],
    [0, 'minor'],
  ]),
  genreProgression('rock-anthem', 'Rock', 'Open-chord anthem', 'I – bVII – IV – I', [
    [0, 'major'],
    [10, 'major'],
    [5, 'major'],
    [0, 'major'],
  ]),
  genreProgression('blues-turn', 'Blues', 'Dominant turnaround', 'I7 – IV7 – I7 – V7', [
    [0, '7'],
    [5, '7'],
    [0, '7'],
    [7, '7'],
  ]),
  genreProgression('blues-minor', 'Blues', 'Minor blues colours', 'i7 – iv7 – bVI7 – V7', [
    [0, 'm7'],
    [5, 'm7'],
    [8, '7'],
    [7, '7'],
  ]),
  genreProgression('jazz-minor', 'Jazz', 'Minor ii–V–i', 'iiø7 – V7b9 – i(maj7)', [
    [2, 'm7b5'],
    [7, '7b9'],
    [0, 'mMaj7'],
  ]),
  genreProgression('jazz-cycle', 'Jazz', 'Descending fifths', 'iii7 – VI7 – ii7 – V7', [
    [4, 'm7'],
    [9, '7'],
    [2, 'm7'],
    [7, '7'],
  ]),
  genreProgression('pop-singer', 'Pop', 'Singer-songwriter turn', 'vi – IV – I – V', [
    [9, 'minor'],
    [5, 'major'],
    [0, 'major'],
    [7, 'major'],
  ]),
  genreProgression('funk-dorian', 'Funk & Soul', 'Dorian pocket', 'i9 – IV13', [
    [0, 'm9'],
    [5, '13'],
  ]),
  genreProgression('country-road', 'Country', 'Open-road changes', 'I – IV – V – I', [
    [0, 'major'],
    [5, 'major'],
    [7, 'major'],
    [0, 'major'],
  ]),
  genreProgression('country-six', 'Country', 'Sixth-chord stroll', 'I6 – vi7 – ii7 – V7', [
    [0, '6'],
    [9, 'm7'],
    [2, 'm7'],
    [7, '7'],
  ]),
  genreProgression('classical-minor', 'Classical', 'Minor cadence', 'i – iv – V – i', [
    [0, 'minor'],
    [5, 'minor'],
    [7, 'major'],
    [0, 'minor'],
  ]),
  genreProgression('classical-cycle', 'Classical', 'Circle sequence', 'i – iv – bVII – bIII', [
    [0, 'minor'],
    [5, 'minor'],
    [10, 'major'],
    [3, 'major'],
  ]),
  genreProgression(
    'ambient-major',
    'Ambient',
    'Open-sky extensions',
    'Imaj9 – IVmaj7 – vi9 – Vsus4',
    [
      [0, 'maj9'],
      [5, 'maj7'],
      [9, 'm9'],
      [7, 'sus4'],
    ],
  ),
  genreProgression(
    'ambient-minor',
    'Ambient',
    'Suspended minor space',
    'i9 – bVImaj9 – bIIImaj7 – bVIIadd9',
    [
      [0, 'm9'],
      [8, 'maj9'],
      [3, 'maj7'],
      [10, 'add9'],
    ],
  ),
);
ARPEGGIO_TEMPLATES.push(...MORE_ARPEGGIO_PROGRESSIONS);
export const ARPEGGIO_GENRES = [
  'Metal',
  'Rock',
  'Blues',
  'Jazz',
  'Pop',
  'Funk & Soul',
  'Country',
  'Classical',
  'Ambient',
];
export const MAX_ARPEGGIO_STEPS = 32;
export const ARPEGGIO_STORAGE_KEY = 'cassian.learn.arpeggios.v1';
const clamp = (value, min, max, fallback) =>
  Number.isFinite(Number(value))
    ? Math.min(max, Math.max(min, Math.round(Number(value))))
    : fallback;
export const getArpeggioQuality = (id) =>
  ARPEGGIO_QUALITIES.find((item) => item.id === id) ?? ARPEGGIO_QUALITIES[0];
export const getArpeggioRoot = (key, step) => pitchClass(key + step.offset);
export const arpeggioName = (key, step) =>
  noteNameInKey(key, step.offset) + getArpeggioQuality(step.quality).suffix;

export function parseArpeggioSequence(text, key = 0, firstId = 1) {
  const source = String(text).trim().replaceAll('♯', '#').replaceAll('♭', 'b');
  if (!source || source.length > 256)
    throw new Error('Enter a chord sequence, for example E C D B or Em7 Cmaj7 D B7.');
  const aliases = new Map();
  for (const chord of ARPEGGIO_QUALITIES) {
    aliases.set(chord.id.toLowerCase(), chord.id);
    aliases.set(chord.suffix.toLowerCase(), chord.id);
  }
  aliases.set('min', 'minor');
  aliases.set('maj', 'major');
  const notePitch = (letter, accidental = '') =>
    pitchClass(
      { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[letter.toUpperCase()] +
        (accidental === '#' ? 1 : accidental === 'b' ? -1 : 0),
    );
  const parseChord = (token) => {
    const match = /^([A-Ga-g])([#b]?)([^/]*)(?:\/([A-Ga-g])([#b]?))?$/.exec(token);
    if (!match) throw new Error(`Could not read “${token}”. Separate chords with spaces.`);
    const suffix = match[3];
    const majorAliases = { M: 'major', M6: '6', M7: 'maj7', M9: 'maj9', M13: 'maj13' };
    const id = /^M(?:\d|$)/.test(suffix) ? majorAliases[suffix] : aliases.get(suffix.toLowerCase());
    if (!id) throw new Error(`Unsupported chord “${token}”. Choose a chord type from the builder.`);
    const root = notePitch(match[1], match[2]),
      chord = getArpeggioQuality(id);
    const bass = match[4] ? notePitch(match[4], match[5]) : root;
    const inversion = chord.intervals.findIndex((interval) => pitchClass(root + interval) === bass);
    if (inversion < 0)
      throw new Error(`The bass note in “${token}” must be one of its chord tones.`);
    return { offset: pitchClass(root - key), quality: id, inversion, bars: 1, pattern: 'up-down' };
  };
  let tokens;
  if (/[\s,|→–—-]/.test(source)) tokens = source.split(/[\s,|→–—-]+/).filter(Boolean);
  else {
    try {
      return [{ ...parseChord(source), id: firstId }];
    } catch {
      /* Try compact notation such as ECDB or EmCDG. */
    }
    tokens = [];
    const compact = /[A-G][#b]?[^A-G/\s]*(?:\/[A-G][#b]?)?/gy;
    let cursor = 0,
      match;
    while ((match = compact.exec(source))) {
      tokens.push(match[0]);
      cursor = compact.lastIndex;
    }
    if (cursor !== source.length)
      throw new Error('Use chord names such as E C D B. Unrecognized text was not added.');
  }
  if (!tokens.length || tokens.length > MAX_ARPEGGIO_STEPS)
    throw new Error('A progression can contain 1–32 chords.');
  return tokens.map((token, index) => ({ ...parseChord(token), id: firstId + index }));
}

export function spellChordTones(root, id, rootName = NOTE_NAMES[pitchClass(root)]) {
  const selected = getArpeggioQuality(id);
  return selected.intervals.map((interval, index) => {
    const degree = Number(selected.degrees[index].replace(/[^0-9]/g, ''));
    const name = spellFromRoot(rootName, root + interval, degree - 1);
    return { name, degree: selected.degrees[index], pitch: pitchClass(root + interval) };
  });
}

export function createArpeggioProgression(templateId = 'jazz') {
  const template =
    ARPEGGIO_TEMPLATES.find((item) => item.id === templateId) ?? ARPEGGIO_TEMPLATES[0];
  return {
    version: 1,
    name: template.name,
    key: 4,
    tuning: 'standard',
    tempo: 90,
    meter: '4/4',
    rate: 'eighth',
    octaves: 1,
    minFret: 0,
    maxFret: 5,
    runRange: 'octaves',
    referenceScale: template.id === 'jazz' ? 'major' : 'none',
    strings: 'all',
    connect: true,
    steps: template.steps.map(([offset, chord], index) => ({
      id: index + 1,
      offset,
      quality: chord,
      inversion: 0,
      bars: 1,
      pattern: 'up-down',
    })),
    nextId: template.steps.length + 1,
  };
}

// Saved drafts and imported files are bounded data, never executable content.
export function normalizeArpeggioProgression(input) {
  if (
    !input ||
    input.version !== 1 ||
    !Array.isArray(input.steps) ||
    !input.steps.length ||
    input.steps.length > MAX_ARPEGGIO_STEPS
  )
    throw new Error('Choose a Cassian arpeggio progression with 1–32 chords.');
  const defaults = createArpeggioProgression();
  const steps = input.steps.map((step, index) => {
    if (
      !step ||
      !ARPEGGIO_QUALITIES.some((item) => item.id === step.quality) ||
      !Number.isFinite(step.offset)
    )
      throw new Error('This progression contains an unsupported chord.');
    const selected = getArpeggioQuality(step.quality);
    return {
      id: index + 1,
      offset: pitchClass(step.offset),
      quality: selected.id,
      inversion: clamp(step.inversion, 0, selected.intervals.length - 1, 0),
      bars: clamp(step.bars, 1, 8, 1),
      pattern: ARPEGGIO_PATTERNS.some((item) => item.id === step.pattern) ? step.pattern : 'up',
    };
  });
  const minFret = clamp(input.minFret, 0, 19, 0);
  return {
    ...defaults,
    referenceScale: HARMONY_SCALES.some((scale) => scale.id === input.referenceScale)
      ? input.referenceScale
      : 'none',
    name: String(input.name || 'My progression')
      .replace(/[\u0000-\u001f]/g, '')
      .slice(0, 80),
    key: pitchClass(input.key),
    tuning: getLearnTuning(input.tuning).id,
    tempo: clamp(input.tempo, 40, 240, 90),
    meter: ARPEGGIO_METERS.includes(input.meter) ? input.meter : '4/4',
    rate: ARPEGGIO_RATES.some((item) => item.id === input.rate) ? input.rate : 'eighth',
    octaves: clamp(input.octaves, 1, 2, 1),
    runRange: input.runRange === 'full-neck' ? 'full-neck' : 'octaves',
    minFret,
    maxFret: clamp(input.maxFret, minFret + 3, 24, Math.max(5, minFret + 3)),
    strings: ['all', 'upper3', 'upper4', 'lower4'].includes(input.strings) ? input.strings : 'all',
    connect: input.connect !== false,
    steps,
    nextId: steps.length + 1,
  };
}

export function harmonizeArpeggios(scaleId, sevenths = true) {
  const scale = HARMONY_SCALES.find((item) => item.id === scaleId) ?? HARMONY_SCALES[0];
  return scale.intervals.map((offset, degree) => {
    const intervals = Array.from({ length: sevenths ? 4 : 3 }, (_, index) => {
      const position = degree + index * 2;
      return scale.intervals[position % 7] + Math.floor(position / 7) * 12 - offset;
    });
    const match = ARPEGGIO_QUALITIES.find(
      (item) =>
        item.intervals.length === intervals.length &&
        item.intervals.every((value, index) => value === intervals[index]),
    );
    return { offset, quality: match?.id, degree: degree + 1 };
  });
}

export function applyArpeggioPattern(path, pattern) {
  if (pattern === 'down') return [...path].reverse();
  if (pattern === 'up-down') return [...path, ...path.slice(1, -1).reverse()];
  if (pattern === 'outside-in') {
    const notes = [];
    for (let low = 0, high = path.length - 1; low <= high; low += 1, high -= 1) {
      notes.push(path[low]);
      if (low !== high) notes.push(path[high]);
    }
    return notes;
  }
  if (pattern === 'rolling-fours') {
    if (path.length < 4) return path;
    return Array.from({ length: path.length - 3 }, (_, index) =>
      path.slice(index, index + 4),
    ).flat();
  }
  if (pattern === 'skip-tone') {
    const sequence = [];
    for (let index = 0; index < path.length - 2; index += 1)
      sequence.push(path[index], path[index + 2]);
    sequence.push(...path.slice(-2));
    return sequence;
  }
  return path;
}

// A path is a sequence of real string/fret locations, not a simultaneous grip.
// Dynamic programming favours adjacent strings and smaller fret movements.
export function buildArpeggioPath(root, step, options = {}, previousMidi = null) {
  const selected = getArpeggioQuality(step.quality);
  const tuning = getLearnTuning(options.tuning);
  const minFret = clamp(options.minFret, 0, 19, 0);
  const maxFret = clamp(options.maxFret, minFret + 3, 24, Math.max(5, minFret + 3));
  const octaves = clamp(options.octaves, 1, 2, 1);
  const wholeNeck = options.runRange === 'full-neck';
  const inversion = clamp(step.inversion, 0, selected.intervals.length - 1, 0);
  const bass = pitchClass(root + selected.intervals[inversion]);
  const pitches = [...new Set(selected.intervals.map((interval) => pitchClass(root + interval)))];
  const relative = pitches.map((pitch) => pitchClass(pitch - bass)).sort((a, b) => a - b);
  const offsets = Array.from({ length: octaves }, (_, octave) =>
    relative.map((offset) => offset + octave * 12),
  ).flat();
  offsets.push(octaves * 12);
  const cells = tuning.notes.flatMap((open, stringIndex) => {
    const count = tuning.notes.length;
    if (options.strings === 'upper3' && stringIndex < count - 3) return [];
    if (options.strings === 'upper4' && stringIndex < count - 4) return [];
    if (options.strings === 'lower4' && stringIndex >= 4) return [];
    return Array.from({ length: maxFret - minFret + 1 }, (_, index) => ({
      stringIndex,
      fret: minFret + index,
      midi: open + minFret + index,
    }));
  });
  const nameFor = (midi) => {
    const tone = spellChordTones(root, selected.id, options.rootName).find(
      (item) => item.pitch === pitchClass(midi),
    );
    return { ...tone, octave: spelledOctave(midi, tone.name) };
  };
  const firstString = Math.min(...cells.map((cell) => cell.stringIndex));
  const lastString = Math.max(...cells.map((cell) => cell.stringIndex));
  const starts = [
    ...new Set(
      cells
        .filter(
          (cell) =>
            pitchClass(cell.midi) === bass && (!wholeNeck || cell.stringIndex === firstString),
        )
        .map((cell) => cell.midi),
    ),
  ].sort((a, b) => a - b);
  const fullPitches = [
    ...new Set(
      cells.filter((cell) => pitches.includes(pitchClass(cell.midi))).map((cell) => cell.midi),
    ),
  ].sort((a, b) => a - b);
  let best = null;
  for (const start of wholeNeck ? starts.slice(0, 1) : starts) {
    const targets = wholeNeck
      ? fullPitches.filter((midi) => midi >= start)
      : offsets.map((offset) => start + offset);
    let states = [
      {
        cost: previousMidi === null ? start * 0.025 : Math.abs(start - previousMidi) * 1.5,
        notes: [],
      },
    ];
    for (const target of targets) {
      const choices = cells.filter((cell) => cell.midi === target);
      states = choices
        .map((cell) => {
          let winner = null;
          for (const state of states) {
            const last = state.notes.at(-1);
            if (
              wholeNeck &&
              (last
                ? cell.stringIndex < last.stringIndex || cell.stringIndex > last.stringIndex + 1
                : cell.stringIndex !== firstString)
            )
              continue;
            const frets = state.notes.map((note) => note.fret);
            const span = frets.length ? Math.max(...frets) - Math.min(...frets) : 0;
            const nextSpan = Math.max(cell.fret, ...frets) - Math.min(cell.fret, ...frets);
            const stretch = Math.max(0, nextSpan - 4) ** 2 - Math.max(0, span - 4) ** 2;
            const cost =
              state.cost +
              (wholeNeck ? 0 : stretch * 3) +
              (last
                ? Math.abs(last.stringIndex - cell.stringIndex) * 1.8 +
                  Math.abs(last.fret - cell.fret) * 0.55
                : cell.fret * 0.1);
            if (!winner || cost < winner.cost)
              winner = { cost, notes: [...state.notes, { ...cell, ...nameFor(cell.midi) }] };
          }
          return winner;
        })
        .filter(Boolean);
      if (!states.length) break;
    }
    for (const state of states)
      if (
        state.notes.length === targets.length &&
        (!wholeNeck || state.notes.at(-1)?.stringIndex === lastString) &&
        (!best || state.cost < best.cost)
      )
        best = state;
  }
  return best ? applyArpeggioPattern(best.notes, step.pattern) : [];
}

export function compileArpeggioProgression(document, key = document.key, tuning = document.tuning) {
  const barTicks = meterQuarterBeats(document.meter) * 480;
  const pulse = ARPEGGIO_RATES.find((item) => item.id === document.rate)?.ticks ?? 240;
  let startTick = 0,
    previousMidi = null;
  const events = [],
    missing = [],
    paths = [],
    stepTicks = [];
  for (const step of document.steps) {
    const path = buildArpeggioPath(
      getArpeggioRoot(key, step),
      step,
      { ...document, tuning, rootName: noteNameInKey(key, step.offset) },
      document.connect ? previousMidi : null,
    );
    paths.push(path);
    if (!path.length) missing.push(step.id);
    const ticks =
      document.runRange === 'full-neck'
        ? Math.max(barTicks * step.bars, Math.ceil((path.length * pulse) / barTicks) * barTicks)
        : barTicks * step.bars;
    stepTicks.push(ticks);
    if (path.length) {
      for (
        let tick = 0, index = 0;
        tick < ticks && (document.runRange !== 'full-neck' || index < path.length);
        tick += pulse, index += 1
      ) {
        events.push({
          ...path[index % path.length],
          tick: startTick + tick,
          duration: Math.min(Math.round(pulse * 0.82), ticks - tick),
          stepId: step.id,
          pathIndex: index % path.length,
        });
      }
      previousMidi = events.at(-1).midi;
    }
    startTick += ticks;
  }
  return { events, paths, missing, stepTicks, totalTicks: startTick };
}
export function meterQuarterBeats(meter) {
  const [numerator, denominator] = (ARPEGGIO_METERS.includes(meter) ? meter : '4/4')
    .split('/')
    .map(Number);
  return (numerator * 4) / denominator;
}

export function chordConnection(fromRoot, fromQuality, toRoot, toQuality, key = null) {
  const from = spellChordTones(
      fromRoot,
      fromQuality,
      key === null ? undefined : noteNameInKey(key, pitchClass(fromRoot - key)),
    ),
    to = spellChordTones(
      toRoot,
      toQuality,
      key === null ? undefined : noteNameInKey(key, pitchClass(toRoot - key)),
    );
  const shared = from
    .filter((tone) => to.some((next) => next.pitch === tone.pitch))
    .map((tone) => tone.name);
  let motion = null;
  for (const tone of from)
    for (const next of to) {
      const distance = Math.min(
        pitchClass(next.pitch - tone.pitch),
        pitchClass(tone.pitch - next.pitch),
      );
      if (distance && (!motion || distance < motion.distance))
        motion = { from: tone.name, to: next.name, distance };
    }
  return { shared, motion };
}

export function arpeggioScaleReport(document, key, scaleId = document.referenceScale) {
  const scale = HARMONY_SCALES.find((item) => item.id === scaleId);
  if (!scale) return null;
  const pitches = new Set(scale.intervals.map((interval) => pitchClass(key + interval)));
  const chords = document.steps.map((step) => {
    const root = getArpeggioRoot(key, step),
      quality = getArpeggioQuality(step.quality);
    const outside = spellChordTones(root, quality.id, noteNameInKey(key, step.offset)).filter(
      (tone) => !pitches.has(tone.pitch),
    );
    const minorDominant =
      scale.id === 'minor' &&
      pitchClass(root - key) === 7 &&
      quality.intervals.includes(4) &&
      quality.intervals.includes(10) &&
      outside.length === 1 &&
      outside[0].pitch === pitchClass(key + 11);
    return { id: step.id, name: arpeggioName(key, step), outside, minorDominant };
  });
  return { scale, chords, outsideCount: chords.filter((chord) => chord.outside.length).length };
}

export function arpeggioTab(document, key = document.key, tuning = document.tuning, stepId = null) {
  const compiled = compileArpeggioProgression(document, key, tuning);
  if (compiled.missing.some((id) => stepId === null || id === stepId))
    throw new Error('Widen the fret range before writing the complete tab.');
  const instrument = getLearnTuning(tuning);
  const rate = ARPEGGIO_RATES.find((item) => item.id === document.rate).name;
  const lines = [
    `CASSIAN | ${document.name}`,
    `${NOTE_NAMES[pitchClass(key)]} | ${instrument.name}`,
    `${document.tempo} quarter-note BPM | ${document.meter} | ${rate}`,
    stepId === null
      ? 'Complete progression, in playback order. Repeat from the first chord when looping.'
      : 'Selected run, once through the complete picking pattern.',
    'High string at the top. Numbers are frets. Every note is included.',
    '',
  ];
  const selectedSteps = document.steps.filter((step) => stepId === null || step.id === stepId);
  if (!selectedSteps.length) throw new Error('Choose a chord before writing its tab.');
  for (const step of selectedSteps) {
    const index = document.steps.findIndex((item) => item.id === step.id);
    const notes =
      stepId === null
        ? compiled.events.filter((event) => event.stepId === step.id)
        : compiled.paths[index];
    const bars = compiled.stepTicks[index] / (meterQuarterBeats(document.meter) * 480);
    lines.push(
      `[${index + 1}] ${arpeggioName(key, step)} | ${bars} bars | ${notes.length} notes`,
      '',
    );
    for (let start = 0; start < notes.length; start += 12) {
      const group = notes.slice(start, start + 12);
      lines.push('Note ' + group.map((note) => (note.name + note.octave).padEnd(5)).join(''));
      for (let string = instrument.notes.length - 1; string >= 0; string -= 1) {
        const label = guitarStringLabel(
          instrument.notes[string],
          string === instrument.notes.length - 1,
        );
        lines.push(
          label.padEnd(3) +
            '|' +
            group
              .map((note) =>
                note.stringIndex === string ? ('--' + note.fret).padEnd(5, '-') : '-----',
              )
              .join('') +
            '|',
        );
      }
      lines.push('');
    }
  }
  return lines.join('\n');
}

const variable = (value) => {
  const bytes = [value & 127];
  while ((value >>= 7)) bytes.unshift((value & 127) | 128);
  return bytes;
};
const ascii = (text) => [...text].map((character) => character.charCodeAt(0));
const uint32 = (value) => [
  (value >>> 24) & 255,
  (value >>> 16) & 255,
  (value >>> 8) & 255,
  value & 255,
];
export function arpeggioMidi(document, key = document.key, tuning = document.tuning) {
  const compiled = compileArpeggioProgression(document, key, tuning);
  if (compiled.missing.length)
    throw new Error(
      'Move the fret window or use more strings before exporting. Every chord needs a playable path.',
    );
  const tempo = Math.round(60000000 / document.tempo);
  const [numerator, denominator] = document.meter.split('/').map(Number);
  const track = [
    0,
    255,
    81,
    3,
    (tempo >> 16) & 255,
    (tempo >> 8) & 255,
    tempo & 255,
    0,
    255,
    88,
    4,
    numerator,
    Math.log2(denominator),
    24,
    8,
    0,
    192,
    24,
  ];
  const messages = compiled.events
    .flatMap((event) => [
      { tick: event.tick, bytes: [144, event.midi, 82], order: 1 },
      { tick: event.tick + event.duration, bytes: [128, event.midi, 0], order: 0 },
    ])
    .sort((a, b) => a.tick - b.tick || a.order - b.order);
  let lastTick = 0;
  for (const message of messages) {
    track.push(...variable(message.tick - lastTick), ...message.bytes);
    lastTick = message.tick;
  }
  track.push(...variable(compiled.totalTicks - lastTick), 255, 47, 0);
  return new Uint8Array([
    ...ascii('MThd'),
    0,
    0,
    0,
    6,
    0,
    0,
    0,
    1,
    1,
    224,
    ...ascii('MTrk'),
    ...uint32(track.length),
    ...track,
  ]);
}
