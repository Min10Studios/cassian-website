// Crazaloth: browser-only, bounded local preferences; never a rig or native state document.
import { PATHWAYS } from "./curriculum.js";
import { LEARN_TUNINGS, LEARN_SCALES } from "./fretboardTheory.js";

export const defaultPreferences = {
  schema: 1,
  pathway: "blues",
  root: 4,
  tuning: "standard",
  scale: "minor-pentatonic",
  handedness: "right",
  section: "lesson",
  tempo: 80,
  completed: [],
};
export function sanitizePreferences(value) {
  const source =
    value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const oneOf = (key, choices) =>
    choices.includes(source[key]) ? source[key] : defaultPreferences[key];
  return {
    schema: 1,
    pathway: oneOf(
      "pathway",
      PATHWAYS.map((row) => row.id),
    ),
    root:
      Number.isInteger(source.root) && source.root >= 0 && source.root < 12
        ? source.root
        : 4,
    tuning: oneOf(
      "tuning",
      LEARN_TUNINGS.map((row) => row.id),
    ),
    scale: oneOf(
      "scale",
      LEARN_SCALES.map((row) => row.id),
    ),
    handedness: oneOf("handedness", ["left", "right"]),
    section: oneOf("section", ["lesson", "neck", "tone"]),
    tempo:
      Number.isInteger(source.tempo) &&
      source.tempo >= 40 &&
      source.tempo <= 200
        ? source.tempo
        : 80,
    completed: [
      ...new Set(Array.isArray(source.completed) ? source.completed : []),
    ]
      .filter((id) => PATHWAYS.some((row) => row.id === id))
      .slice(0, 12),
  };
}
export function readPreferences(key, storage) {
  try {
    const text = storage?.getItem(key);
    if (!text || text.length > 8192) return { ...defaultPreferences };
    const value = JSON.parse(text);
    return value.schema === 1
      ? sanitizePreferences(value)
      : { ...defaultPreferences };
  } catch {
    return { ...defaultPreferences };
  }
}
export function browserStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}
