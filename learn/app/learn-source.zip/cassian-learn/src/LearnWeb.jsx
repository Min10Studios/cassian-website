// Crazaloth: portable public Learn UI. No desktop imports or native bridge calls.
import { useEffect, useRef, useState } from "react";
import { PATHWAYS } from "./curriculum.js";
import {
  LEARN_KEYS,
  LEARN_TUNINGS,
  getLearnTuning,
} from "./fretboardTheory.js";
import { RetainedViewBoundary } from "./retainedViewState.js";
import {
  browserStorage,
  readPreferences,
  sanitizePreferences,
} from "./preferences.js";
import { createBrowserAudio } from "./browserAudio.js";
import Fretboard from "./Fretboard.jsx";
import GenreCurriculum from "./GenreCurriculum.jsx";
import ToneGuide from "./ToneGuide.jsx";
import TheoryCompass from "./TheoryCompass.jsx";

function LearnContent({
  storageKey = "cassian.learn.web.v1",
  initialState,
  onEvent,
  audioFactory,
  sourceUrl = "./learn-source.zip",
}) {
  const [prefs, setPrefs] = useState(() =>
    sanitizePreferences({
      ...readPreferences(storageKey, browserStorage()),
      ...initialState,
    }),
  );
  const [saving, setSaving] = useState(true),
    [chord, setChord] = useState(null),
    [position, setPosition] = useState("all"),
    [feedback, setFeedback] = useState(""),
    [playing, setPlaying] = useState(false),
    [busy, setBusy] = useState(false);
  const [tempoDraft, setTempoDraft] = useState(String(prefs.tempo));
  const audio = useRef(null),
    active = useRef(true),
    eventHandler = useRef(onEvent);
  eventHandler.current = onEvent;
  const emit = (type, detail) => {
    try {
      eventHandler.current?.({ schema: 1, type, detail });
    } catch {
      /* Host callback is optional. */
    }
  };
  const update = (patch) =>
    setPrefs((value) => sanitizePreferences({ ...value, ...patch }));
  useEffect(() => {
    try {
      const storage = browserStorage();
      if (!storage) throw Error();
      storage.setItem(storageKey, JSON.stringify(prefs));
      setSaving(true);
    } catch {
      setSaving(false);
    }
  }, [prefs, storageKey]);
  useEffect(() => {
    active.current = true;
    const interrupted = (error) => {
      if (active.current) {
        setPlaying(false);
        setFeedback(error.message);
        emit("audio-error", { message: error.message });
      }
    };
    audio.current = audioFactory
      ? audioFactory({ onError: interrupted })
      : createBrowserAudio({ onError: interrupted });
    const hide = () => {
      if (document.hidden) {
        audio.current.stop();
        setPlaying(false);
      }
    };
    document.addEventListener("visibilitychange", hide);
    return () => {
      active.current = false;
      document.removeEventListener("visibilitychange", hide);
      audio.current.dispose();
    };
  }, [audioFactory]);
  useEffect(() => {
    audio.current?.setTempo(prefs.tempo);
  }, [prefs.tempo]);
  const pathway =
    PATHWAYS.find((row) => row.id === prefs.pathway) ?? PATHWAYS[0];
  const leftHanded = prefs.handedness === "left";
  const play = async (notes) => {
    try {
      const success = await audio.current.playNotes(notes);
      if (success && active.current) {
        setFeedback("Playing synthetic reference audio.");
        emit("note-played", { notes });
      }
    } catch (error) {
      if (active.current) setFeedback(error.message);
      emit("audio-error", { message: error.message });
    }
  };
  const pulse = async () => {
    if (busy) return;
    if (playing) {
      audio.current.stop();
      setPlaying(false);
      emit("practice-state", { playing: false });
      return;
    }
    setBusy(true);
    try {
      const success = await audio.current.startPulse(prefs.tempo);
      if (success && active.current) {
        setPlaying(true);
        setFeedback("Practice pulse started.");
        emit("practice-state", { playing: true, tempo: prefs.tempo });
      }
    } catch (error) {
      if (active.current) setFeedback(error.message);
      emit("audio-error", { message: error.message });
    } finally {
      if (active.current) setBusy(false);
    }
  };
  const selectPathway = (id) => {
    const next = PATHWAYS.find((row) => row.id === id);
    if (!next) return;
    update({ pathway: id, scale: next.defaultScale });
    setChord(null);
    setPosition("all");
    emit("lesson-change", { pathway: id });
  };
  const showChord = (selected) => {
    setChord(selected);
    setPosition("all");
    update({ section: "neck" });
  };
  const completed = prefs.completed.includes(pathway.id);
  const mark = () => {
    const list = completed
      ? prefs.completed.filter((id) => id !== pathway.id)
      : [...prefs.completed, pathway.id];
    update({ completed: list });
    emit("progress-change", { completed: list });
  };
  const switchSection = (section) => update({ section });
  const tabs = [
    ["lesson", "Lesson"],
    ["neck", "Fretboard"],
    ["tone", "Tone guide"],
  ];
  const tabRefs = useRef([]);
  return (
    <section className="cassian-learn" data-handedness={prefs.handedness}>
      <header className="learn-web-heading">
        <div>
          <span className="learn-kicker">Min10 Studios</span>
          <h2>Cassian Learn</h2>
          <p>Choose a lesson. Find it on the neck. Make it musical.</p>
        </div>
        <span className="learn-progress">
          {prefs.completed.length} / 12 practised
        </span>
      </header>
      <div className="learn-global-settings" aria-label="Learning preferences">
        <label>
          Pathway
          <select aria-label="Pathway"
            value={pathway.id}
            onChange={(event) => selectPathway(event.target.value)}
          >
            {PATHWAYS.map((row) => (
              <option value={row.id} key={row.id}>
                {row.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Key
          <select aria-label="Key"
            value={prefs.root}
            onChange={(event) => {
              update({ root: Number(event.target.value) });
              setChord(null);
            }}
          >
            {LEARN_KEYS.map((row) => (
              <option key={row.value} value={row.value}>
                {row.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Tuning
          <select aria-label="Tuning"
            value={prefs.tuning}
            onChange={(event) => {
              update({ tuning: event.target.value });
              setChord(null);
              setPosition("all");
            }}
          >
            {LEARN_TUNINGS.map((row) => (
              <option key={row.id} value={row.id}>
                {row.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Handedness
          <select aria-label="Handedness"
            value={prefs.handedness}
            onChange={(event) => update({ handedness: event.target.value })}
          >
            <option value="right">Right-handed</option>
            <option value="left">Left-handed</option>
          </select>
        </label>
      </div>
      <nav
        className="learn-section-tabs"
        role="tablist"
        aria-label="Learn sections"
      >
        {tabs.map(([id, label], index) => (
          <button
            key={id}
            ref={(node) => {
              tabRefs.current[index] = node;
            }}
            type="button"
            role="tab"
            id={"learn-tab-" + id}
            aria-selected={prefs.section === id}
            aria-controls={"learn-panel-" + id}
            tabIndex={prefs.section === id ? 0 : -1}
            onClick={() => switchSection(id)}
            onKeyDown={(event) => {
              const next =
                event.key === "ArrowRight"
                  ? (index + 1) % 3
                  : event.key === "ArrowLeft"
                    ? (index + 2) % 3
                    : event.key === "Home"
                      ? 0
                      : event.key === "End"
                        ? 2
                        : null;
              if (next !== null) {
                event.preventDefault();
                switchSection(tabs[next][0]);
                tabRefs.current[next]?.focus();
              }
            }}
          >
            {label}
          </button>
        ))}
      </nav>
      <section
        role="tabpanel"
        id={"learn-panel-" + prefs.section}
        aria-labelledby={"learn-tab-" + prefs.section}
      >
        {prefs.section === "lesson" && (
          <>
            <GenreCurriculum
              compactNavigation
              leftHanded={leftHanded}
              selectedId={pathway.id}
              onSelect={selectPathway}
              root={prefs.root}
              tuning={prefs.tuning}
              onChordSelect={showChord}
              onScaleSelect={(scale) => {
                update({ scale, section: "neck" });
                setChord(null);
                setPosition("all");
              }}
              onTuningSelect={(tuning) => {
                update({ tuning });
                setChord(null);
                setPosition("all");
              }}
            >
              <p className="learn-reference-hint">
                Chord grips below are six-string Standard E references.
                Alternate tunings and bass use recalculated note/interval maps
                in Fretboard.
              </p>
            </GenreCurriculum>
            <button
              className="learn-mark"
              type="button"
              aria-pressed={completed}
              onClick={mark}
            >
              {completed
                ? "Practised · mark to revisit"
                : "Mark this lesson practised"}
            </button>
          </>
        )}
        {prefs.section === "neck" && (
          <>
            {chord && (
              <div className="learn-chord-actions">
                <strong>
                  {chord.name} · {leftHanded ? "Left-handed" : "Right-handed"}
                </strong>
                <button type="button" onClick={() => setChord(null)}>
                  Return to scale
                </button>
                <button
                  type="button"
                  onClick={() =>
                    play(
                      chord.frets.flatMap((fret, index) =>
                        fret === null
                          ? []
                          : [getLearnTuning("standard").notes[index] + fret],
                      ),
                    )
                  }
                >
                  Hear chord reference
                </button>
              </div>
            )}
            <Fretboard
              compactControls
              root={prefs.root}
              tuning={prefs.tuning}
              scale={prefs.scale}
              position={position}
              onPositionChange={setPosition}
              chord={chord}
              leftHanded={leftHanded}
              onScaleChange={(scale) => {
                update({ scale });
                setChord(null);
                setPosition("all");
              }}
              onNoteActivate={(midi) => play([midi])}
            />
            <p className="learn-muted">
              Scroll the neck to reach all 24 frets. Arrow keys follow the
              displayed direction. String identities, note names and standard
              TAB notation keep their musical meaning.
            </p>
          </>
        )}
        {prefs.section === "neck" && (
          <details className="learn-card learn-compass-disclosure">
            <summary>Circle of fifths &amp; chord progressions</summary>
            <TheoryCompass
              root={prefs.root}
              onRootChange={(root) => {
                update({ root });
                setChord(null);
              }}
            />
          </details>
        )}
        {prefs.section === "tone" && (
          <ToneGuide key={pathway.id} pathway={pathway.id} />
        )}
      </section>
      <aside
        className="learn-practice-strip"
        aria-label="Browser practice tools"
      >
        <div>
          <strong>Practice pulse</strong>
          <span>Synthetic reference audio · 4 beats per bar</span>
        </div>
        <label>
          BPM
          <input
            type="number"
            min="40"
            max="200"
            step="1"
            value={tempoDraft}
            onChange={(event) => {
              const text = event.target.value,
                value = Number(text);
              setTempoDraft(text);
              if (Number.isInteger(value) && value >= 40 && value <= 200)
                update({ tempo: value });
            }}
            onBlur={() => {
              if (Number(tempoDraft) !== prefs.tempo)
                setFeedback("Choose 40–200 BPM.");
              setTempoDraft(String(prefs.tempo));
            }}
          />
        </label>
        <button
          type="button"
          disabled={busy}
          aria-pressed={playing}
          onClick={pulse}
        >
          {playing ? "Stop pulse" : "Start pulse"}
        </button>
        <button
          type="button"
          onClick={() => {
            audio.current.stop();
            setPlaying(false);
            setFeedback("Reference audio stopped.");
          }}
        >
          Stop all audio
        </button>
      </aside>
      <p className="learn-feedback" role="status">
        {feedback}
      </p>
      <footer className="learn-web-footer">
        <span>
          {saving
            ? "Progress stays in this browser."
            : "Progress is not saved in this browser."}
        </span>
        <a href={sourceUrl}>Learning module source · AGPL</a>
        <span>Original Cassian learning content · Crazaloth</span>
      </footer>
    </section>
  );
}
export default function LearnWeb(props) {
  return (
    <RetainedViewBoundary>
      <LearnContent {...props} />
    </RetainedViewBoundary>
  );
}
