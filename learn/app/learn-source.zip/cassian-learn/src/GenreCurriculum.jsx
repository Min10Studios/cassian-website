import * as uiCopy from "./copy.js";
import { useId, useRef } from "react";
import {
  PATHWAYS,
  SCALE_REFERENCE,
  STANDARD_OPEN_PITCHES,
  STRING_NAMES,
  OPEN_CHORDS,
  buildProgression,
  getPathwayChords,
  getChordVoicing,
  getChordNoteName,
  getPentatonicBoxes,
  getScaleNoteNames,
  noteName,
  pitchClass,
} from "./curriculum.js";

export { PATHWAYS } from "./curriculum.js";

const tuningLabels = {
  standard: "Standard · E A D G B E",
  "drop-d": "Drop D · D A D G B E",
  facgce: "FACGCE · F A C G C E",
  dadgad: "DADGAD · D A D G A D",
  "open-d": "Open D · D A D F# A D",
  "seven-standard": "7-string standard · B E A D G B E",
};
const modeIds = [
  "ionian",
  "dorian",
  "phrygian",
  "lydian",
  "mixolydian",
  "aeolian",
  "locrian",
];

export function ChordDiagram({ chord, leftHanded = false }) {
  const positive = chord.frets.filter((fret) => fret > 0);
  const start = positive.length ? Math.min(...positive) : 1;
  const firstFret = start <= 1 ? 1 : start;
  const fretRows = Math.max(4, Math.max(...positive, 1) - firstFret + 1);
  const left = 27,
    top = 40,
    gap = 19,
    rowHeight = 23;
  const bottom = top + fretRows * rowHeight;
  const description = chord.frets
    .map((fret) =>
      fret === null ? "muted" : fret === 0 ? "open" : `fret ${fret}`,
    )
    .join(", ");
  return (
    <svg
      className="learn-chord-diagram"
      viewBox={`0 0 152 ${bottom + 32}`}
      role="img"
      data-handedness={leftHanded ? "left" : "right"}
      aria-label={`${chord.name}, ${leftHanded ? "left-handed" : "right-handed"}, standard tuning: low E to high E, ${description}`}
    >
      <text x="4" y={top + 17} className="learn-diagram-fret">
        {firstFret}
      </text>
      {Array.from({ length: fretRows + 1 }, (_, row) => (
        <line
          key={`fret-${row}`}
          x1={left}
          x2={left + 5 * gap}
          y1={top + row * rowHeight}
          y2={top + row * rowHeight}
          className={
            row === 0 && firstFret === 1
              ? "learn-diagram-nut"
              : "learn-diagram-line"
          }
        />
      ))}
      {chord.frets.map((fret, string) => {
        const x = left + (leftHanded ? 5 - string : string) * gap;
        const pc =
          fret === null
            ? null
            : pitchClass(STANDARD_OPEN_PITCHES[string] + fret);
        const isRoot = pc === chord.baseRoot;
        return (
          <g
            key={string}
            data-string-index={string}
            data-fret={fret ?? "muted"}
            data-midi={
              fret === null
                ? undefined
                : [40, 45, 50, 55, 59, 64][string] + fret
            }
          >
            <line
              x1={x}
              x2={x}
              y1={top}
              y2={bottom}
              className="learn-diagram-line"
            />
            <text
              x={x}
              y="20"
              textAnchor="middle"
              className={
                isRoot ? "learn-diagram-root-label" : "learn-diagram-open"
              }
            >
              {fret === null ? "×" : fret === 0 ? "○" : ""}
            </text>
            {fret > 0 && (
              <>
                <circle
                  cx={x}
                  cy={top + (fret - firstFret + 0.5) * rowHeight}
                  r="7"
                  className={
                    isRoot ? "learn-diagram-root" : "learn-diagram-dot"
                  }
                />
                <text
                  x={x}
                  y={top + (fret - firstFret + 0.5) * rowHeight + 3}
                  textAnchor="middle"
                  className="learn-diagram-dot-text"
                >
                  {isRoot ? "R" : ""}
                </text>
              </>
            )}
            <text
              x={x}
              y={bottom + 19}
              textAnchor="middle"
              className="learn-diagram-string"
            >
              {STRING_NAMES[string]}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function ChordCard({ chord, onSelect, disabled, leftHanded }) {
  const notes = chord.frets.map((fret, i) =>
    fret === null
      ? "×"
      : getChordNoteName(chord, STANDARD_OPEN_PITCHES[i] + fret),
  );
  return (
    <article className="learn-chord-card">
      <div className="learn-chord-card-heading">
        <h4>{chord.name}</h4>
        <span>{chord.label}</span>
      </div>
      <ChordDiagram chord={chord} leftHanded={leftHanded} />
      <div
        className="learn-chord-frets"
        aria-label="Frets from low E to high E"
      >
        {chord.frets.map((fret, i) => (
          <span key={i}>{fret === null ? "×" : fret}</span>
        ))}
      </div>
      <div
        className="learn-chord-notes"
        aria-label="Sounding notes from low E to high E"
      >
        {notes.map((note, i) => (
          <span key={i}>{note}</span>
        ))}
      </div>
      <button
        type="button"
        disabled={disabled || !onSelect}
        onClick={() =>
          onSelect?.({
            ...chord,
            intervals: [...chord.intervals],
            frets: [...chord.frets],
          })
        }
        aria-label={`View ${chord.name} ${chord.label} on fretboard`}
      >
        View on fretboard
      </button>
    </article>
  );
}

function PentatonicBoxes({ root }) {
  return (
    <div className="learn-pentatonic-boxes">
      <p className="learn-reference-note">
        {noteName(root)}
        {uiCopy.GenreCurriculum_minor_pentatonic_1b345b7_standard_tuning_only}
      </p>
      <div className="learn-box-grid">
        {getPentatonicBoxes(root).map((box) => (
          <article key={box.id} className="learn-pent-box">
            <h4>{box.label}</h4>
            <dl>
              {box.frets.map((frets, string) => (
                <div key={string}>
                  <dt>{STRING_NAMES[string]}</dt>
                  <dd>{frets.join(" – ")}</dd>
                </div>
              ))}
            </dl>
          </article>
        ))}
      </div>
      <p className="learn-reference-note">
        {uiCopy.GenreCurriculum_Play_one_box_ascending_return_through}
        {noteName(root)}
        {uiCopy.GenreCurriculum_Boxes_describe_locations_they_are_not}
      </p>
    </div>
  );
}

/** Curriculum is local study content. Band and rig writes belong to LearnWorkspace. */
export default function GenreCurriculum({
  selectedId,
  onSelect,
  root = 4,
  tuning = "standard",
  onChordSelect,
  onScaleSelect,
  onTuningSelect,
  disabled = false,
  children,
  leftHanded = false,
  compactNavigation = false,
}) {
  const id = useId();
  const tabs = useRef([]);
  const selected =
    PATHWAYS.find((pathway) => pathway.id === selectedId) || PATHWAYS[0];
  const selectedIndex = PATHWAYS.indexOf(selected);
  const keyRoot = pitchClass(root);
  const inStandardTuning = tuning === "standard";
  const hasWorkspaceSlot = children !== undefined && children !== null;
  const chords = getPathwayChords(selected, keyRoot);
  const progression = buildProgression(selected, keyRoot);
  const selectTab = (index) => {
    if (disabled) return;
    onSelect?.(PATHWAYS[index].id);
    tabs.current[index]?.focus();
  };
  const onTabKey = (event, index) => {
    const next =
      event.key === "ArrowRight" || event.key === "ArrowDown"
        ? (index + 1) % PATHWAYS.length
        : event.key === "ArrowLeft" || event.key === "ArrowUp"
          ? (index + PATHWAYS.length - 1) % PATHWAYS.length
          : event.key === "Home"
            ? 0
            : event.key === "End"
              ? PATHWAYS.length - 1
              : null;
    if (next !== null) {
      event.preventDefault();
      selectTab(next);
    }
  };
  const showChord = (chord) => onChordSelect?.(chord);
  return (
    <section
      className="learn-curriculum"
      aria-label="Genre learning curriculum"
    >
      {!compactNavigation && (
        <div
          className="learn-pathway-tabs"
          role="tablist"
          aria-label="Choose a genre pathway"
        >
          {PATHWAYS.map((pathway, index) => (
            <button
              key={pathway.id}
              ref={(element) => {
                tabs.current[index] = element;
              }}
              type="button"
              role="tab"
              id={`${id}-tab-${pathway.id}`}
              aria-selected={pathway.id === selected.id}
              aria-controls={`${id}-panel`}
              tabIndex={pathway.id === selected.id ? 0 : -1}
              disabled={disabled}
              onClick={() => onSelect?.(pathway.id)}
              onKeyDown={(event) => onTabKey(event, index)}
            >
              <span className="learn-pathway-number">
                {String(index + 1).padStart(2, "0")}
              </span>
              {pathway.label}
            </button>
          ))}
        </div>
      )}
      <div
        id={`${id}-panel`}
        role="tabpanel"
        aria-labelledby={
          compactNavigation ? undefined : `${id}-tab-${selected.id}`
        }
        aria-label={compactNavigation ? selected.label : undefined}
        tabIndex="0"
        className="learn-pathway-panel"
      >
        <header className="learn-pathway-heading">
          <div>
            <span className="learn-curriculum-eyebrow">
              Pathway {String(selectedIndex + 1).padStart(2, "0")} / 12 · Key{" "}
              {noteName(keyRoot)}
            </span>
            <h2>{selected.label}</h2>
            <p>{selected.tagline}</p>
          </div>
          <div className="learn-tuning-suggestion">
            <span>Suggested tuning</span>
            <strong>
              {tuningLabels[selected.suggestedTuning] ||
                selected.suggestedTuning}
            </strong>
            {onTuningSelect && tuning !== selected.suggestedTuning && (
              <button
                type="button"
                disabled={disabled}
                onClick={() => onTuningSelect(selected.suggestedTuning)}
              >
                Explore this tuning
              </button>
            )}
          </div>
        </header>
        {children}
        {!hasWorkspaceSlot && (
          <div
            className={`learn-band-reference${selected.closestGroove ? " learn-band-reference-closest" : ""}`}
          >
            <span>
              {selected.closestGroove
                ? "Closest existing groove"
                : "Band groove"}
            </span>
            <strong>{selected.bandGenre}</strong>
            <p>{selected.bandNote}</p>
          </div>
        )}

        <div className="learn-lesson-grid">
          <section className="learn-lesson-card">
            <span className="learn-curriculum-eyebrow">01 / Harmony</span>
            <h3>{selected.theoryTitle}</h3>
            <p>{selected.theory}</p>
            <div className="learn-progression-heading">
              <h4>{selected.progression.label}</h4>
              <span>{selected.progression.meter}</span>
            </div>
            <ol
              className="learn-progression"
              aria-label={`${selected.progression.label} in ${noteName(keyRoot)}`}
            >
              {progression.map((item, index) => (
                <li key={`${index}-${item.degree}`}>
                  <span>{item.degree}</span>
                  <strong>{item.name}</strong>
                  {progression.length === 12 && <small>Bar {index + 1}</small>}
                </li>
              ))}
            </ol>
          </section>
          <section className="learn-lesson-card">
            <span className="learn-curriculum-eyebrow">02 / Hands</span>
            <h3>{selected.technique.title}</h3>
            <ol className="learn-exercise-steps">
              {selected.technique.steps.map((instruction) => (
                <li key={instruction}>{instruction}</li>
              ))}
            </ol>
            <p className="learn-practice-goal">
              <strong>Practice target</strong>
              {selected.technique.goal}
            </p>
          </section>
          <section className="learn-lesson-card learn-rhythm-card">
            <span className="learn-curriculum-eyebrow">03 / Time</span>
            <h3>{selected.rhythm.title}</h3>
            <div className="learn-count-pattern">{selected.rhythm.count}</div>
            <p>{selected.rhythm.instruction}</p>
          </section>
          <section className="learn-lesson-card">
            <span className="learn-curriculum-eyebrow">04 / Note choices</span>
            <h3>Scale routes</h3>
            <p className="learn-scale-context">
              These buttons explore each scale on {noteName(keyRoot)}
              {uiCopy.GenreCurriculum_the_selected_root_Match_a_mode}
            </p>
            <div className="learn-scale-routes">
              {selected.scales.map((scaleId) => {
                const scale = SCALE_REFERENCE.find(
                  (item) => item.id === scaleId,
                );
                return (
                  scale && (
                    <button
                      key={scale.id}
                      type="button"
                      disabled={disabled || !onScaleSelect}
                      onClick={() => onScaleSelect?.(scale.id)}
                    >
                      <strong>
                        {noteName(keyRoot)} {scale.name}
                      </strong>
                      <span>{scale.formula}</span>
                    </button>
                  )
                );
              })}
            </div>
          </section>
        </div>

        <section className="learn-voicing-section" aria-label="Chord voicings">
          <div className="learn-section-heading">
            <div>
              <span className="learn-curriculum-eyebrow">05 / Voicings</span>
              <h3>Play the harmony</h3>
            </div>
            <p>{uiCopy.GenreCurriculum_Sixstring_standard_tuning_low_E_at}</p>
          </div>
          {!inStandardTuning && (
            <div className="learn-shape-warning" role="status">
              <strong>Standard-tuning shapes only.</strong>
              <span>
                {uiCopy.GenreCurriculum_The_diagrams_below_remain_E_A}
                {tuningLabels[tuning] || tuning}
                {uiCopy.GenreCurriculum_Use_the_tuningaware_fretboard_to_find}
              </span>
              {onTuningSelect && (
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => onTuningSelect("standard")}
                >
                  Use standard tuning for shapes
                </button>
              )}
            </div>
          )}
          <div className="learn-chord-grid">
            {chords.map((chord) => (
              <ChordCard
                leftHanded={leftHanded}
                key={chord.id}
                chord={chord}
                onSelect={showChord}
                disabled={disabled || !inStandardTuning || !onChordSelect}
              />
            ))}
          </div>
        </section>

        <div className="learn-reference-library">
          <details
            open={selected.id === "blues" ? true : undefined}
            key={`pent-${selected.id}`}
          >
            <summary>
              {uiCopy.GenreCurriculum_Five_connected_minor_pentatonic_boxes}
              {noteName(keyRoot)}
            </summary>
            <PentatonicBoxes root={keyRoot} />
          </details>
          <details>
            <summary>
              {uiCopy.GenreCurriculum_Essential_open_chords_fixed_concert_keys}
            </summary>
            <p className="learn-reference-note">
              {
                uiCopy.GenreCurriculum_These_eight_references_retain_their_written
              }
            </p>
            <div className="learn-chord-grid">
              {OPEN_CHORDS.map((chord) => (
                <ChordCard
                  leftHanded={leftHanded}
                  key={chord.id}
                  chord={chord}
                  onSelect={showChord}
                  disabled={disabled || !inStandardTuning || !onChordSelect}
                />
              ))}
            </div>
          </details>
          <details>
            <summary>CAGED · five major forms of {noteName(keyRoot)}</summary>
            <p className="learn-reference-note">
              All five grips below spell {noteName(keyRoot)}
              {uiCopy.GenreCurriculum_major_in_standard_tuning_Their_CAGED}
            </p>
            <div className="learn-chord-grid">
              {["cagedC", "cagedA", "cagedG", "cagedE", "cagedD"].map(
                (shape) => {
                  const chord = getChordVoicing(shape, keyRoot);
                  return (
                    <ChordCard
                      leftHanded={leftHanded}
                      key={shape}
                      chord={chord}
                      onSelect={showChord}
                      disabled={disabled || !inStandardTuning || !onChordSelect}
                    />
                  );
                },
              )}
            </div>
          </details>
          <details>
            <summary>Seven modes · compare interval formulas</summary>
            <p className="learn-reference-note">
              {uiCopy.GenreCurriculum_Compare_each_mode_against_the_same}
              {noteName(keyRoot)}
              {uiCopy.GenreCurriculum_The_formula_shows_which_notes_changed}
            </p>
            <div className="learn-mode-grid">
              {modeIds.map((modeId) => {
                const scale = SCALE_REFERENCE.find(
                  (item) => item.id === modeId,
                );
                return (
                  <button
                    key={modeId}
                    type="button"
                    disabled={disabled || !onScaleSelect}
                    onClick={() => onScaleSelect?.(modeId)}
                  >
                    <strong>{scale.name}</strong>
                    <span>{scale.formula}</span>
                    <small>
                      {getScaleNoteNames(modeId, keyRoot).join(" · ")}
                    </small>
                  </button>
                );
              })}
            </div>
          </details>
        </div>
      </div>
    </section>
  );
}
