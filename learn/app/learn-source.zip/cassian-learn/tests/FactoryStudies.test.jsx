import React from "react";
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import ToneGuide from "../src/ToneGuide.jsx";
import references from "../src/factoryStudyReferences.json";

afterEach(cleanup);
const selected = references.studies.find(
  (row) => row.searchTerm === "Clean Glass",
);
const choose = () =>
  fireEvent.change(screen.getByLabelText("Tone study"), {
    target: { value: selected.id },
  });

it("ships 21 versioned public preset references with no model or private fields", () => {
  expect(references.minimumVersion).toBe("1.2.1");
  expect(references.author).toBe("Crazaloth");
  expect(references.studies).toHaveLength(21);
  expect(new Set(references.studies.map((row) => row.presetId)).size).toBe(21);
  for (const row of references.studies) {
    expect(Object.keys(row).sort()).toEqual([
      "id",
      "name",
      "presetId",
      "searchTerm",
    ]);
    expect(row.id).toBe("study." + row.presetId);
  }
});

it("describes the actual 1.2.1 sound-chooser workflow and capture controls", () => {
  render(<ToneGuide pathway="blues" />);
  choose();
  const guide = screen.getByRole("region", { name: "Tone crafting guide" });
  expect(guide.textContent).toContain(
    "In Cassian 1.2.1, search the sound chooser for “Clean Glass”",
  );
  expect(screen.getByRole("heading", { name: selected.name })).toBeTruthy();
  expect(guide.textContent).toContain("Input, Output and Bypass");
  expect(guide.textContent).not.toContain("Depth / Resonance");
});

it("copies a manual study reference without native control overrides", async () => {
  const writeText = vi.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", {
    configurable: true,
    value: { writeText },
  });
  render(<ToneGuide pathway="blues" />);
  choose();
  fireEvent.click(screen.getByRole("button", { name: "Copy study" }));
  expect(await screen.findByText("Study copied.")).toBeTruthy();
  const text = writeText.mock.calls[0][0];
  expect(text).toContain(selected.name);
  expect(text).toContain("Cassian 1.2.1");
  expect(text).toContain("Search the sound chooser for: Clean Glass");
  expect(text).not.toMatch(/AMP_|BOARD_|modelId|[A-Z]:\\Users/);
});

it("retains a readable reference when clipboard access fails", async () => {
  Object.defineProperty(navigator, "clipboard", {
    configurable: true,
    value: { writeText: vi.fn().mockRejectedValue(Error()) },
  });
  render(<ToneGuide pathway="blues" />);
  choose();
  fireEvent.click(screen.getByRole("button", { name: "Copy study" }));
  expect(
    await screen.findByText(
      "Clipboard unavailable. Select and copy the study below.",
    ),
  ).toBeTruthy();
  expect(screen.queryByText("Study copied.")).toBeNull();
});
