import React, { useState } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  within,
} from "@testing-library/react";
import Fretboard from "../src/Fretboard.jsx";
import {
  createRetainedViewStore,
  RetainedViewBoundary,
} from "../src/retainedViewState.js";
import {
  LEARN_TUNINGS,
  LEARN_SCALES,
  PEARL_FRETS,
  getFretMidi,
  midiNoteName,
  getRelativeInterval,
  intervalName,
  getLearnScale,
  getPentatonicBox,
  isInPosition,
  getPositionOptions,
  canShowChordShape,
} from "../src/fretboardTheory.js";

afterEach(cleanup);
const cell = (container, stringIndex, fret) =>
  container.querySelector(
    '[data-string-index="' + stringIndex + '"][data-fret="' + fret + '"]',
  );
const expectedTunings = {
  "eight-standard": [30, 35, 40, 45, 50, 55, 59, 64],
  "bass-four": [28, 33, 38, 43],
  "bass-five": [23, 28, 33, 38, 43],
  standard: [40, 45, 50, 55, 59, 64],
  "drop-d": [38, 45, 50, 55, 59, 64],
  facgce: [41, 45, 48, 55, 60, 64],
  dadgad: [38, 45, 50, 55, 57, 62],
  "open-d": [38, 45, 50, 54, 57, 62],
  "drop-c": [36, 43, 48, 53, 57, 62],
  "seven-standard": [35, 40, 45, 50, 55, 59, 64],
  daeacse: [38, 45, 52, 57, 61, 64],
  cgdgbd: [36, 43, 50, 55, 59, 62],
};
function ControlledBoard({ initial = {}, chord = null }) {
  const [root, setRoot] = useState(initial.root ?? 4);
  const [tuning, setTuning] = useState(initial.tuning ?? "standard");
  const [scale, setScale] = useState(initial.scale ?? "minor-pentatonic");
  const [position, setPosition] = useState("all");
  return (
    <Fretboard
      root={root}
      onRootChange={setRoot}
      tuning={tuning}
      onTuningChange={setTuning}
      scale={scale}
      onScaleChange={setScale}
      position={position}
      onPositionChange={setPosition}
      chord={chord}
    />
  );
}

describe("concert pitch and interval arithmetic", () => {
  it.each(Object.entries(expectedTunings))(
    "%s has correct open strings and all frets through two octaves",
    (id, expected) => {
      expect(LEARN_TUNINGS.find((item) => item.id === id).notes).toEqual(
        expected,
      );
      expected.forEach((openMidi, stringIndex) => {
        for (let fret = 0; fret <= 24; fret += 1) {
          expect(getFretMidi(id, stringIndex, fret)).toBe(openMidi + fret);
        }
        expect(getFretMidi(id, stringIndex, 12)).toBe(openMidi + 12);
        expect(getFretMidi(id, stringIndex, 24)).toBe(openMidi + 24);
      });
    },
  );
  it("names MIDI pitches with the correct octaves and rejects positions outside the neck", () => {
    expect(midiNoteName(35)).toBe("B1");
    expect(midiNoteName(40)).toBe("E2");
    expect(midiNoteName(60)).toBe("C4");
    expect(midiNoteName(88)).toBe("E6");
    expect(getFretMidi("standard", 6, 0)).toBe(null);
    expect(getFretMidi("standard", 0, -1)).toBe(null);
    expect(getFretMidi("standard", 0, 25)).toBe(null);
  });
  it("measures every semitone relative to the chosen root, including below the root", () => {
    expect(
      Array.from({ length: 12 }, (_, step) =>
        getRelativeInterval(57 + step, 9),
      ),
    ).toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
    expect(getRelativeInterval(40, 9)).toBe(7);
    expect(getRelativeInterval(38, 4)).toBe(10);
    expect(intervalName(6, "lydian")).toBe("#4");
    expect(intervalName(6, "blues")).toBe("b5");
    expect(intervalName(0)).toBe("1"); // Theory formula spelling remains unchanged.
    expect(getLearnScale("major").id).toBe("ionian");
    expect(getLearnScale("natural-minor").id).toBe("aeolian");
    expect(
      LEARN_SCALES.find((item) => item.id === "harmonic-minor").intervals,
    ).toEqual([0, 2, 3, 5, 7, 8, 11]);
    expect(
      LEARN_SCALES.filter((item) =>
        [
          "ionian",
          "dorian",
          "phrygian",
          "lydian",
          "mixolydian",
          "aeolian",
          "locrian",
        ].includes(item.id),
      ),
    ).toHaveLength(7);
  });
});

describe("pentatonic position contracts", () => {
  it("maps all five A-minor boxes to the conventional standard-E frets", () => {
    const expected = [
      [
        [5, 8],
        [5, 7],
        [5, 7],
        [5, 7],
        [5, 8],
        [5, 8],
      ],
      [
        [8, 10],
        [7, 10],
        [7, 10],
        [7, 9],
        [8, 10],
        [8, 10],
      ],
      [
        [10, 12],
        [10, 12],
        [10, 12],
        [9, 12],
        [10, 13],
        [10, 12],
      ],
      [
        [12, 15],
        [12, 15],
        [12, 14],
        [12, 14],
        [13, 15],
        [12, 15],
      ],
      [
        [15, 17],
        [15, 17],
        [14, 17],
        [14, 17],
        [15, 17],
        [15, 17],
      ],
    ];
    expected.forEach((frets, index) =>
      expect(getPentatonicBox(9, "minor-pentatonic", index + 1).frets).toEqual(
        frets,
      ),
    );
    expect(getPentatonicBox(6, "major-pentatonic", 1).frets).toEqual([
      [2, 4],
      [1, 4],
      [1, 4],
      [1, 3],
      [2, 4],
      [2, 4],
    ]);
  });
  it("keeps every box in every key in range and on the selected pentatonic scale", () => {
    for (const [scale, allowed] of [
      ["minor-pentatonic", [0, 3, 5, 7, 10]],
      ["major-pentatonic", [0, 2, 4, 7, 9]],
    ]) {
      for (let root = 0; root < 12; root += 1) {
        for (let box = 1; box <= 5; box += 1) {
          getPentatonicBox(root, scale, box).frets.forEach(
            (pair, stringIndex) => {
              expect(pair).toHaveLength(2);
              pair.forEach((fret) => {
                expect(fret).toBeGreaterThanOrEqual(0);
                expect(fret).toBeLessThanOrEqual(24);
                expect(allowed).toContain(
                  (expectedTunings.standard[stringIndex] + fret - root + 120) %
                    12,
                );
                expect(
                  isInPosition(stringIndex, fret, {
                    tuningId: "standard",
                    scaleId: scale,
                    root,
                    position: String(box),
                  }),
                ).toBe(true);
              });
            },
          );
        }
      }
    }
  });
  it(
    "uses honest fret windows when the tuning or scale does not support t" +
      "hose standard-E boxes",
    () => {
      expect(
        getPositionOptions("standard", "minor-pentatonic", 9)[1].name,
      ).toBe("Box 1 · frets 5–8");
      expect(getPositionOptions("facgce", "minor-pentatonic", 9)[1].name).toBe(
        "Window 1 · frets 0–4",
      );
      expect(getPositionOptions("standard", "dorian", 9)[5].name).toBe(
        "Window 5 · frets 20–24",
      );
      expect(
        isInPosition(0, 4, {
          tuningId: "drop-d",
          scaleId: "minor-pentatonic",
          root: 9,
          position: "1",
        }),
      ).toBe(true);
      expect(
        isInPosition(0, 5, {
          tuningId: "drop-d",
          scaleId: "minor-pentatonic",
          root: 9,
          position: "1",
        }),
      ).toBe(false);
    },
  );
});

describe("interactive neck", () => {
  it("renders 25 positions per string and the correct single and double pearl markers", () => {
    const { container } = render(<Fretboard />);
    expect(screen.getAllByRole("gridcell")).toHaveLength(150);
    expect(
      [...container.querySelectorAll("[data-marker-fret]")].map((node) =>
        Number(node.dataset.markerFret),
      ),
    ).toEqual(PEARL_FRETS);
    for (const fret of PEARL_FRETS) {
      expect(
        container.querySelectorAll('[data-marker-fret="' + fret + '"] circle'),
      ).toHaveLength(fret === 12 || fret === 24 ? 2 : 1);
    }
    expect(cell(container, 0, 0).dataset.midi).toBe("40");
    expect(cell(container, 0, 12).dataset.midi).toBe("52");
    expect(cell(container, 0, 24).dataset.midi).toBe("64");
    expect(cell(container, 5, 24).dataset.midi).toBe("88");
  });
  it("updates pitch, tone membership and root highlighting from tuning and root controls", () => {
    const { container } = render(<ControlledBoard />);
    expect(cell(container, 0, 0).dataset.root).toBe("true");
    fireEvent.change(screen.getByLabelText("Tuning"), {
      target: { value: "drop-d" },
    });
    expect(cell(container, 0, 0).dataset.midi).toBe("38");
    expect(cell(container, 0, 0).dataset.root).toBe("false");
    fireEvent.change(screen.getByLabelText("Root note"), {
      target: { value: "2" },
    });
    expect(cell(container, 0, 0).dataset.root).toBe("true");
    expect(cell(container, 0, 12).dataset.root).toBe("true");
    fireEvent.click(cell(container, 0, 0));
    expect(screen.getByLabelText("Selected fret").textContent).toContain("D2");
    expect(screen.getByLabelText("Selected fret").textContent).toContain(
      "MIDI 38",
    );
    fireEvent.change(screen.getByLabelText("Tuning"), {
      target: { value: "seven-standard" },
    });
    expect(screen.getAllByRole("gridcell")).toHaveLength(175);
    expect(cell(container, 0, 0).dataset.midi).toBe("35");
  });
  it("switches visible labels between notes and scale intervals without changing pitches", () => {
    const { container } = render(
      <Fretboard root={9} scale="minor-pentatonic" />,
    );
    expect(cell(container, 0, 8).textContent).toBe("C");
    fireEvent.click(screen.getByRole("button", { name: "Intervals" }));
    expect(cell(container, 0, 8).textContent).toBe("b3");
    expect(cell(container, 0, 5).textContent).toBe("R");
    expect(cell(container, 0, 5).getAttribute("aria-label")).toContain(
      "interval R",
    );
    fireEvent.click(cell(container, 0, 5));
    expect(screen.getByLabelText("Selected fret").textContent).toContain(
      "Interval R",
    );
    expect(cell(container, 0, 8).dataset.midi).toBe("48");
    fireEvent.click(screen.getByRole("button", { name: "Notes" }));
    expect(cell(container, 0, 8).textContent).toBe("C");
  });
  it("provides one neck tab stop and arrow, Home, End and Enter keyboard navigation", () => {
    const { container } = render(<Fretboard />);
    expect(
      container.querySelectorAll('[role="gridcell"][tabindex="0"]'),
    ).toHaveLength(1);
    const start = cell(container, 5, 0);
    start.focus();
    fireEvent.keyDown(start, { key: "ArrowRight" });
    expect(document.activeElement).toBe(cell(container, 5, 1));
    fireEvent.keyDown(document.activeElement, { key: "ArrowDown" });
    expect(document.activeElement).toBe(cell(container, 4, 1));
    fireEvent.keyDown(document.activeElement, { key: "End" });
    expect(document.activeElement).toBe(cell(container, 4, 24));
    fireEvent.keyDown(document.activeElement, { key: "Enter" });
    expect(screen.getByLabelText("Selected fret").textContent).toContain("B5");
    fireEvent.keyDown(document.activeElement, { key: "Home" });
    expect(document.activeElement).toBe(cell(container, 4, 0));
    expect(
      container.querySelectorAll('[role="gridcell"][tabindex="0"]'),
    ).toHaveLength(1);
  });
  it("mirrors the fret coordinates and keyboard direction for a left-handed view", () => {
    const { container } = render(<Fretboard />);
    expect(Number(cell(container, 0, 0).dataset.positionX)).toBeLessThan(
      Number(cell(container, 0, 24).dataset.positionX),
    );
    fireEvent.click(screen.getByLabelText("Left-handed view"));
    expect(Number(cell(container, 0, 0).dataset.positionX)).toBeGreaterThan(
      Number(cell(container, 0, 24).dataset.positionX),
    );
    expect(cell(container, 0, 0).dataset.midi).toBe("40");
    fireEvent.click(cell(container, 0, 12));
    fireEvent.keyDown(document.activeElement, { key: "ArrowLeft" });
    expect(document.activeElement).toBe(cell(container, 0, 13));
    fireEvent.keyDown(document.activeElement, { key: "ArrowRight" });
    expect(document.activeElement).toBe(cell(container, 0, 12));
  });
  it(
    "scopes notes to a pentatonic box and reinterprets the same position " +
      "as a window after retuning",
    () => {
      const { container } = render(<ControlledBoard initial={{ root: 9 }} />);
      fireEvent.change(screen.getByLabelText("Position"), {
        target: { value: "1" },
      });
      expect(cell(container, 0, 5).dataset.tone).toBe("true");
      expect(cell(container, 0, 8).dataset.tone).toBe("true");
      expect(cell(container, 0, 17).dataset.tone).toBe("false");
      fireEvent.change(screen.getByLabelText("Tuning"), {
        target: { value: "facgce" },
      });
      expect(screen.getByText(/Fret window for this tuning/)).toBeTruthy();
      expect(cell(container, 0, 0).dataset.midi).toBe("41");
      expect(cell(container, 0, 4).dataset.tone).toBe("true"); // F2 + 4 = A2, new tonic.
      expect(cell(container, 0, 5).dataset.tone).toBe("false"); // outside the selected 0–4 window.
    },
  );
  it("shows only a matching chord shape and recalculates chord tones for alternate tunings", () => {
    const chord = {
      name: "A minor",
      intervals: [0, 3, 7],
      baseRoot: 9,
      tuning: "standard",
      frets: [null, 0, 2, 2, 1, 0],
    };
    const { container, rerender } = render(
      <Fretboard root={9} chord={chord} />,
    );
    expect(container.querySelectorAll('[data-shape="true"]')).toHaveLength(5);
    expect(cell(container, 1, 0).dataset.root).toBe("true");
    rerender(<Fretboard root={9} tuning="facgce" chord={chord} />);
    expect(container.querySelectorAll('[data-shape="true"]')).toHaveLength(0);
    expect(cell(container, 2, 0).dataset.midi).toBe("48");
    expect(cell(container, 2, 0).dataset.tone).toBe("true"); // C3 is still a concert A-minor chord tone.
    expect(screen.getByText(/reference fingering is hidden/)).toBeTruthy();
    expect(canShowChordShape(chord, "standard", 0)).toBe(false);
    expect(canShowChordShape(chord, "seven-standard", 9)).toBe(false);
  });
  it("inspects B major in a global E lesson without changing the lesson key", () => {
    const chord = {
      name: "B major",
      intervals: [0, 4, 7],
      baseRoot: 11,
      tuning: "standard",
      frets: [null, 2, 4, 4, 4, 2],
    };
    const { container } = render(<Fretboard root={4} chord={chord} />);
    expect(screen.getByLabelText("Root note").value).toBe("4");
    expect(container.querySelectorAll('[data-shape="true"]')).toHaveLength(5);
    expect(cell(container, 1, 2).dataset.root).toBe("true"); // B2, the chord tonic.
    expect(cell(container, 0, 0).dataset.root).toBe("false"); // E2 is outside B major.
    expect(cell(container, 0, 0).dataset.tone).toBe("false");
    expect(cell(container, 2, 4).dataset.interval).toBe("7"); // F#3 is the fifth.
    expect(cell(container, 4, 4).dataset.tone).toBe("true"); // D#4 is the third.
  });
  it("retains neck labels, orientation and selection across remounts within each app store", () => {
    const appA = createRetainedViewStore();
    const appB = createRetainedViewStore();
    const mount = (store) =>
      render(
        <RetainedViewBoundary store={store}>
          <Fretboard />
        </RetainedViewBoundary>,
      );
    let view = mount(appA);
    fireEvent.click(screen.getByRole("button", { name: "Intervals" }));
    fireEvent.click(screen.getByLabelText("Left-handed view"));
    fireEvent.click(cell(view.container, 2, 17));
    expect(screen.getByLabelText("Selected fret").textContent).toContain(
      "fret 17",
    );
    view.unmount();
    expect(appA.listenerCount()).toBe(0);

    view = mount(appB);
    expect(
      screen
        .getByRole("button", { name: "Notes" })
        .getAttribute("aria-pressed"),
    ).toBe("true");
    expect(screen.getByLabelText("Left-handed view").checked).toBe(false);
    expect(cell(view.container, 5, 0).getAttribute("aria-selected")).toBe(
      "true",
    );
    fireEvent.click(cell(view.container, 4, 7));
    view.unmount();
    expect(appB.listenerCount()).toBe(0);

    view = mount(appA);
    expect(
      screen
        .getByRole("button", { name: "Intervals" })
        .getAttribute("aria-pressed"),
    ).toBe("true");
    expect(screen.getByLabelText("Left-handed view").checked).toBe(true);
    expect(cell(view.container, 2, 17).getAttribute("aria-selected")).toBe(
      "true",
    );
    expect(
      Number(cell(view.container, 0, 0).dataset.positionX),
    ).toBeGreaterThan(Number(cell(view.container, 0, 24).dataset.positionX));
    expect(screen.getByLabelText("Selected fret").textContent).toContain("G4");
    expect(screen.getByLabelText("Selected fret").textContent).toContain(
      "fret 17",
    );
    view.unmount();

    view = mount(appB);
    expect(
      screen
        .getByRole("button", { name: "Notes" })
        .getAttribute("aria-pressed"),
    ).toBe("true");
    expect(screen.getByLabelText("Left-handed view").checked).toBe(false);
    expect(cell(view.container, 4, 7).getAttribute("aria-selected")).toBe(
      "true",
    );
    view.unmount();
    expect(appA.listenerCount()).toBe(0);
    expect(appB.listenerCount()).toBe(0);
  });
  it("has controlled callbacks and no duplicate SVG IDs across separate instances", () => {
    const handlers = {
      onRootChange: vi.fn(),
      onTuningChange: vi.fn(),
      onScaleChange: vi.fn(),
      onPositionChange: vi.fn(),
    };
    const { container } = render(
      <>
        <Fretboard {...handlers} />
        <Fretboard />
      </>,
    );
    const first = within(
      screen.getAllByRole("region", { name: "Interactive fretboard" })[0],
    );
    fireEvent.change(first.getByLabelText("Root note"), {
      target: { value: "7" },
    });
    fireEvent.change(first.getByLabelText("Tuning"), {
      target: { value: "dadgad" },
    });
    fireEvent.change(first.getByLabelText("Scale / mode"), {
      target: { value: "lydian" },
    });
    fireEvent.change(first.getByLabelText("Position"), {
      target: { value: "3" },
    });
    expect(handlers.onRootChange).toHaveBeenCalledWith(7);
    expect(handlers.onTuningChange).toHaveBeenCalledWith("dadgad");
    expect(handlers.onScaleChange).toHaveBeenCalledWith("lydian");
    expect(handlers.onPositionChange).toHaveBeenCalledWith("3");
    const ids = [...container.querySelectorAll("svg [id]")].map(
      (node) => node.id,
    );
    expect(new Set(ids).size).toBe(ids.length);
  });
});
