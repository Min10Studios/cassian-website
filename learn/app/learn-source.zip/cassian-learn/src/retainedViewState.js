import {
  createContext,
  createElement,
  useContext,
  useRef,
  useSyncExternalStore,
} from "react";

const Context = createContext(null);
// Per app/editor session, never a module-global draft or a persistence format.
// Unmounted views retain their bounded model fields, not DOM, effects or listeners.
export function createRetainedViewStore() {
  const fields = new Map(),
    refs = new Map(),
    identity = (scope, key) => JSON.stringify([scope, key]);
  return {
    field(scope, key, initial) {
      const id = identity(scope, key);
      if (!fields.has(id)) {
        let value = typeof initial === "function" ? initial() : initial;
        const listeners = new Set();
        fields.set(id, {
          read: () => value,
          subscribe: (listener) => {
            listeners.add(listener);
            return () => listeners.delete(listener);
          },
          write: (update) => {
            const next = typeof update === "function" ? update(value) : update;
            if (Object.is(next, value)) return;
            value = next;
            [...listeners].forEach((listener) => listener());
          },
          listenerCount: () => listeners.size,
        });
      }
      return fields.get(id);
    },
    ref(scope, key, initial) {
      const id = identity(scope, key);
      if (!refs.has(id)) refs.set(id, { current: initial });
      return refs.get(id);
    },
    listenerCount: () =>
      [...fields.values()].reduce(
        (sum, field) => sum + field.listenerCount(),
        0,
      ),
  };
}
export function RetainedViewBoundary({ children, store }) {
  const inherited = useContext(Context),
    own = useRef(null);
  if (!store && !inherited && !own.current)
    own.current = createRetainedViewStore();
  const selected = store ?? inherited ?? own.current;
  return selected === inherited
    ? children
    : createElement(Context.Provider, { value: selected }, children);
}
function useStore() {
  const inherited = useContext(Context),
    own = useRef(null);
  if (!inherited && !own.current) own.current = createRetainedViewStore();
  return inherited ?? own.current;
}
export function useRetainedState(scope, key, initial) {
  const field = useStore().field(scope, key, initial);
  const value = useSyncExternalStore(field.subscribe, field.read, field.read);
  return [value, field.write];
}
export function useRetainedRef(scope, key, initial) {
  return useStore().ref(scope, key, initial);
}
