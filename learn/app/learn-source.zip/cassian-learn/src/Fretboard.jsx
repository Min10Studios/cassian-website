import * as uiCopy from "./copy.js";
import React, { useRef, useEffect } from "react";
import { useRetainedState } from "./retainedViewState.js";
import {
  LEARN_KEYS,
  LEARN_TUNINGS,
  LEARN_SCALES,
  NOTE_NAMES,
  PEARL_FRETS,
  FRETBOARD_WIDTH,
  getLearnTuning,
  getLearnScale,
  pitchClass,
  getFretMidi,
  midiNoteName,
  intervalName,
  getRelativeInterval,
  getFretX,
  getPositionOptions,
  isInPosition,
  isPentatonicBox,
  canShowChordShape,
} from "./fretboardTheory.js";

export default function Fretboard({
  root = 4,
  onRootChange,
  tuning = "standard",
  onTuningChange,
  scale = "minor-pentatonic",
  onScaleChange,
  position = "all",
  onPositionChange,
  chord = null,
  leftHanded: controlledHand,
  onHandednessChange,
  onNoteActivate,
  compactControls = false,
}) {
  const [display, setDisplay] = useRetainedState(
    "learn-neck",
    "display",
    "notes",
  );
  const [savedHand, setSavedHand] = useRetainedState(
    "learn-neck",
    "left-handed",
    false,
  );
  const leftHanded = controlledHand ?? savedHand;
  const setLeftHanded = onHandednessChange ?? setSavedHand;
  const [selection, setSelection] = useRetainedState(
    "learn-neck",
    "selection",
    () => ({
      stringIndex: getLearnTuning(tuning).notes.length - 1,
      fret: 0,
    }),
  );
  const noteRefs = useRef(new Map());
  const scrollRef = useRef(null);
  const selectedTuning = getLearnTuning(tuning);
  const selectedScale = getLearnScale(scale);
  const keyRoot = pitchClass(root);
  const tonic = Number.isFinite(chord?.baseRoot)
    ? pitchClass(chord.baseRoot)
    : keyRoot;
  const stringCount = selectedTuning.notes.length;
  const current = {
    stringIndex: Math.min(selection.stringIndex, stringCount - 1),
    fret: selection.fret,
  };
  const currentMidi = getFretMidi(
    selectedTuning,
    current.stringIndex,
    current.fret,
  );
  const currentInterval = getRelativeInterval(currentMidi, tonic);
  const fretIntervalLabel = (interval) =>
    interval === 0 ? "R" : intervalName(interval, selectedScale.id);
  const shapeVisible = canShowChordShape(chord, selectedTuning.id, tonic);
  const intervals = new Set(
    (chord?.intervals || selectedScale.intervals).map(pitchClass),
  );
  const positionOptions = getPositionOptions(
    selectedTuning.id,
    selectedScale.id,
    keyRoot,
  );
  const boardHeight = 102 + (stringCount - 1) * 48;
  const stringY = (index) => 56 + (stringCount - 1 - index) * 48;
  const idFor = (stringIndex, fret) => stringIndex + "-" + fret;
  const selectNote = (stringIndex, fret, focus = true) => {
    setSelection({ stringIndex, fret });
    if (focus) {
      const node = noteRefs.current.get(idFor(stringIndex, fret));
      node?.focus?.();
      node?.scrollIntoView?.({ block: "nearest", inline: "nearest" });
    }
  };
  const navigate = (event, stringIndex, fret) => {
    let nextString = stringIndex;
    let nextFret = fret;
    switch (event.key) {
      case "ArrowRight":
        nextFret += leftHanded ? -1 : 1;
        break;
      case "ArrowLeft":
        nextFret += leftHanded ? 1 : -1;
        break;
      case "ArrowUp":
        nextString += 1;
        break;
      case "ArrowDown":
        nextString -= 1;
        break;
      case "Home":
        nextFret = 0;
        break;
      case "End":
        nextFret = 24;
        break;
      case "Enter":
      case " ":
        event.preventDefault();
        selectNote(stringIndex, fret);
        onNoteActivate?.(getFretMidi(selectedTuning, stringIndex, fret));
        return;
      default:
        return;
    }
    event.preventDefault();
    selectNote(
      Math.min(stringCount - 1, Math.max(0, nextString)),
      Math.min(24, Math.max(0, nextFret)),
    );
  };
  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const reveal = () => {
      const svg = container.querySelector("svg");
      if (!svg) return;
      const frets = Array.from({ length: 25 }, (_, fret) => fret).filter(
        (fret) =>
          selectedTuning.notes.some((_, index) =>
            isInPosition(index, fret, {
              tuningId: selectedTuning.id,
              scaleId: selectedScale.id,
              root: keyRoot,
              position,
            }),
          ),
      );
      const target =
        position === "all" || !frets.length
          ? current.fret
          : (Math.min(...frets) + Math.max(...frets)) / 2;
      container.scrollLeft =
        (getFretX(target, leftHanded) * svg.getBoundingClientRect().width) /
          FRETBOARD_WIDTH -
        container.clientWidth / 2;
    };
    reveal();
    const observer =
      typeof ResizeObserver === "function" ? new ResizeObserver(reveal) : null;
    observer?.observe(container);
    window.addEventListener("resize", reveal);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", reveal);
    };
  }, [
    leftHanded,
    selectedTuning,
    selectedScale,
    keyRoot,
    position,
    current.fret,
  ]);
  const currentString = stringCount - current.stringIndex;
  return (
    <section className="learn-fretboard" aria-label="Interactive fretboard">
      <div className="learn-fretboard__heading">
        <div>
          <span className="learn-fretboard__eyebrow">
            NECK ATLAS / 24 FRETS
          </span>
          <h2>Find the next note.</h2>
        </div>
        <span className="learn-fretboard__tuning-stamp">
          {selectedTuning.openNotes.join(" · ")}
        </span>
      </div>
      <div className="learn-fretboard__controls">
        {!compactControls && (
          <>
            <label>
              Root note
              <select
                value={keyRoot}
                onChange={(event) => onRootChange?.(Number(event.target.value))}
              >
                {LEARN_KEYS.map((key) => (
                  <option key={key.value} value={key.value}>
                    {key.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Tuning
              <select
                value={selectedTuning.id}
                onChange={(event) => onTuningChange?.(event.target.value)}
              >
                {LEARN_TUNINGS.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
            </label>
          </>
        )}
        <label>
          Scale / mode
          <select
            value={selectedScale.id}
            onChange={(event) => onScaleChange?.(event.target.value)}
          >
            {LEARN_SCALES.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Position
          <select
            value={String(position)}
            onChange={(event) => onPositionChange?.(event.target.value)}
          >
            {positionOptions.map((item) => (
              <option key={item.value} value={item.value}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="learn-fretboard__tools">
        <div className="learn-fretboard__display" aria-label="Fret labels">
          <button
            type="button"
            aria-pressed={display === "notes"}
            onClick={() => setDisplay("notes")}
          >
            Notes
          </button>
          <button
            type="button"
            aria-pressed={display === "intervals"}
            onClick={() => setDisplay("intervals")}
          >
            Intervals
          </button>
        </div>
        {!compactControls && (
          <label className="learn-fretboard__handedness">
            <input
              type="checkbox"
              checked={leftHanded}
              onChange={(event) => setLeftHanded(event.target.checked)}
            />
            Left-handed view
          </label>
        )}
        <span className="learn-fretboard__legend">
          <i /> Root <b /> {chord ? "Chord tone" : "Scale tone"}
        </span>
      </div>
      {chord && (
        <p className="learn-fretboard__chord-note" role="status">
          {chord.name} · root {NOTE_NAMES[tonic]}:{" "}
          {shapeVisible
            ? "outlined notes show this voicing in " + selectedTuning.name + "."
            : uiCopy.Fretboard_chord_tones_recalculated_for_this_tuning +
              getLearnTuning(chord.tuning).name +
              " in " +
              NOTE_NAMES[pitchClass(chord.baseRoot)] +
              "."}
        </p>
      )}
      {!chord &&
        position !== "all" &&
        !isPentatonicBox(selectedTuning.id, selectedScale.id) && (
          <p className="learn-fretboard__position-note">
            {uiCopy.Fretboard_Fret_window_for_this_tuning_these}
          </p>
        )}
      <div className="learn-fretboard__scroll" ref={scrollRef}>
        <svg
          className="learn-fretboard__neck"
          viewBox={"0 0 " + FRETBOARD_WIDTH + " " + boardHeight}
          role="grid"
          aria-label={
            "24-fret " +
            (tuning.startsWith("bass-") ? "bass" : "guitar") +
            " fretboard, " +
            selectedTuning.name +
            ", " +
            (leftHanded ? "left-handed" : "right-handed")
          }
          aria-rowcount={stringCount}
          aria-colcount={25}
        >
          <rect
            className="learn-fretboard__wood"
            x={leftHanded ? FRETBOARD_WIDTH - 1262 : 79}
            y="28"
            width="1183"
            height={boardHeight - 62}
            rx="3"
          />
          {Array.from({ length: 25 }, (_, fret) => {
            const x = leftHanded
              ? FRETBOARD_WIDTH - (80 + fret * 49)
              : 80 + fret * 49;
            return (
              <line
                key={"wire-" + fret}
                className={
                  fret === 0 ? "learn-fretboard__nut" : "learn-fretboard__wire"
                }
                x1={x}
                x2={x}
                y1="28"
                y2={boardHeight - 34}
              />
            );
          })}
          {PEARL_FRETS.map((fret) => {
            const double = fret === 12 || fret === 24;
            const centerY = (stringY(0) + stringY(stringCount - 1)) / 2;
            return (
              <g
                key={"pearl-" + fret}
                className="learn-fretboard__pearl"
                aria-hidden="true"
                data-marker-fret={fret}
              >
                {double ? (
                  <>
                    <circle
                      cx={getFretX(fret, leftHanded)}
                      cy={centerY - 25}
                      r="6"
                    />
                    <circle
                      cx={getFretX(fret, leftHanded)}
                      cy={centerY + 25}
                      r="6"
                    />
                  </>
                ) : (
                  <circle cx={getFretX(fret, leftHanded)} cy={centerY} r="6" />
                )}
              </g>
            );
          })}
          {Array.from({ length: 25 }, (_, fret) => (
            <text
              key={"number-" + fret}
              className="learn-fretboard__number"
              x={getFretX(fret, leftHanded)}
              y="17"
              textAnchor="middle"
              aria-hidden="true"
            >
              {fret === 0 ? "OPEN" : fret}
            </text>
          ))}
          {selectedTuning.notes.map((openMidi, stringIndex) => {
            const y = stringY(stringIndex);
            return (
              <g
                key={"string-" + stringIndex}
                role="row"
                aria-rowindex={stringCount - stringIndex}
              >
                <line
                  className="learn-fretboard__string"
                  x1="46"
                  x2={FRETBOARD_WIDTH - 46}
                  y1={y}
                  y2={y}
                  strokeWidth={3.4 - (stringIndex / (stringCount - 1)) * 1.8}
                  aria-hidden="true"
                />
                <text
                  className="learn-fretboard__string-name"
                  x={leftHanded ? FRETBOARD_WIDTH - 18 : 18}
                  y={y + 4}
                  textAnchor="middle"
                  aria-hidden="true"
                >
                  {NOTE_NAMES[pitchClass(openMidi)]}
                </text>
                {Array.from({ length: 25 }, (_, fret) => {
                  const midi = getFretMidi(selectedTuning, stringIndex, fret);
                  const relative = getRelativeInterval(midi, tonic);
                  const inPosition = isInPosition(stringIndex, fret, {
                    tuningId: selectedTuning.id,
                    scaleId: selectedScale.id,
                    root: tonic,
                    position,
                  });
                  const isTone =
                    intervals.has(relative) && (Boolean(chord) || inPosition);
                  const isRoot = relative === 0 && isTone;
                  const isShape =
                    shapeVisible && chord.frets[stringIndex] === fret;
                  const isSelected =
                    current.stringIndex === stringIndex &&
                    current.fret === fret;
                  const x = getFretX(fret, leftHanded);
                  const label =
                    "String " +
                    (stringCount - stringIndex) +
                    ", fret " +
                    fret +
                    ", " +
                    midiNoteName(midi) +
                    ", MIDI " +
                    midi +
                    ", interval " +
                    fretIntervalLabel(relative) +
                    (isRoot
                      ? ", root"
                      : isTone
                        ? ", " + (chord ? "chord tone" : "scale tone")
                        : "");
                  return (
                    <g
                      key={fret}
                      ref={(node) => {
                        if (node)
                          noteRefs.current.set(idFor(stringIndex, fret), node);
                        else noteRefs.current.delete(idFor(stringIndex, fret));
                      }}
                      className={
                        "learn-fretboard__note" +
                        (isTone ? " is-tone" : "") +
                        (isRoot ? " is-root" : "") +
                        (isShape ? " is-shape" : "") +
                        (isSelected ? " is-selected" : "")
                      }
                      transform={"translate(" + x + "," + y + ")"}
                      role="gridcell"
                      aria-colindex={fret + 1}
                      aria-selected={isSelected}
                      aria-label={label}
                      tabIndex={isSelected ? 0 : -1}
                      data-string-index={stringIndex}
                      data-fret={fret}
                      data-midi={midi}
                      data-interval={relative}
                      data-root={Boolean(isRoot)}
                      data-tone={Boolean(isTone)}
                      data-shape={Boolean(isShape)}
                      data-position-x={x}
                      onFocus={() => setSelection({ stringIndex, fret })}
                      onClick={() => {
                        selectNote(stringIndex, fret);
                        onNoteActivate?.(midi);
                      }}
                      onKeyDown={(event) => navigate(event, stringIndex, fret)}
                    >
                      <rect
                        className="learn-fretboard__hit"
                        x="-23"
                        y="-22"
                        width="46"
                        height="44"
                        rx="5"
                      />
                      <circle
                        className="learn-fretboard__tone"
                        r={isTone || isSelected ? 14 : 2.5}
                      />
                      {isShape && (
                        <circle className="learn-fretboard__shape" r="17" />
                      )}
                      {(isTone || isSelected) && (
                        <text
                          className="learn-fretboard__note-label"
                          textAnchor="middle"
                          y="4"
                          aria-hidden="true"
                        >
                          {display === "notes"
                            ? NOTE_NAMES[pitchClass(midi)]
                            : fretIntervalLabel(relative)}
                        </text>
                      )}
                    </g>
                  );
                })}
              </g>
            );
          })}
        </svg>
      </div>
      <div className="learn-fretboard__footer">
        <output
          className="learn-fretboard__readout"
          aria-live="polite"
          aria-atomic="true"
          aria-label="Selected fret"
        >
          <strong>{midiNoteName(currentMidi)}</strong>
          <span>
            String {currentString} ·{" "}
            {current.fret === 0 ? "open" : "fret " + current.fret}
          </span>
          <span>
            Interval {fretIntervalLabel(currentInterval)}
            {currentInterval === 0 ? " · root" : ""}
          </span>
          <span>MIDI {currentMidi}</span>
        </output>
        {onNoteActivate && (
          <button type="button" onClick={() => onNoteActivate(currentMidi)}>
            Hear {midiNoteName(currentMidi)}
          </button>
        )}
        <p>{uiCopy.Fretboard_Click_a_fret_to_inspect_Arrow}</p>
      </div>
    </section>
  );
}
