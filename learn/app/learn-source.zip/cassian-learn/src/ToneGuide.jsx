import { useState } from "react";
import recipes from "./recipeData.json";
import { doctors } from "./doctors.js";

const label = (id) =>
  id
    .replace(/^(AMP_|REVERB_|DELAY_|COMP_|DIST_|CHORUS_)/, "")
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(/^./, (letter) => letter.toUpperCase());
export default function ToneGuide({ pathway }) {
  const recipe = recipes.find((row) => row.id === pathway) ?? recipes[0];
  const [feedback, setFeedback] = useState("");
  const text = [
    recipe.name,
    recipe.amp,
    recipe.description,
    ...Object.entries(recipe.ampControls).map(
      ([id, value]) => `${label(id)}: ${value}`,
    ),
    ...recipe.blocks.map(
      (block) =>
        `${block.type}: ${Object.entries(block.values)
          .map(([id, value]) => `${label(id)} ${value}`)
          .join(", ")}`,
    ),
    recipe.lesson,
    recipe.limitations,
  ].join("\n");
  const copy = async () => {
    try {
      if (!navigator.clipboard?.writeText) throw Error();
      await navigator.clipboard.writeText(text);
      setFeedback("Recipe copied.");
    } catch {
      setFeedback("Clipboard unavailable. Select and copy the recipe below.");
    }
  };
  return (
    <section className="learn-tone-guide" aria-label="Tone crafting guide">
      <div className="learn-card">
        <span className="learn-kicker">Tone recipe · {recipe.genre}</span>
        <h2>{recipe.name}</h2>
        <p>{recipe.description}</p>
        <div className="learn-signal-chain" aria-label="Typical guitar signal chain">
          <span>
            Guitar → Wah / drive → Amp → Cabinet → Modulation → Delay / reverb
          </span>
        </div>
        <p>{recipe.lesson}</p>
        <p className="learn-muted">{recipe.limitations}</p>
        <details>
          <summary>Recipe settings</summary>
          <pre tabIndex="0">{text}</pre>
        </details>
        <button type="button" onClick={copy}>
          Copy recipe
        </button>
        <p role="status">{feedback}</p>
        <p className="learn-muted">
          Dial these settings in Cassian. Reference audio here uses a simple
          synth.
        </p>
      </div>
      <div className="learn-doctors">
        {doctors.map((doctor) => (
          <details className="learn-card" key={doctor.id}>
            <summary>{doctor.title}</summary>
            <p>{doctor.summary}</p>
            <p>{doctor.explanation}</p>
            <strong>Try it on your guitar</strong>
            <p>{doctor.exercise}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
