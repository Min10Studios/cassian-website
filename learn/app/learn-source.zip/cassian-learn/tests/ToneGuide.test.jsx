import React from 'react';
import { afterEach, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import ToneGuide from '../src/ToneGuide.jsx';
import recipes from '../src/recipeData.json';
import { PATHWAYS } from '../src/curriculum.js';
afterEach(cleanup);
it('retains a genuine recipe for every source pathway rather than a placeholder', () => {
  expect(recipes.map(row=>row.id).sort()).toEqual(PATHWAYS.map(row=>row.id).sort());
  expect(recipes.every(row=>row.lesson&&row.limitations&&row.ampControls&&row.blocks)).toBe(true);
});
it('copies the selected real recipe through the Clipboard API', async () => {
  const writeText=vi.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText}});
  render(<ToneGuide pathway="blues" />);
  fireEvent.click(screen.getByRole('button',{name:'Copy recipe'}));
  expect(await screen.findByText('Recipe copied.')).toBeTruthy();
  expect(writeText).toHaveBeenCalledOnce();
  expect(writeText.mock.calls[0][0]).toContain(recipes.find(row=>row.id==='blues').name);
});
it('reports clipboard rejection instead of claiming a copy succeeded', async () => {
  Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:vi.fn().mockRejectedValue(Error())}});
  render(<ToneGuide pathway="blues" />);fireEvent.click(screen.getByRole('button',{name:'Copy recipe'}));
  expect(await screen.findByText('Clipboard unavailable. Select and copy the recipe below.')).toBeTruthy();
  expect(screen.queryByText('Recipe copied.')).toBeNull();
});
