import { guitarStringLabel } from './fretboardTheory.js';
/* eslint-disable jsx-a11y/no-noninteractive-tabindex -- Named horizontal scroll regions need keyboard focus. */
import { getLearnTuning, midiNoteName } from './fretboardTheory.js';
import { useEffect, useRef } from 'react';

export default function ArpeggioNeck({
  view = 'both',
  overview = false,
  path,
  tuning,
  minFret,
  maxFret,
  leftHanded,
  active,
  onPlayNote,
}) {
  const instrument = getLearnTuning(tuning);
  const neckScroll = useRef(null),
    tabScroll = useRef(null);
  const width = overview ? 1100 : Math.max(440, (maxFret - minFret + 1) * 58 + 100),
    height = instrument.notes.length * 36 + 76;
  const x = (fret) => {
    const right = 70 + ((fret - minFret) * (width - 140)) / (maxFret - minFret);
    return leftHanded ? width - right : right;
  };
  const y = (stringIndex) => 58 + (instrument.notes.length - 1 - stringIndex) * 36;
  const unique = [
    ...new Map(path.map((note) => [note.stringIndex + ':' + note.fret, note])).values(),
  ];
  useEffect(() => {
    if (!active) return;
    const neck = neckScroll.current;
    if (neck && !overview) {
      const svg = neck.querySelector('svg');
      const right = 70 + ((active.fret - minFret) * (width - 140)) / (maxFret - minFret);
      const target =
        ((leftHanded ? width - right : right) * svg.getBoundingClientRect().width) / width;
      if (target < neck.scrollLeft + 30 || target > neck.scrollLeft + neck.clientWidth - 30)
        neck.scrollTo?.({ left: Math.max(0, target - neck.clientWidth / 2), behavior: 'auto' });
    }
    const tab = tabScroll.current;
    const cell = tab?.querySelector(`[data-run-index="${active.pathIndex}"]`);
    if (cell) {
      const target =
        cell.getBoundingClientRect().left - tab.getBoundingClientRect().left + tab.scrollLeft;
      if (target < tab.scrollLeft + 70 || target > tab.scrollLeft + tab.clientWidth - 35)
        tab.scrollTo?.({ left: Math.max(0, target - tab.clientWidth / 2), behavior: 'auto' });
    }
  }, [active, minFret, maxFret, width, leftHanded, view, overview]);
  return (
    <>
      {view !== 'tab' && (
        <div
          className={'arp-neck-scroll' + (overview ? ' is-overview' : '')}
          ref={neckScroll}
          tabIndex={0}
          role="region"
          aria-label={
            overview
              ? 'Complete arpeggio fretboard, all frets visible'
              : 'Arpeggio fretboard, scroll horizontally'
          }
        >
          <svg
            className="arp-neck"
            style={{ minWidth: overview ? 0 : width }}
            viewBox={`0 0 ${width} ${height}`}
            role="group"
            aria-label={`${leftHanded ? 'Left' : 'Right'}-handed arpeggio fretboard, ${instrument.name}`}
          >
            <rect
              className="arp-neck-wood"
              x="36"
              y="34"
              width={width - 72}
              height={height - 72}
              rx="5"
            />
            {Array.from({ length: maxFret - minFret + 1 }, (_, index) => {
              const fret = minFret + index;
              return (
                <g key={fret} aria-hidden="true">
                  <line
                    className="arp-fret-wire"
                    x1={x(fret) + (leftHanded ? -23 : 23)}
                    x2={x(fret) + (leftHanded ? -23 : 23)}
                    y1="34"
                    y2={height - 38}
                  />
                  <text className="arp-fret-number" x={x(fret)} y="20" textAnchor="middle">
                    {fret === 0 ? 'OPEN' : fret}
                  </text>
                </g>
              );
            })}
            {instrument.notes.map((note, index) => (
              <g key={index} aria-hidden="true">
                <line
                  className="arp-string"
                  x1="36"
                  x2={width - 36}
                  y1={y(index)}
                  y2={y(index)}
                  strokeWidth={2.5 - index * 0.2}
                />
                <text
                  className="arp-fret-number arp-string-label"
                  x={leftHanded ? width - 16 : 16}
                  y={y(index) + 5}
                  textAnchor="middle"
                >
                  {guitarStringLabel(note, index === instrument.notes.length - 1)}
                </text>
              </g>
            ))}
            {unique.map((note) => {
              const lit = active?.stringIndex === note.stringIndex && active?.fret === note.fret;
              const play = () => onPlayNote(note);
              return (
                <g
                  key={note.stringIndex + ':' + note.fret}
                  role="button"
                  tabIndex={0}
                  aria-label={
                    `Hear ${note.name}${note.octave}, string ` +
                    `${instrument.notes.length - note.stringIndex}, fret ${note.fret}`
                  }
                  data-fret={note.fret}
                  data-string={note.stringIndex}
                  data-x={x(note.fret)}
                  className={`arp-neck-note${note.degree === '1' ? ' is-root' : ''}${lit ? ' is-playing' : ''}`}
                  transform={`translate(${x(note.fret)},${y(note.stringIndex)})`}
                  onClick={play}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      play();
                    }
                  }}
                >
                  <circle r="18" />
                  <text y="-1" textAnchor="middle">
                    {note.name}
                  </text>
                  <text className="arp-note-degree" y="12" textAnchor="middle">
                    {note.degree === '1' ? 'R' : note.degree}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      )}
      {!!path.length && view !== 'neck' && (
        <div
          className="arp-tab-scroll"
          ref={tabScroll}
          tabIndex={0}
          role="region"
          aria-label="Arpeggio tablature, scroll horizontally"
        >
          <table className="arp-tab">
            <caption>
              Play in order · high string at the top
              {leftHanded ? ' · the neck is mirrored; tab reads normally' : ''}
            </caption>
            <thead>
              <tr>
                <th scope="col">Note</th>
                {path.map((note, index) => (
                  <th
                    scope="col"
                    key={index}
                    data-run-index={index}
                    className={active?.pathIndex === index ? 'is-playing' : ''}
                  >
                    {index + 1}
                    <small>
                      {note.name}
                      {note.octave}
                    </small>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...instrument.notes].reverse().map((open, row) => {
                const stringIndex = instrument.notes.length - 1 - row;
                return (
                  <tr key={stringIndex}>
                    <th scope="row">{midiNoteName(open)}</th>
                    {path.map((note, index) => (
                      <td key={index} className={active?.pathIndex === index ? 'is-playing' : ''}>
                        {note.stringIndex === stringIndex ? <strong>{note.fret}</strong> : '—'}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
