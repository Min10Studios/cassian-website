import { useRef, useId } from "react";
import { useRetainedState } from "./retainedViewState.js";
import { noteNameInKey } from "./curriculum.js";
import { NOTE_NAMES } from "./fretboardTheory.js";
import * as uiCopy from "./copy.js";
const FIFTHS = [0, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5];
const PROGRESSIONS = [
  {
    id: "pop",
    name: "Pop four chords",
    formula: "I – V – vi – IV",
    steps: [
      [0, ""],
      [7, ""],
      [9, "m"],
      [5, ""],
    ],
  },
  {
    id: "jazz",
    name: "Jazz ii–V–I",
    formula: "ii7 – V7 – Imaj7",
    steps: [
      [2, "m7"],
      [7, "7"],
      [0, "maj7"],
    ],
  },
  {
    id: "spanish",
    name: "Andalusian cadence",
    formula: "i – ♭VII – ♭VI – V",
    steps: [
      [0, "m"],
      [10, ""],
      [8, ""],
      [7, ""],
    ],
  },
  {
    id: "blues",
    name: "12-bar blues",
    formula: "I7 / IV7 / V7",
    steps: [
      [0, "7"],
      [0, "7"],
      [0, "7"],
      [0, "7"],
      [5, "7"],
      [5, "7"],
      [0, "7"],
      [0, "7"],
      [7, "7"],
      [5, "7"],
      [0, "7"],
      [7, "7"],
    ],
  },
];
export const progressionChords = (root, id) => {
  const selected = PROGRESSIONS.find((row) => row.id === id) ?? PROGRESSIONS[0];
  return selected.steps.map(
    ([interval, suffix]) => noteNameInKey(root, interval) + suffix,
  );
};
export default function TheoryCompass({ root, onRootChange }) {
  const [progression, setProgression] = useRetainedState(
      "learn",
      "progression",
      "pop",
    ),
    buttons = useRef([]),
    id = useId();
  const selected =
    PROGRESSIONS.find((row) => row.id === progression) ?? PROGRESSIONS[0];
  const navigate = (event, index) => {
    const next =
      event.key === "ArrowRight"
        ? (index + 1) % 12
        : event.key === "ArrowLeft"
          ? (index + 11) % 12
          : event.key === "Home"
            ? 0
            : event.key === "End"
              ? 11
              : null;
    if (next === null) return;
    event.preventDefault();
    onRootChange(FIFTHS[next]);
    buttons.current[next]?.focus();
  };
  return (
    <section className="learn-compass learn-panel" aria-label="Theory compass">
      <div className="learn-section-heading">
        <span>THE THEORY COMPASS</span>
        <h2>Find the next chord.</h2>
      </div>
      <div className="learn-compass-body">
        <svg
          viewBox="0 0 300 300"
          aria-label="Interactive circle of fifths"
          role="group"
        >
          <defs>
            <radialGradient id={id}>
              <stop stopColor="#343b37" />
              <stop offset="1" stopColor="#101715" />
            </radialGradient>
          </defs>
          <circle
            cx="150"
            cy="150"
            r="136"
            fill={`url(#${id})`}
            stroke="#83714c"
          />
          <circle cx="150" cy="150" r="88" className="learn-circle-inner" />
          {FIFTHS.map((note, index) => {
            const angle = (index * Math.PI) / 6 - Math.PI / 2,
              x = 150 + 112 * Math.cos(angle),
              y = 150 + 112 * Math.sin(angle);
            return (
              <g
                key={note}
                role="button"
                aria-label={`Circle key ${NOTE_NAMES[note]}`}
                aria-pressed={root === note}
                tabIndex={root === note ? 0 : -1}
                ref={(node) => {
                  buttons.current[index] = node;
                }}
                className={root === note ? "selected" : ""}
                transform={`translate(${x} ${y})`}
                onClick={() => onRootChange(note)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    onRootChange(note);
                  } else navigate(event, index);
                }}
              >
                <circle r="19" />
                <text textAnchor="middle" dominantBaseline="central">
                  {NOTE_NAMES[note]}
                </text>
              </g>
            );
          })}
          <text
            x="150"
            y="144"
            className="learn-circle-root"
            textAnchor="middle"
          >
            {NOTE_NAMES[root]}
          </text>
          <text
            x="150"
            y="171"
            className="learn-circle-caption"
            textAnchor="middle"
          >
            LESSON KEY
          </text>
        </svg>
        <div>
          <label>
            Progression
            <select
              aria-label="Theory progression"
              value={progression}
              onChange={(event) => setProgression(event.target.value)}
            >
              {PROGRESSIONS.map((row) => (
                <option key={row.id} value={row.id}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          <p className="learn-progression-formula">{selected.formula}</p>
          <ol
            className="learn-progression-chords"
            aria-label="Transposed chord progression"
          >
            {progressionChords(root, progression).map((name, index) => (
              <li key={index}>
                <small>{index + 1}</small>
                {name}
              </li>
            ))}
          </ol>
          <p className="learn-subtle">
            {uiCopy.Learn_Move_clockwise_by_fifths_Neighbouring_keys}
          </p>
        </div>
      </div>
    </section>
  );
}
