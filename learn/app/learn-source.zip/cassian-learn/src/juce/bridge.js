// Browser-only adapter. Crazaloth provenance.
export const native = false;
