import { createRoot } from "react-dom/client";
import LearnWeb from "./LearnWeb.jsx";
import "./learn.css";

export { LearnWeb };
export function mountCassianLearn(target, options = {}) {
  if (!target || target.nodeType !== 1)
    throw Error("Cassian Learn needs a host element.");
  if (target.shadowRoot?.childNodes.length)
    throw Error("Cassian Learn is already mounted.");
  const shadow = target.shadowRoot ?? target.attachShadow({ mode: "open" });
  const style = document.createElement("link");
  style.rel = "stylesheet";
  style.href =
    options.stylesUrl ??
    new URL(/* @vite-ignore */ "./cassian-learn.css", import.meta.url).href;
  const container = document.createElement("div");
  shadow.append(style, container);
  const root = createRoot(container);
  root.render(<LearnWeb {...options} />);
  let disposed = false;
  return {
    unmount() {
      if (disposed) return;
      disposed = true;
      root.unmount();
      style.remove();
      container.remove();
    },
  };
}
