import React from "react";
import { afterEach, expect, it } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import LearnWeb from "../src/LearnWeb.jsx";

afterEach(() => {
  cleanup();
  localStorage.clear();
});

const silentAudio = () => ({
  playNotes: async () => true,
  startPulse: async () => true,
  stop() {},
  setTempo() {},
  dispose() {},
});

it("puts keyboard focus on the chosen chord reference and retains it when returning to the scale", () => {
  render(<LearnWeb audioFactory={silentAudio} />);
  fireEvent.click(
    screen.getByRole("button", {
      name: "View E7 E form dominant 7 on fretboard",
    }),
  );
  expect(
    screen
      .getByRole("tab", { name: "Fretboard", exact: true })
      .getAttribute("aria-selected"),
  ).toBe("true");
  expect(document.activeElement).toBe(screen.getByRole("tabpanel"));
  fireEvent.click(screen.getByRole("button", { name: "Return to scale" }));
  expect(document.activeElement).toBe(screen.getByRole("tabpanel"));
});

it("puts keyboard focus on a scale selected from a lesson", () => {
  render(<LearnWeb audioFactory={silentAudio} />);
  fireEvent.click(screen.getByRole("button", { name: /^E Minor pentatonic/ }));
  expect(document.activeElement).toBe(screen.getByRole("tabpanel"));
  expect(screen.getByLabelText("Scale / mode").value).toBe("minor-pentatonic");
});

it("keeps focus on the user's tab and handedness control during normal navigation", () => {
  render(<LearnWeb audioFactory={silentAudio} />);
  const tab = screen.getByRole("tab", { name: "Fretboard", exact: true });
  tab.focus();
  fireEvent.click(tab);
  expect(document.activeElement).toBe(tab);
  const handedness = screen.getByLabelText("Handedness");
  handedness.focus();
  fireEvent.change(handedness, { target: { value: "left" } });
  expect(document.activeElement).toBe(handedness);
});
