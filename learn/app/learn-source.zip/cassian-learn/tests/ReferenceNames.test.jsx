import React from "react";
import { afterEach, expect, it } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import LearnWeb from "../src/LearnWeb.jsx";
import Fretboard from "../src/Fretboard.jsx";
import { getChordNoteName, getChordVoicing } from "../src/curriculum.js";
import { midiNoteName, NOTE_NAMES } from "../src/fretboardTheory.js";

afterEach(() => {
  cleanup();
  localStorage.clear();
});

const silentAudio = () => ({
  playNotes: async () => true,
  startPulse: async () => true,
  stop() {},
  setTempo() {},
  dispose() {},
});

it.each(["right", "left"])(
  "spells the displayed E7 and B7 chord tones correctly in the %s-handed lesson",
  (handedness) => {
    render(
      <LearnWeb
        audioFactory={silentAudio}
        initialState={{ pathway: "blues", root: 4, handedness }}
      />,
    );
    const rows = screen.getAllByLabelText(
      "Sounding notes from low E to high E",
    );
    const notes = (row) => [...row.children].map((node) => node.textContent);
    expect(notes(rows[0])).toEqual(["E", "B", "D", "G#", "B", "E"]);
    expect(notes(rows[2])).toEqual(["B", "F#", "A", "D#", "F#", "B"]);
  },
);

it.each([false, true])(
  "keeps scale note labels, accessible names and the selected pitch consistent with leftHanded=%s",
  (leftHanded) => {
    const view = render(
      <Fretboard
        root={4}
        scale="ionian"
        leftHanded={leftHanded}
        compactControls
      />,
    );
    const note = view.container.querySelector(
      '[data-string-index="0"][data-fret="4"]',
    );
    expect(note.dataset.midi).toBe("44");
    expect(note.querySelector("text").textContent).toBe("G#");
    expect(note.getAttribute("aria-label")).toContain("G#2");
    fireEvent.click(note);
    expect(screen.getByLabelText("Selected fret").textContent).toContain("G#2");
  },
);

it("uses the written octave when a C-sharp-major note is B-sharp", () => {
  const view = render(<Fretboard root={1} scale="ionian" compactControls />);
  const note = view.container.querySelector(
    '[data-string-index="0"][data-fret="8"]',
  );
  expect(note.dataset.midi).toBe("48");
  expect(note.querySelector("text").textContent).toBe("B#");
  expect(note.getAttribute("aria-label")).toContain("B#2");
});

it("retains a chord's written root and distinguishes a sharp ninth from a minor third", () => {
  const chord = { ...getChordVoicing("minor", 8), name: "G#m" };
  expect(getChordNoteName(chord, 68)).toBe("G#");
  expect(getChordNoteName(chord, 75)).toBe("D#");
  expect(
    getChordNoteName(
      { name: "C7#9", baseRoot: 0, intervals: [0, 4, 7, 10, 3] },
      63,
    ),
  ).toBe("D#");
});

it("preserves canonical MIDI names and computes written enharmonic octaves", () => {
  expect([40, 45, 50].map(midiNoteName)).toEqual(["E2", "A2", "D3"]);
  for (let midi = 0; midi < 128; midi += 1) {
    expect(midiNoteName(midi)).toBe(
      NOTE_NAMES[midi % 12] + (Math.floor(midi / 12) - 1),
    );
  }
  expect(midiNoteName(60, "B#")).toBe("B#3");
  expect(midiNoteName(59, "Cb")).toBe("Cb4");
  expect(midiNoteName(65, "E#")).toBe("E#4");
});
