import { useEffect, useId, useRef } from 'react';

// Native radios provide exclusive selection and arrow-key navigation inside each bank.
export function SelectorBank({
  label,
  value,
  options,
  disabled = false,
  onChange,
  className = '',
}) {
  const name = useId();
  return (
    <fieldset className={`hardware-selector ${className}`} disabled={disabled} aria-label={label}>
      <legend>{label}</legend>
      <div>
        {options.map((option, index) => {
          const item = typeof option === 'string' ? { value: index, label: option } : option;
          return (
            <label key={item.value}>
              <input
                type="radio"
                name={name}
                value={item.value}
                checked={value === item.value}
                disabled={disabled}
                onChange={() => {
                  if (!disabled) onChange(item.value);
                }}
              />
              <span>
                <i aria-hidden="true" />
                {item.label}
              </span>
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

// Draft controls deliberately bypass the global parameter/automation store.
// A press only captures the dial; values move with relative drag or an explicit key.
export function DraftDial({
  label,
  caption = label,
  value,
  min,
  max,
  step = 1,
  fineStep = step / 10,
  disabled = false,
  onChange,
}) {
  const drag = useRef(null),
    input = useRef(null),
    bounded = (value) => Math.max(min, Math.min(max, value));
  const shown = Number.isFinite(value) ? bounded(value) : min;
  const hint = `Drag or use arrow keys${fineStep < step ? ' · Shift for fine control' : ''}`;
  useEffect(() => {
    if (disabled) drag.current = null;
  }, [disabled]);
  function change(value, increment = step) {
    const next = bounded(Number((Math.round(value / increment) * increment).toFixed(6)));
    if (next !== shown) onChange(next);
  }
  function keyDown(event) {
    if (disabled) return;
    const increment = event.shiftKey ? fineStep : step;
    const direction = {
      ArrowUp: 1,
      ArrowRight: 1,
      ArrowDown: -1,
      ArrowLeft: -1,
      PageUp: 10,
      PageDown: -10,
    }[event.key];
    if (direction === undefined && event.key !== 'Home' && event.key !== 'End') return;
    event.preventDefault();
    event.stopPropagation();
    const next = bounded(
      event.key === 'Home'
        ? min
        : event.key === 'End'
          ? max
          : Number((shown + direction * increment).toFixed(9)),
    );
    if (next !== shown) onChange(next);
  }
  return (
    <label className="draft-dial">
      <span>{caption}</span>
      <span
        className="draft-dial-ring"
        title={hint}
        style={{ '--dial-angle': `${-135 + ((shown - min) / (max - min)) * 270}deg` }}
        onPointerDown={(event) => {
          if (disabled || event.button !== 0) return;
          event.preventDefault();
          input.current?.focus({ preventScroll: true });
          event.currentTarget.setPointerCapture?.(event.pointerId);
          drag.current = { x: event.clientX, y: event.clientY, value: shown };
        }}
        onPointerMove={(event) => {
          if (!drag.current || disabled) return;
          const previous = drag.current;
          previous.value = bounded(
            previous.value +
              ((event.clientX - previous.x - (event.clientY - previous.y)) * (max - min)) /
                200 /
                (event.shiftKey ? 10 : 1),
          );
          previous.x = event.clientX;
          previous.y = event.clientY;
          change(previous.value, event.shiftKey ? fineStep : step);
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerCancel={() => {
          drag.current = null;
        }}
        onLostPointerCapture={() => {
          drag.current = null;
        }}
      >
        <i aria-hidden="true" />
        <input
          ref={input}
          type="range"
          min={min}
          max={max}
          step="any"
          value={shown}
          disabled={disabled}
          aria-label={`${label} dial`}
          aria-description={hint}
          aria-valuetext={String(value)}
          onChange={(event) => {
            if (!disabled) change(event.target.valueAsNumber);
          }}
          onKeyDown={keyDown}
          onBlur={() => {
            drag.current = null;
          }}
        />
      </span>
    </label>
  );
}
