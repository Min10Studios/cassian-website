// Original Cassian theory spelling helpers. Crazaloth provenance.
export const NOTE_NAMES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
export const NOTE_CHOICES = [
  'C',
  'C# / Db',
  'D',
  'D# / Eb',
  'E',
  'F',
  'F# / Gb',
  'G',
  'G# / Ab',
  'A',
  'A# / Bb',
  'B',
];
const letters = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
const naturals = [0, 2, 4, 5, 7, 9, 11];
export function pitchClass(note) {
  return ((Math.trunc(Number(note) || 0) % 12) + 12) % 12;
}
export function spellFromRoot(rootName, soundingPitch, letterSteps) {
  const letter = (letters.indexOf(rootName[0]) + letterSteps) % 7;
  let alteration = pitchClass(soundingPitch - naturals[letter]);
  if (alteration > 6) alteration -= 12;
  return letters[letter] + (alteration < 0 ? 'b'.repeat(-alteration) : '#'.repeat(alteration));
}
export function noteNameInKey(root, offset) {
  const degrees = [0, 1, 1, 2, 2, 3, 3, 4, 5, 5, 6, 6];
  const tonic = pitchClass(root),
    relative = pitchClass(offset);
  return spellFromRoot(NOTE_NAMES[tonic], tonic + relative, degrees[relative]);
}

export function spelledOctave(midi, name) {
  const accidental = [...name.slice(1)].reduce((sum, mark) => sum + (mark === '#' ? 1 : -1), 0);
  return Math.floor((midi - naturals[letters.indexOf(name[0])] - accidental) / 12) - 1;
}
