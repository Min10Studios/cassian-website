import * as uiCopy from "./copy.js";
export const doctors = [
  {
    id: "gain",
    title: "Gain vs Master",
    summary: uiCopy.ToneAcademy_Distortion_and_listening_level_have_different,
    explanation: uiCopy.ToneAcademy_Gain_pushes_the_amplifier_input_into,
    exercise: uiCopy.ToneAcademy_Play_one_chord_softly_then_hard,
  },
  {
    id: "presence",
    title: "Presence vs Treble",
    summary: uiCopy.ToneAcademy_Separate_upperedge_bite_from_the_main,
    explanation: uiCopy.ToneAcademy_Treble_shapes_the_highfrequency_balance_of,
    exercise: uiCopy.ToneAcademy_Hold_a_chord_and_move_Treble,
  },
  {
    id: "depth",
    title: "Depth / Resonance",
    summary: uiCopy.ToneAcademy_Lowend_weight_is_different_from_lowend,
    explanation: uiCopy.ToneAcademy_A_heads_depth_or_resonance_control,
    exercise: uiCopy.ToneAcademy_Palmmute_the_lowest_string_If_it,
  },
  {
    id: "gate",
    title: "Noise Gate Clamp",
    summary: uiCopy.ToneAcademy_Silence_between_notes_should_not_erase,
    explanation: uiCopy.ToneAcademy_Threshold_decides_when_the_front_gate,
    exercise: uiCopy.ToneAcademy_Mute_the_strings_and_raise_Threshold,
  },
];
