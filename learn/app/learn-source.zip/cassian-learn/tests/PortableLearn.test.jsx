import React from "react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  within,
} from "@testing-library/react";
import LearnWeb from "../src/LearnWeb.jsx";
import { ChordDiagram } from "../src/GenreCurriculum.jsx";
import {
  OPEN_CHORDS,
  CHORD_SHAPES,
  getChordVoicing,
  PATHWAYS,
} from "../src/curriculum.js";
import {
  getFretMidi,
  getLearnTuning,
  LEARN_TUNINGS,
} from "../src/fretboardTheory.js";
import { sanitizePreferences, readPreferences } from "../src/preferences.js";
import { progressionChords } from "../src/TheoryCompass.jsx";

beforeEach(() => localStorage.clear());
afterEach(cleanup);
const fakeAudio = {
  playNotes: vi.fn().mockResolvedValue(true),
  startPulse: vi.fn().mockResolvedValue(true),
  stop: vi.fn(),
  setTempo: vi.fn(),
  dispose: vi.fn(),
};
const factory = () => fakeAudio;
const setting = (name) =>
  within(screen.getByLabelText("Learning preferences")).getByLabelText(name);

it("persists one left-handed preference across neck, every chord diagram and reload", () => {
  const view = render(<LearnWeb audioFactory={factory} />);
  fireEvent.change(setting("Handedness"), { target: { value: "left" } });
  expect(
    document.querySelectorAll('[data-handedness="left"]').length,
  ).toBeGreaterThan(1);
  fireEvent.click(screen.getByRole("tab", { name: "Fretboard", exact: true }));
  expect(screen.getByRole("grid").getAttribute("aria-label")).toContain(
    "left-handed",
  );
  view.unmount();
  render(<LearnWeb audioFactory={factory} />);
  expect(setting("Handedness").value).toBe("left");
  expect(screen.getByRole("grid").getAttribute("aria-label")).toContain(
    "left-handed",
  );
});

it.each(OPEN_CHORDS)(
  "preserves named $name pitches, fret numbers and readable labels in both hands",
  (chord) => {
    const view = render(<ChordDiagram chord={chord} />);
    const original = [
      ...view.container.querySelectorAll("[data-string-index]"),
    ].map((node) => ({
      string: node.dataset.stringIndex,
      fret: node.dataset.fret,
      midi: node.dataset.midi,
      x: Number(node.querySelector("line").getAttribute("x1")),
      text: node.textContent,
    }));
    view.rerender(<ChordDiagram chord={chord} leftHanded />);
    const mirrored = [
      ...view.container.querySelectorAll("[data-string-index]"),
    ];
    mirrored.forEach((node, index) => {
      expect([
        node.dataset.stringIndex,
        node.dataset.fret,
        node.dataset.midi,
        node.textContent,
      ]).toEqual([
        original[index].string,
        original[index].fret,
        original[index].midi,
        original[index].text,
      ]);
      expect(
        Number(node.querySelector("line").getAttribute("x1")) +
          original[index].x,
      ).toBe(149);
      expect(node.getAttribute("transform")).toBeNull();
    });
    const actual = original
      .filter((row) => row.midi)
      .map((row) => Number(row.midi) % 12);
    expect(
      actual.every((pc) =>
        chord.intervals.includes((pc - chord.baseRoot + 12) % 12),
      ),
    ).toBe(true);
  },
);

it("keeps all CAGED named major voicings mathematically correct in every key", () => {
  for (const root of Array.from({ length: 12 }, (_, index) => index)) {
    for (const id of ["cagedC", "cagedA", "cagedG", "cagedE", "cagedD"]) {
      expect(CHORD_SHAPES[id]).toBeTruthy();
      const chord = getChordVoicing(id, root);
      const sounding = chord.frets.flatMap((fret, index) =>
        fret === null ? [] : [getFretMidi("standard", index, fret)],
      );
      expect(
        sounding.every((midi) => [0, 4, 7].includes((midi - root + 120) % 12)),
      ).toBe(true);
      expect(sounding.some((midi) => midi % 12 === root)).toBe(true);
    }
  }
});

it.each(LEARN_TUNINGS)(
  "$name keeps exact open pitches and octaves for every string count",
  (tuning) => {
    const selected = getLearnTuning(tuning.id);
    selected.notes.forEach((midi, index) => {
      expect(getFretMidi(tuning.id, index, 0)).toBe(midi);
      expect(getFretMidi(tuning.id, index, 12)).toBe(midi + 12);
      expect(getFretMidi(tuning.id, index, 24)).toBe(midi + 24);
    });
  },
);

it("retains all four source progression families with correct transposition", () => {
  expect(progressionChords(0, "pop")).toEqual(["C", "G", "Am", "F"]);
  expect(progressionChords(0, "jazz")).toEqual(["Dm7", "G7", "Cmaj7"]);
  expect(progressionChords(9, "spanish")).toEqual(["Am", "G", "F", "E"]);
  expect(progressionChords(4, "blues")).toEqual([
    "E7",
    "E7",
    "E7",
    "E7",
    "A7",
    "A7",
    "E7",
    "E7",
    "B7",
    "A7",
    "E7",
    "B7",
  ]);
});

it("recovers from corrupt, oversized or unavailable preference storage without accepting foreign state", () => {
  expect(readPreferences("key", { getItem: () => "{broken" }).handedness).toBe(
    "right",
  );
  expect(
    readPreferences("key", { getItem: () => "x".repeat(9000) }).completed,
  ).toEqual([]);
  expect(
    sanitizePreferences({
      root: 42,
      tuning: "private-model",
      completed: ["blues", "blues", "secret"],
      handedness: "mirrored-all-text",
    }),
  ).toMatchObject({
    root: 4,
    tuning: "standard",
    handedness: "right",
    completed: ["blues"],
  });
});

it("records manual practice progress, keeps all twelve pathways and never claims mastery automatically", () => {
  render(<LearnWeb audioFactory={factory} />);
  expect(within(setting("Pathway")).getAllByRole("option")).toHaveLength(12);
  expect(PATHWAYS).toHaveLength(12);
  fireEvent.click(
    screen.getByRole("button", { name: "Mark this lesson practised" }),
  );
  expect(screen.getByText("1 / 12 practised")).toBeTruthy();
  expect(
    JSON.parse(localStorage.getItem("cassian.learn.web.v1")).completed,
  ).toEqual(["blues"]);
});

it("cleans up reference audio on unmount and reports browser rejection honestly", async () => {
  fakeAudio.startPulse.mockRejectedValueOnce(Error("Playback blocked."));
  const view = render(<LearnWeb audioFactory={factory} />);
  fireEvent.click(screen.getByRole("button", { name: "Start pulse" }));
  expect(await screen.findByText("Playback blocked.")).toBeTruthy();
  expect(
    screen
      .getByRole("button", { name: "Start pulse" })
      .getAttribute("aria-pressed"),
  ).toBe("false");
  view.unmount();
  expect(fakeAudio.dispose).toHaveBeenCalled();
});

it("keeps harmony hints correct in both orientations without changing written string order", () => {
  render(<LearnWeb audioFactory={factory} />);
  expect(
    screen.getByText(
      /strings listed low E to high E; diagrams follow your handedness/,
    ),
  ).toBeTruthy();
  fireEvent.change(setting("Handedness"), { target: { value: "left" } });
  expect(
    screen.getByText(
      /strings listed low E to high E; diagrams follow your handedness/,
    ),
  ).toBeTruthy();
  expect(screen.queryByText(/low E at left/)).toBeNull();
});
