import { useState } from "react";
import recipes from "./recipeData.json";
import { doctors } from "./doctors.js";
import factoryReferences from "./factoryStudyReferences.json";
import { captureStudyDoctors } from "./captureStudyDoctors.js";

const label = (id) =>
  id
    .replace(/^(AMP_|REVERB_|DELAY_|COMP_|DIST_|CHORUS_)/, "")
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(/^./, (letter) => letter.toUpperCase());
export default function ToneGuide({ pathway }) {
  const recipe = recipes.find((row) => row.id === pathway) ?? recipes[0];
  const [studyId, setStudyId] = useState("");
  const study = factoryReferences.studies.find((row) => row.id === studyId);
  const [feedback, setFeedback] = useState("");
  const text = study
    ? [
        study.name,
        `Factory preset study · reference: Cassian ${factoryReferences.minimumVersion}`,
        `Search the sound chooser for: ${study.searchTerm}`,
        "Load the complete preset, then repeat one short phrase at a matched listening level.",
        "Study one visible control at a time and keep the preset's saved routing as your starting point.",
      ].join("\n")
    : [
        recipe.name,
        recipe.amp,
        recipe.description,
        ...Object.entries(recipe.ampControls).map(
          ([id, value]) => `${label(id)}: ${value}`,
        ),
        ...recipe.blocks.map(
          (block) =>
            `${block.type}: ${Object.entries(block.values)
              .map(([id, value]) => `${label(id)} ${value}`)
              .join(", ")}`,
        ),
        recipe.lesson,
        recipe.limitations,
      ].join("\n");
  const copy = async () => {
    try {
      if (!navigator.clipboard?.writeText) throw Error();
      await navigator.clipboard.writeText(text);
      setFeedback(study ? "Study copied." : "Recipe copied.");
    } catch {
      setFeedback(
        study
          ? "Clipboard unavailable. Select and copy the study below."
          : "Clipboard unavailable. Select and copy the recipe below.",
      );
    }
  };
  return (
    <section className="learn-tone-guide" aria-label="Tone crafting guide">
      <label>
        Tone study
        <select
          aria-label="Tone study"
          value={study?.id ?? ""}
          onChange={(event) => {
            setStudyId(event.target.value);
            setFeedback("");
          }}
        >
          <option value="">Original genre recipe · {recipe.genre}</option>
          <optgroup
            label={`Factory presets · Cassian ${factoryReferences.minimumVersion}`}
          >
            {factoryReferences.studies.map((row) => (
              <option key={row.id} value={row.id}>
                {row.name}
              </option>
            ))}
          </optgroup>
        </select>
      </label>
      <div className="learn-card">
        <span className="learn-kicker">
          {study
            ? `Factory study · Cassian ${factoryReferences.minimumVersion}`
            : `Tone recipe · ${recipe.genre}`}
        </span>
        <h2>{study?.name ?? recipe.name}</h2>
        <p>
          {study
            ? `In Cassian ${factoryReferences.minimumVersion}, ` +
              `search the sound chooser for “${study.searchTerm}” and load the complete preset.`
            : recipe.description}
        </p>
        <div
          className="learn-signal-chain"
          aria-label="Typical guitar signal chain"
        >
          <span>
            {study
              ? "Complete preset → saved amp, cabinet and pedal routing"
              : "Guitar → Wah / drive → Amp → Cabinet → Modulation → Delay / reverb"}
          </span>
        </div>
        <p>
          {study
            ? "Repeat one short phrase. Describe the attack, sustain and space, " +
              "then compare one visible control at a matched listening level."
            : recipe.lesson}
        </p>
        <p className="learn-muted">
          {study
            ? "The source capture defines its recorded tone. Use the controls displayed for the selected preset."
            : recipe.limitations}
        </p>
        <details>
          <summary>{study ? "Study reference" : "Recipe settings"}</summary>
          <pre tabIndex="0">{text}</pre>
        </details>
        <button type="button" onClick={copy}>
          {study ? "Copy study" : "Copy recipe"}
        </button>
        <p role="status">{feedback}</p>
        <p className="learn-muted">
          {study
            ? "Choose this preset in the desktop sound chooser and use your instrument for the listening exercise."
            : "Load the matching genre recipe in desktop Learn before exploring its controls. " +
              "Reference audio here uses a simple synth."}
        </p>
      </div>
      <div className="learn-doctors">
        {(study ? captureStudyDoctors : doctors).map((doctor) => (
          <details className="learn-card" key={doctor.id}>
            <summary>{doctor.title}</summary>
            <p>{doctor.summary}</p>
            <p>{doctor.explanation}</p>
            <strong>Try it on your guitar</strong>
            <p>{doctor.exercise}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
