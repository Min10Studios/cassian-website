import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFile, mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = fileURLToPath(new URL("../", import.meta.url));
const stamp = new Date().toISOString().replaceAll(/[:.]/g, "-");
const output = resolve(root, ".local", "browser-" + stamp);
await mkdir(output, { recursive: true });
const html =
  '<!doctype html><html lang="en"><head><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width,initial-scale=1"><title>Learn browser proof</title>' +
  '<link rel="stylesheet" href="/host.css"></head><body><main><h1>Learn guitar with Cassian</h1>' +
  '<div id="cassian-learn-root"></div></main><script type="module" src="/init.js"></script></body></html>';
const init = `import{mountCassianLearn}from'/cassian-learn.js';
window.learnInstance=mountCassianLearn(document.querySelector('#cassian-learn-root'),{
stylesUrl:'/cassian-learn.css',sourceUrl:'/learn-source.zip'});
window.addEventListener('popstate',()=>window.learnInstance.unmount());`;
const server = createServer(async (request, response) => {
  response.setHeader(
    "Content-Security-Policy",
    "default-src 'none'; script-src 'self'; style-src 'self'; " +
      "img-src 'self' data:; connect-src 'none'; base-uri 'none'; form-action 'none'",
  );
  const path = new URL(request.url, "http://localhost").pathname;
  let body,
    type = "text/html; charset=utf-8";
  if (path === "/") body = html;
  else if (path === "/init.js") {
    body = init;
    type = "text/javascript";
  } else if (path === "/host.css") {
    body =
      ":root{--black:#141513;--surface:#1a1b19;--white:#eeeae0;" +
      "--muted:#b7b8ad;--amber:#dabb7e;--line:#41413a}body{margin:0;background:var(--black);" +
      "color:var(--white);font-family:Segoe UI,Arial,sans-serif}main{padding-inline:24px}h1{margin:24px;font-size:28px}";
    type = "text/css";
  } else if (path === "/__test/browserAudio.js") {
    body = await readFile(resolve(root, "src/browserAudio.js"));
    type = "text/javascript";
  } else if (
    [
      "/cassian-learn.js",
      "/cassian-learn.css",
      "/learn-source.zip",
      "/LICENSE.txt",
      "/NOTICES.txt",
    ].includes(path)
  ) {
    body = await readFile(resolve(root, "dist", path.slice(1)));
    type = path.endsWith(".js")
      ? "text/javascript"
      : path.endsWith(".css")
        ? "text/css"
        : path.endsWith(".zip")
          ? "application/zip"
          : "text/plain";
  } else {
    response.statusCode = path === "/favicon.ico" ? 204 : 404;
    response.end();
    return;
  }
  response.setHeader("Content-Type", type);
  response.end(body);
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const base = "http://127.0.0.1:" + server.address().port;
const browser = await chromium.launch({
  channel:
    process.env.PLAYWRIGHT_CHANNEL ||
    (process.platform === "win32" ? "msedge" : undefined),
  args: ["--mute-audio"],
});
const rows = [],
  errors = [];
const preference = (page, name) =>
  page.locator(".learn-global-settings").getByLabel(name, { exact: true });
const contrast = ([a, b]) => {
  const lum = (c) =>
    c
      .match(/[\d.]+/g)
      .slice(0, 3)
      .map(Number)
      .map((v) => v / 255)
      .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
      .reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0);
  const x = lum(a),
    y = lum(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
};
try {
  for (const [width, height] of [
    [320, 800],
    [360, 800],
    [390, 844],
    [768, 1024],
    [1280, 800],
    [1920, 1080],
  ]) {
    const page = await browser.newPage({ viewport: { width, height } });
    page.on("pageerror", (error) => errors.push(error.message));
    page.on("console", (message) => {
      if (message.type() === "error") errors.push(message.text());
    });
    await page.addInitScript(() => {
      window.__learnContexts = [];
      window.__csp = [];
      document.addEventListener("securitypolicyviolation", (event) =>
        window.__csp.push(event.violatedDirective),
      );
      const Original = window.AudioContext;
      if (Original)
        window.AudioContext = class extends Original {
          constructor(...args) {
            super(...args);
            window.__learnContexts.push(this);
          }
        };
    });
    await page.goto(base);
    await preference(page, "Pathway").waitFor();
    assert.equal(
      await page.locator("main").count(),
      1,
      "Host owns the single main",
    );
    assert.equal(
      await page.locator("h1").count(),
      1,
      "Host owns the single H1",
    );
    assert.equal(
      await preference(page, "Pathway").locator("option").count(),
      12,
    );
    await preference(page, "Handedness").selectOption("left");
    await page.locator('.cassian-learn[data-handedness="left"]').waitFor();
    const diagram = page.locator("svg.learn-chord-diagram").first();
    const before = await diagram
      .locator("[data-string-index]")
      .evaluateAll((nodes) =>
        nodes.map((n) => ({
          string: n.dataset.stringIndex,
          midi: n.dataset.midi,
          fret: n.dataset.fret,
          text: n.textContent,
          x: Number(n.querySelector("line").getAttribute("x1")),
        })),
      );
    await preference(page, "Handedness").selectOption("right");
    const after = await diagram
      .locator("[data-string-index]")
      .evaluateAll((nodes) =>
        nodes.map((n) => ({
          string: n.dataset.stringIndex,
          midi: n.dataset.midi,
          fret: n.dataset.fret,
          text: n.textContent,
          x: Number(n.querySelector("line").getAttribute("x1")),
        })),
      );
    before.forEach((n, index) => {
      assert.equal(n.x + after[index].x, 149);
      assert.deepEqual(
        [n.string, n.midi, n.fret, n.text],
        [
          after[index].string,
          after[index].midi,
          after[index].fret,
          after[index].text,
        ],
      );
    });
    await preference(page, "Handedness").selectOption("left");
    await preference(page, "Key").selectOption("0");
    await page.getByRole("tab", { name: "Fretboard", exact: true }).click();
    const tab = page.getByRole("tab", { name: "Fretboard", exact: true });
    await tab.hover();
    await tab.focus();
    const selected = await tab.evaluate((node) => {
      const r = node.getBoundingClientRect(),
        range = document.createRange();
      range.selectNodeContents(node);
      const text = range.getBoundingClientRect(),
        s = getComputedStyle(node);
      return {
        foreground: s.color,
        background: s.backgroundColor,
        width: r.width,
        height: r.height,
        textInside: text.left >= r.left && text.right <= r.right,
        scroll: node.scrollWidth,
        client: node.clientWidth,
      };
    });
    assert.ok(
      contrast([selected.foreground, selected.background]) >= 4.5,
      "Selected/hover/focus tab contrast",
    );
    assert.ok(
      selected.textInside && selected.scroll <= selected.client,
      "Tab caption must fit",
    );
    assert.ok(selected.height >= 44, "Tab target floor");
    const tuningIds = await preference(page, "Tuning")
      .locator("option")
      .evaluateAll((nodes) => nodes.map((n) => n.value));
    const maps = [];
    for (const tuning of tuningIds) {
      await preference(page, "Tuning").selectOption(tuning);
      const grid = page.getByRole("grid");
      const data = await grid.evaluate((node) => ({
        strings: Number(node.getAttribute("aria-rowcount")),
        cells: [...node.querySelectorAll("[role=gridcell]")].map((n) => ({
          string: Number(n.dataset.stringIndex),
          fret: Number(n.dataset.fret),
          midi: Number(n.dataset.midi),
          interval: Number(n.dataset.interval),
          x: Number(n.dataset.positionX),
        })),
      }));
      assert.equal(data.cells.length, data.strings * 25);
      for (const cell of data.cells) {
        const open = data.cells.find(
          (n) => n.string === cell.string && n.fret === 0,
        ).midi;
        assert.equal(cell.midi, open + cell.fret);
        assert.equal(cell.interval, cell.midi % 12);
        assert.equal(
          cell.x,
          1328 - (cell.fret === 0 ? 54 : 105 + (cell.fret - 1) * 49),
        );
      }
      maps.push({ tuning, strings: data.strings, cells: data.cells.length });
    }
    assert.deepEqual(
      [...new Set(maps.map((row) => row.strings))].sort(),
      [4, 5, 6, 7, 8],
    );
    await preference(page, "Tuning").selectOption("standard");
    const cell = page.locator('[role=gridcell][tabindex="0"]');
    await cell.focus();
    await cell.press("Home");
    const first = page.locator('[role=gridcell][aria-selected="true"]');
    await first.press("ArrowLeft");
    assert.equal(
      await page
        .locator('[role=gridcell][aria-selected="true"]')
        .getAttribute("data-fret"),
      "1",
    );
    await page
      .getByText("Circle of fifths & chord progressions", { exact: true })
      .click();
    await page.getByLabel("Theory progression").selectOption("jazz");
    assert.deepEqual(
      await page
        .getByRole("list", { name: "Transposed chord progression" })
        .locator("li")
        .evaluateAll((nodes) =>
          nodes.map((n) => n.textContent.replace(/^\d+/, "")),
        ),
      ["Dm7", "G7", "Cmaj7"],
    );
    const circle = page.getByRole("button", {
      name: "Circle key C",
      exact: true,
    });
    const circleBounds = await circle.boundingBox();
    assert.ok(
      circleBounds.width >= 24 && circleBounds.height >= 24,
      "Circle key target floor",
    );
    await circle.focus();
    await circle.press("ArrowRight");
    assert.equal(
      await preference(page, "Key").inputValue(),
      "7",
      "Circle keyboard updates shared key",
    );
    await preference(page, "Key").selectOption("0");
    const selectBounds = await page
      .locator(".learn-global-settings select")
      .evaluateAll((nodes) =>
        nodes.map((node) => {
          const r = node.getBoundingClientRect(),
            s = getComputedStyle(node),
            canvas = document.createElement("canvas");
          const ctx = canvas.getContext("2d");
          ctx.font = s.font;
          return {
            name: node.closest("label").firstChild.textContent.trim(),
            width: r.width,
            needed:
              ctx.measureText(node.selectedOptions[0].textContent).width +
              parseFloat(s.paddingLeft) +
              parseFloat(s.paddingRight) +
              20,
          };
        }),
      );
    for (const select of selectBounds)
      assert.ok(
        select.width >= select.needed,
        select.name + " selected label clipped",
      );
    assert.ok(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      "No page horizontal overflow",
    );
    assert.deepEqual(
      await page.evaluate(() => window.__csp),
      [],
      "Strict self-only CSP",
    );
    await page.screenshot({
      path: resolve(output, width + "-left-neck.png"),
      fullPage: true,
    });
    await page.reload();
    await preference(page, "Handedness").waitFor();
    assert.equal(
      await preference(page, "Handedness").inputValue(),
      "left",
      "Handedness survives reload",
    );
    assert.equal(
      await page.evaluate(() => window.__learnContexts.length),
      0,
      "No automatic audio",
    );
    await page
      .getByRole("button", { name: "Start pulse", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Stop pulse", exact: true })
      .waitFor();
    assert.equal(
      await page.evaluate(() => window.__learnContexts[0].state),
      "running",
    );
    await page.evaluate(() => {
      Object.defineProperty(document, "hidden", {
        value: true,
        configurable: true,
      });
      document.dispatchEvent(new Event("visibilitychange"));
    });
    await page
      .getByRole("button", { name: "Start pulse", exact: true })
      .waitFor();
    await page.evaluate(() => {
      history.pushState({}, "", "?lesson=1");
      history.back();
    });
    await page.waitForFunction(() =>
      window.__learnContexts.every((context) => context.state === "closed"),
    );
    rows.push({
      width,
      height,
      selected,
      selectBounds,
      maps,
      handednessReload: true,
      audioLifecycle: true,
      cspFailures: 0,
    });
    await page.close();
  }
  const page = await browser.newPage();
  await page.goto(base);
  const audioProof = await page.evaluate(async () => {
    const { scheduleReference } = await import("/__test/browserAudio.js");
    const context = new OfflineAudioContext(1, 72000, 48000);
    scheduleReference(context, 69, 0, 1.3);
    const buffer = await context.startRendering(),
      samples = buffer.getChannelData(0);
    let crossings = 0,
      sum = 0,
      finite = true;
    for (let i = 7200; i < 55200; i++) {
      if (samples[i - 1] <= 0 && samples[i] > 0) crossings++;
      sum += samples[i] ** 2;
      finite &&= Number.isFinite(samples[i]);
    }
    return {
      frequency: crossings,
      rms: Math.sqrt(sum / 48000),
      finite,
      tailSilent: samples.slice(66000).every((value) => value === 0),
    };
  });
  assert.ok(Math.abs(audioProof.frequency - 440) <= 1);
  assert.ok(audioProof.rms > 0.005 && audioProof.rms < 0.1);
  assert.ok(audioProof.finite && audioProof.tailSilent);
  rows.push({ offlineReference: audioProof });
  await page.close();
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ output, cases: rows.length, errors }));
} catch (error) {
  const pages = browser.contexts().flatMap((context) => context.pages());
  for (const [index, page] of pages.entries()) {
    await page.screenshot({
      path: resolve(output, "failure-" + index + ".png"),
      fullPage: true,
    });
    const debug = await page.evaluate(() => ({
      body: document.body.innerHTML,
      shadow: document.querySelector("#cassian-learn-root")?.shadowRoot
        ?.innerHTML,
      csp: window.__csp,
    }));
    await writeFile(
      resolve(output, "failure-" + index + ".json"),
      JSON.stringify(debug, null, 2),
    );
  }
  throw error;
} finally {
  await writeFile(
    resolve(output, "RESULTS.json"),
    JSON.stringify({ rows, errors }, null, 2) + "\n",
  );
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
