// Browser-only offline fallback. The installed app uses its native MIDI engine.
// Crazaloth provenance. The scheduler owns and releases every timer and audio node.
export function createArpeggioPlayer({
  AudioContextClass,
  onEvent = () => {},
  onStarted = () => {},
  onComplete = () => {},
  onError = () => {},
}) {
  let session = null,
    generation = 0;
  const stop = () => {
    generation += 1;
    if (!session) return;
    const old = session;
    session = null;
    clearInterval(old.timer);
    for (const timer of old.uiTimers) clearTimeout(timer);
    for (const node of old.nodes) {
      try {
        node.osc.stop();
      } catch {
        /* Already ended. */
      }
      node.osc.disconnect();
      node.gain.disconnect();
    }
    old.nodes.clear();
    old.master.disconnect();
    Promise.resolve(old.context.close()).catch(() => {});
  };
  const setVolume = (volume) => {
    if (session)
      session.master.gain.setTargetAtTime(
        Math.max(0, Math.min(100, volume)) / 100,
        session.context.currentTime,
        0.02,
      );
  };
  const start = async (events, { tempo = 90, totalTicks, loop = false, volume = 75 } = {}) => {
    stop();
    const token = generation;
    if (!AudioContextClass)
      throw new Error(
        'Reference audio is unavailable here. You can still use the fretboard, tab and MIDI file.',
      );
    if (!events.length || events.length > 8192 || !Number.isFinite(totalTicks) || totalTicks <= 0)
      throw new Error('Choose a playable arpeggio first.');
    const context = new AudioContextClass();
    const master = context.createGain();
    master.gain.setValueAtTime(Math.max(0, Math.min(100, volume)) / 100, context.currentTime);
    master.connect(context.destination);
    const current = { context, master, nodes: new Set(), uiTimers: new Set(), timer: null };
    session = current;
    try {
      if (context.state === 'suspended') await context.resume();
      if (token !== generation) return;
      const secondsPerTick = 60 / Math.min(240, Math.max(40, tempo)) / 480;
      const length = totalTicks * secondsPerTick;
      let origin = context.currentTime + 0.06,
        index = 0;
      const tick = () => {
        if (session !== current) return;
        try {
          const horizon = context.currentTime + 0.15;
          while (true) {
            if (index === events.length) {
              if (!loop || origin + length >= horizon) break;
              // Queue the next cycle before the boundary, without an added pause.
              origin =
                origin + length < context.currentTime - 0.06
                  ? context.currentTime + 0.06
                  : origin + length;
              index = 0;
            }
            if (origin + events[index].tick * secondsPerTick >= horizon) break;
            const event = events[index++];
            const scheduled = origin + event.tick * secondsPerTick;
            // A busy UI must not bunch missed notes into a loud chord.
            if (scheduled < context.currentTime - 0.06) continue;
            const when = Math.max(context.currentTime, scheduled);
            const duration = Math.max(0.035, event.duration * secondsPerTick);
            const osc = context.createOscillator(),
              gain = context.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(440 * 2 ** ((event.midi - 69) / 12), when);
            gain.gain.setValueAtTime(0, when);
            gain.gain.linearRampToValueAtTime(0.16, when + 0.006);
            gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
            osc.connect(gain);
            gain.connect(master);
            const node = { osc, gain };
            current.nodes.add(node);
            osc.onended = () => {
              current.nodes.delete(node);
              osc.disconnect();
              gain.disconnect();
            };
            osc.start(when);
            osc.stop(when + duration + 0.01);
            const uiTimer = setTimeout(
              () => {
                current.uiTimers.delete(uiTimer);
                if (session === current) onEvent(event);
              },
              Math.max(0, (when - context.currentTime) * 1000),
            );
            current.uiTimers.add(uiTimer);
          }
          if (!loop && index === events.length && context.currentTime >= origin + length) {
            stop();
            onComplete();
          }
        } catch (error) {
          stop();
          onError(error);
        }
      };
      current.timer = setInterval(tick, 25);
      onStarted();
      tick();
    } catch (error) {
      if (session === current) {
        stop();
        throw error;
      }
    }
  };
  return { start, stop, setVolume };
}
